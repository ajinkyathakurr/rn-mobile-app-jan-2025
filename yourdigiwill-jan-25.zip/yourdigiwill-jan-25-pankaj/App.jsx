import 'react-native-gesture-handler';
import * as React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { useState, useEffect, useContext } from 'react';
import Splash from './src/components/Splash';
import { AppState } from './user/AppState';
import Login from './src/components/Login';
import OtpVerification from './src/components/OtpVerification';
import Home from './src/components/Home';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SharedByMe from './src/components/SharedByMe';
import Notification from './src/components/Notification';
import Nominee from './src/components/Nominee';
import EnsuranceOne from './src/components/Ensurance/EnsuranceOne';
import EnsuranceTwo from './src/components/Ensurance/EnsuranceTwo';
import EnsuranceThree from './src/components/Ensurance/EnsuranceThree';
import EnsuranceFour from './src/components/Ensurance/EnsuranceFour';
import { AppContext } from './user/AppContext';
import FlashMessage from "react-native-flash-message";
import Signup from './src/components/Signup';
import Pincode from './Pincode';
import Pinverify from './src/components/Pinverify';
import Flash from './src/components/Flash';
import Changepin from './src/components/Changepin';
import Subscriptionlist from './src/components/subscriptions/Subscriptionlist';
import Emptysubscription from './src/components/subscriptions/Emptysubscription';
import LinkedAssets from './src/components/LinkedAssets';
import GetAllassets from './src/components/GetAllassets';
import MyAssetsAndLiablity from './src/components/MyAssetsAndLiablity';
import { MenuProvider } from 'react-native-popup-menu';
import MutualFund from './src/components/forms/MutualFund';
import DistributionOne from './src/components/Distribution/DistributionOne';
import AddNominee from './src/components/nominee/AddNominee';
import NomineeDetails from './src/components/nominee/NomineeDetails';
import EditNominee from './src/components/nominee/EditNominee';
import DistributionTwo from './src/components/Distribution/DistributionTwo';
import SubscriptionOne from './src/components/subscriptions/SubscriptionOne';
import Insurance from './src/components/forms/Insurance';
import Startup from './src/components/forms/Startup';
import LoginSignup from './src/components/LoginSignup';
import ProfileDetails from './src/components/ProfileDetails';
import ViewProfile from './src/components/profile/ViewProfile';
import CommunicationOne from './src/components/communication/CommunicationOne';
import CommunicationTwo from './src/components/communication/CommunicationTwo';
import CommunicationThree from './src/components/communication/CommunicationThree';
import CommunicationFour from './src/components/communication/CommunicationFour';
import ExpressOne from './src/components/expresswill/ExpressOne';
import ExpressTwo from './src/components/expresswill/ExpressTwo';
import EditProfile from './src/components/profile/EditProfile';
import Shares from './src/components/forms/Shares.js';
import RealEstate from './src/components/forms/RealEstate';
import NPS from './src/components/forms/NPS';
import ESOP from './src/components/forms/ESOP';
import Jewellery from './src/components/forms/Jewellery';
import CryptoInvestment from './src/components/forms/Crypto_Investment';
import BankInvestment from './src/components/forms/BankInvestment';
import EPF from './src/components/forms/EPF';
import Loan from './src/components/forms/Loan';
import CreditCard from './src/components/forms/CreditCard';
import GovernmentScheme from './src/components/forms/GovernmentScheme';
import OtherInvestment from './src/components/forms/OtherInvestment';
import ChitFunds from './src/components/forms/ChitFunds';
import GoldLoan from './src/components/forms/GoldLoan';
import CashBorrowed from './src/components/forms/CashBorrowed';
import CreatorAsset from './src/components/forms/CreatorAsset';
import HomepageEnsurance from './src/components/Ensurance/HomePageEnsurance';
import EnsuranceNewOne from './src/components/Ensurance/EnsuranceNewOne';
import { value } from 'deprecated-react-native-prop-types/DeprecatedTextInputPropTypes';
import Terms from './src/components/Terms';
import Privacy from './src/components/Privacy';
import MyReminders from './src/components/MyReminders';
import Settings from './src/components/Settings';
import EditNominee_Communication from './src/components/communication/EditNomineeCommunication';
import BankAccount from './src/components/forms/BankAccount';
import AlreadySubscribed from './src/components/Ensurance/AlreadySubscribed';
import AddNomineeEnsurance from './src/components/Ensurance/AddNomineeEnsurance';
import CommunicationDetail from './src/components/communication/CommunicationDetail';
import CommunicationAddNominee from './src/components/communication/CommunicationAddNominee';
import SetupMPIN from './src/components/Setupmpin';
import InvoiceWebView from './src/components/subscriptions/InvoiceWebView';
import Linked from './src/components/Linked';
import WitnessAndGuardians from './src/components/expresswill/WitnessAndGuardians';
import SpecialDirectives from './src/components/expresswill/SpecialDirectives.js';
import ListingScreen from './src/components/expresswill/ListingScreen.js';
import Executor from './src/components/expresswill/Executor.js';import ExpressWillPreview from './src/components/expresswill/ExpressWillPreview.js';
import Payment from './src/components/expresswill/Payment.js';
import Esign from './src/components/expresswill/Esign.js';
import Reffral from './src/components/Reffral.js';
import ViewDoc from './src/components/ViewDoc.js';
import ViewManagers from './src/components/Managers/ViewManagers.js';

import AddManager from './src/components/Managers/AddManager.js';
import SharedWithMe from './src/components/SharedWithMe.js';
import OnboardingScreen from './src/components/OnboardingScreen.js';
import ChooseFrequency from './src/components/communication/ChooseFrequency.js';
import CommunicationNominee from './src/components/communication/CommunicationNominee.js';
const Stack = createStackNavigator();


export default function App() {
  const { pin, setToken, setPin, loading, setIsLoading } = useContext(AppContext);

  useEffect(() => {
    const checkAuthStatus = async () => {
      setIsLoading(true);
      const storedToken = await AsyncStorage.getItem("token");
      const storedPin = await AsyncStorage.getItem("pin");

      setToken(storedToken || "");
      setPin(storedPin || "");

      setIsLoading(false);
    };

    checkAuthStatus();
  }, []);

  if (loading) {
    return null; // You can add a loading spinner here if needed
  }


  return (

    <MenuProvider>
      <NavigationContainer>

        <Stack.Navigator >
        {pin ? 
          
            <Stack.Screen name="Pinverify" component={Pinverify} options={{ headerShown: false }}   initialParams={{  nominee: "signup", id: ""  }} 
/>
           : (
          <Stack.Screen name="OnboardingScreen" component={OnboardingScreen} options={{ headerShown: false }} />        
        )}
          <Stack.Screen name="Login" component={Login} options={{ headerShown: false }} />
          <Stack.Screen name="LoginSignup" component={LoginSignup} options={{ headerShown: false }} />
          <Stack.Screen name="ProfileDetails" component={ProfileDetails} options={{ headerShown: false }} />
          <Stack.Screen name="OtpVerification" component={OtpVerification} options={{ headerShown: false }} />
          <Stack.Screen name="Home" component={Home} options={{ headerShown: false }} />
          <Stack.Screen name="SharedByMe" component={SharedByMe} options={{ headerShown: false }} />
          <Stack.Screen name="Notification" component={Notification} options={{ headerShown: false }} />
          <Stack.Screen name="Nominee" component={Nominee} options={{ headerShown: false }} />
          <Stack.Screen name="ViewManagers" component={ViewManagers} options={{ headerShown: false }} />
          <Stack.Screen name="AddManager" component={AddManager} options={{ headerShown: false }} />
          <Stack.Screen name="EnsuranceOne" component={HomepageEnsurance} options={{ headerShown: false }} />
          <Stack.Screen name="EnsuranceTwo" component={EnsuranceTwo} options={{ headerShown: false }} />
          <Stack.Screen name="EnsuranceThree" component={EnsuranceThree} options={{ headerShown: false }} />
          <Stack.Screen name="EnsuranceFour" component={EnsuranceFour} options={{ headerShown: false }} />
          <Stack.Screen name="Signup" component={Signup} options={{ headerShown: false }} />
          <Stack.Screen name="Pincode" component={Pincode} options={{ headerShown: false }} />
          {/* <Stack.Screen name="Pinverify" component={Pinverify} options={{ headerShown: false }} /> */}
          <Stack.Screen name="Changepin" component={Changepin} options={{ headerShown: false }} />
          <Stack.Screen name="Subscriptionlist" component={Subscriptionlist} options={{ headerShown: false }} />
          <Stack.Screen name="Emptysubscription" component={Emptysubscription} options={{ headerShown: false }} />
          <Stack.Screen name="LinkedAssets" component={LinkedAssets} options={{ headerShown: false }} />
          <Stack.Screen name="SharedWithMe" component={SharedWithMe} options={{ headerShown: false }} />
          <Stack.Screen name="GetAllassets" component={GetAllassets} options={{ headerShown: false }} />
          <Stack.Screen name="MyAssetsAndLiablity" component={MyAssetsAndLiablity} options={{ headerShown: false }} />
          <Stack.Screen name="DistributionOne" component={DistributionOne} options={{ headerShown: false }} />
          <Stack.Screen name="AddNominee" component={AddNominee} options={{ headerShown: false }} />
          <Stack.Screen name="NomineeDetails" component={NomineeDetails} options={{ headerShown: false }} />
          <Stack.Screen name="EditNominee" component={EditNominee} options={{ headerShown: false }} />
          <Stack.Screen name="DistributionTwo" component={DistributionTwo} options={{ headerShown: false }} />
          <Stack.Screen name="SubscriptionOne" component={SubscriptionOne} options={{ headerShown: false }} />
          <Stack.Screen name="ViewProfile" component={ViewProfile} options={{ headerShown: false }} />
          <Stack.Screen name="EditProfile" component={EditProfile} options={{ headerShown: false }} />
          <Stack.Screen name="MyReminders" component={MyReminders} options={{ headerShown: false }} />
          <Stack.Screen name="Settings" component={Settings} options={{ headerShown: false }} />
          <Stack.Screen name="Reffral" component={Reffral} options={{ headerShown: false }} />
          
          <Stack.Screen name="SetupMPIN" component={SetupMPIN} options={{ headerShown: false }} />
          <Stack.Screen name="LinkedAccounts" component={Linked} options={{ headerShown: false }} />

          <Stack.Screen name="ViewDoc" component={ViewDoc} options={{ headerShown: false }} />          
          <Stack.Screen name="Mutual Funds" component={MutualFund} options={{ headerShown: false }} />
          <Stack.Screen name="Shares" component={Shares} options={{ headerShown: false }} />
          <Stack.Screen name="Insurance" component={Insurance} options={{ headerShown: false }} />
          <Stack.Screen name="Startup Investment" component={Startup} options={{ headerShown: false }} />
          <Stack.Screen name="Real Estate" component={RealEstate} options={{ headerShown: false }} />
          <Stack.Screen name="NPS" component={NPS} options={{ headerShown: false }} />
          <Stack.Screen name="ESOP" component={ESOP} options={{ headerShown: false }} />
          <Stack.Screen name="Jewellery" component={Jewellery} options={{ headerShown: false }} />
          <Stack.Screen name="Crypto Investment" component={CryptoInvestment} options={{ headerShown: false }} />
          <Stack.Screen name="Bank Investment" component={BankInvestment} options={{ headerShown: false }} />
          <Stack.Screen name="EPF" component={EPF} options={{ headerShown: false }} />
          <Stack.Screen name="Loan" component={Loan} options={{ headerShown: false }} />
          <Stack.Screen name="Credit Card" component={CreditCard} options={{ headerShown: false }} />
          <Stack.Screen name="Government Scheme" component={GovernmentScheme} options={{ headerShown: false }} />
          <Stack.Screen name="Other Investments" component={OtherInvestment} options={{ headerShown: false }} />
          <Stack.Screen name="Chit Funds/Kitty Party" component={ChitFunds} options={{ headerShown: false }} />
          <Stack.Screen name="Cash Borrowed" component={CashBorrowed} options={{ headerShown: false }} />
          <Stack.Screen name="Gold Loan" component={GoldLoan} options={{ headerShown: false }} />
          <Stack.Screen name="Creator Asset" component={CreatorAsset} options={{ headerShown: false }} />
          <Stack.Screen name="Terms" component={Terms} options={{ headerShown: false }} />
          <Stack.Screen name="Bank Account" component={BankAccount} options={{ headerShown: false }} />

          <Stack.Screen name="Privacy" component={Privacy} options={{ headerShown: false }} />
          
          <Stack.Screen name="EnsuranceNewOne" component={EnsuranceNewOne} options={{ headerShown: false }} />
          <Stack.Screen name="AlreadySubscribed" component={AlreadySubscribed} options={{ headerShown: false }} />
          <Stack.Screen name="AddNomineeEnsurance" component={AddNomineeEnsurance} options={{ headerShown: false }} />




          
          <Stack.Screen name="CommunicationOne" component={CommunicationOne} options={{ headerShown: false }} />
          <Stack.Screen name="CommunicationNominee" component={CommunicationNominee} options={{ headerShown: false }} />
          <Stack.Screen name="ChooseFrequency" component={ChooseFrequency} options={{ headerShown: false }} />
          <Stack.Screen name="CommunicationTwo" component={CommunicationTwo} options={{ headerShown: false }} />
          <Stack.Screen name="CommunicationThree" component={CommunicationThree} options={{ headerShown: false }} />
          <Stack.Screen name="CommunicationFour" component={CommunicationFour} options={{ headerShown: false }} />
          <Stack.Screen name="EditNominee_Communication" component={EditNominee_Communication} options={{ headerShown: false }} />
          <Stack.Screen name="CommunicationDetail" component={CommunicationDetail} options={{ headerShown: false }} />
          <Stack.Screen name="CommunicationAddNominee" component={CommunicationAddNominee} options={{ headerShown: false }} />

          

          <Stack.Screen name="ExpressOne" component={ExpressOne} options={{ headerShown: false}}/>
          <Stack.Screen name="ExpressTwo" component={ExpressTwo} options={{ headerShown: false }} />
          <Stack.Screen name="ExpressWillPreview" component={ExpressWillPreview} options={{headerShown:false}} />
          <Stack.Screen name='Payment' component={Payment} options={{headerShown:false}}/>
          <Stack.Screen  name="ListingScreen" component={ListingScreen} options={{ headerShown: false }} />
          <Stack.Screen name="WitnessAndGuardians" component={WitnessAndGuardians} options={{ headerShown: false}} />
          <Stack.Screen name="SpecialDirectives" component={SpecialDirectives} options={{ headerShown: false }} />
          <Stack.Screen name="Executor" component={Executor} options={{ headerShown: false }} />
          <Stack.Screen name="Esign" component={Esign} options={{ headerShown: false }} />
          

          {/* my subscriptions setting */}


          <Stack.Screen name="Download" component={InvoiceWebView} options={{ headerShown: false }} />


        </Stack.Navigator>


      </NavigationContainer>
      <FlashMessage style={{ elevation: 10000, zIndex: 10000 }} position="top" />
    </MenuProvider>



  );
}

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     alignItems: 'center',
//     justifyContent: 'center',
//   },
// });
