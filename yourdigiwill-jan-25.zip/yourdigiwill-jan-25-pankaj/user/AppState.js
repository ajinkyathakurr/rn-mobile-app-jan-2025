import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useState, useEffect } from "react";
import { AppContext } from "./AppContext";

export const AppState = ({ children }) => {
  const [token, setToken] = useState("");
  const [name, setName] = useState("");
  const [loading, setIsLoading] = useState(true);
  const [pin, setPin] = useState("");
  const [email, setEmail] = useState("");
  const [mobile_no, setMobile] = useState("");

  const getEmail = async () => {
    try {
      setIsLoading(true);
      const userEmail = await AsyncStorage.getItem("email");
      setEmail(userEmail || "");
    } finally {
      setIsLoading(false);
    }
  };

  const getMobile = async () => {
    const userMobile = await AsyncStorage.getItem("mobile_no");
    setMobile(userMobile || "");
  };

  const checkAuthStatus = async () => {
    setIsLoading(true);
    const storedToken = await AsyncStorage.getItem("token");
    const storedPin = await AsyncStorage.getItem("pin");
  
    setToken(storedToken || "");
    setPin(storedPin || "");
  
    setIsLoading(false);
  };


  useEffect(() => {
    checkAuthStatus();
    getMobile();
  }, []);

  const logout = async () => {
    await AsyncStorage.clear();
    setToken("");
    setName("");
    setEmail("");
    setMobile("");
    setPin("");
  };

  return (
    <AppContext.Provider
      value={{
        getEmail,
        logout,
        setMobile,
        loading,
        setIsLoading,
        token,
        setToken,
        name,
        setName,
        pin,
        setPin,
        email,
        setEmail,
        mobile_no,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
