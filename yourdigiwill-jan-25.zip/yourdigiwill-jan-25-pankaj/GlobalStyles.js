/* fonts */
export const FontFamily = {
  openSans: "Open Sans",
  roboto: "Roboto",
  inter: "Inter",
};
/* font sizes */
export const FontSize = {
  size_5xs: 11,
  size_4xs: 12,
  size_3xs: 13,
  size_2xs: 14,
  size_xs: 15,
  size_sm: 16,
  size_base: 17,
  size_lg: 22,
  size_xl: 24,
  size_2xl: 29,
};
/* Colors */
export const Color = {
  white: "#fff",
  gray_100: "#fefefe",
  gray_200: "#f7f7f7",
  gray_300: "#eff0f6",
  gray_400: "#99a1ab",
  gray_500: "#252836",
  gray_600: "#1f1d2b",
  brown: "#f73b71",
  black: "#000",
  turquoise_100: "#0cfebc",
  turquoise_200: "rgba(12, 254, 188, 0.9)",
};
/* Margins */
export const Margin = {
  m_md: 0,
};
/* border radiuses */
export const Border = {
  br_2xs: 2,
  br_xs: 3,
  br_sm: 3,
  br_md: 8,
  br_lg: 10,
  br_xl: 18,
};
