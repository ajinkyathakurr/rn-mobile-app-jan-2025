import React from 'react'
import { View, Text, TouchableOpacity } from 'react-native'
import { COLORS } from './colors'
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
} from 'react-native-popup-menu';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import { getWithAuthCall, postWithAuthCall } from '../../api/ApiServices';
import ApiConfig from '../../api/ApiConfig';
import { useNavigation } from '@react-navigation/native';
import { useState } from 'react';
import { useEffect } from 'react';



const ExpressWillTile = ({data,setLoading}) => {
    const navigation = useNavigation();
    const [bgcolor,seTbgcolor]=useState()
    const [status,setStatus]=useState('')
    useEffect(()=>{
        if(data.status=="In Progress")
        {
            getWithAuthCall(ApiConfig.E_SIGN_STATUS+`?express_will_id=${data.id}`).then((res)=>{
                setStatus(res.esign_status)
            })
        seTbgcolor("#466FFF")
        }
        else
        {
        seTbgcolor(COLORS.light_yello)
        }
        
       
    },[])
    const handleEditWill = (id) => {        
               
        if(data.status == "Draft"){            
            if(data.draft=="witness"){
                navigation.navigate("WitnessAndGuardians",{id:id})
            }
            else if(data.draft=="legal_doc"||data.draft=="legal_loc"||data.draft==null){
                navigation.navigate("ExpressOne",{id:id})
            }
            else if(data.draft=="distribution"){
                navigation.navigate("ExpressTwo",{id:id})
            }
            else if(data.draft=="speech"){
                navigation.navigate("SpecialDirectives",{id:id})
            }
            else if(data.draft=="executor"){
                navigation.navigate("Executor",{id:id})
            }
            else if(data.draft=="completed"){
                navigation.navigate("SpecialDirectives",{id:id})
            }
    }
}

    return (
        <TouchableOpacity onPress={()=>handleEditWill(data.id)}>
            <View style={{
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: 15,
                backgroundColor: COLORS.white,
                borderRadius: 10,
                marginTop: 10,
            }}>
                <View style={{
                    display: 'flex',
                    flexDirection: 'column'
                }}
                >
                    <Text style={{
                        color: COLORS.dark_grey,
                        fontSize: 20,
                        fontWeight: 'bold',
                    }}>{data.serial}</Text>
                    <Text style={{
                        marginTop: 5,
                        color: COLORS.dark_grey,
                        fontSize: 16,
                    }}>{data.created_at.split(" ")[0]}</Text>
                </View>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                }}
                ><View>
                    <Text style={{
                        color: COLORS.white,
                        fontSize: 15,
                        fontWeight: 'bold',
                        borderRadius: 5,
                        padding: 5,
                        backgroundColor: bgcolor,
                    }}>{data.status}</Text>
                    {(status)?<Text style={{color:COLORS.black,fontWeight:'bold'}}>status:0/3</Text>:<></> }                    
                </View>
                {(!status)? <Menu>
                        <MenuTrigger>
                            <MaterialIcons
                                name="more-vert"
                                size={24}
                                color="black"
                                style={{
                                    marginLeft: 10
                                }}
                            />
                        </MenuTrigger>
                        <MenuOptions style={{
                            backgroundColor: COLORS.white,
                            padding: 10,
                            borderRadius: 10,
                        }}>
                            <MenuOption onSelect={() => navigation.navigate("ExpressOne",{id:data.id})}>
                                <Text style={{ color: COLORS.dark_grey ,fontSize:15}}>Edit</Text>
                            </MenuOption>
                            <MenuOption onSelect={() => alert(`Download`)}>
                                <Text style={{ color: COLORS.dark_grey,fontSize:15 }}>Download</Text>
                            </MenuOption>
                            <MenuOption onSelect={() => alert(`Preview`)}>
                                <Text style={{ color: COLORS.dark_grey,fontSize:15 }}>Preview</Text>
                            </MenuOption>
                        </MenuOptions>
                    </Menu>:<></>}
                    
                   
                </View>
            </View>
        </TouchableOpacity>
    )
}

export default ExpressWillTile