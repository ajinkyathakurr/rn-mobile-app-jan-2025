import { StyleSheet, Text, View ,Button,Image,TouchableOpacity} from 'react-native';
import {HomeIcon} from '../../assets/image.png'

import LinearGradient from 'react-native-linear-gradient';
export default function Splash({navigation}) {
    // const [fontsLoaded] = useFonts({
    //     'System': require('../../assets/font/System.ttf'),
    //   });
    
    //   if (!fontsLoaded) {
    //     return null;
    //   }
    
  return (
    <View style={{flex:1}} >
     <View  style={styles.container}>
    
    <Image
      style={styles.cimage}
        source={require('../../assets/image.png')}
      />

    </View>
    <LinearGradient colors={['#00FFA3', '#22B07D']} style={styles.LinearGradient}>

<Text style={{fontFamily:'System',fontSize:30,color:'#FFFFFF',marginTop:20}}>Welcome To Digiwill</Text>
<Text  style={{fontFamily:'System',fontSize:16,color:'#FFFFFF'}}>Your one-stop solution for Financial
Inheritance</Text>
<Text  style={{fontFamily:'System',fontSize:16,color:'#FFFFFF'}}>
Inheritance</Text>
<TouchableOpacity
     onPress={()=>navigation.navigate('Signup')}
        style={{width:295,
          height:50,
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:'#FFFFFF',
        borderRadius:25,
        marginTop:10}}
        
      >
        <Text>Get Started</Text>
        
      </TouchableOpacity>
<Text  style={{fontFamily:'System',fontSize:16,color:'#FFFFFF',marginTop:10}}>
<Text>Already Member? </Text>
<TouchableOpacity
 onPress={()=>navigation.navigate('Login')}
 
>
    
<Text style={{fontFamily:'System',fontSize:18,color:'black'}} >
click here
</Text >

</TouchableOpacity>
</Text>
</LinearGradient>
    </View>


   

    
  );
}

 const styles = StyleSheet.create({
   container: {
    
     backgroundColor: '#1F1D2B',
     flex:0.7,
     alignItems:'center',
  
     
     
   },
   cimage:{
    width: 289,
    height: 287.61,
    marginTop:129 
    
    
    
   },
   LinearGradient:{
   flex:0.3,
   alignItems:'center',
   fontSize:30

   }
 });
