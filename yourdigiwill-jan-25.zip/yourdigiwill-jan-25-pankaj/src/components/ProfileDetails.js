import { StyleSheet, Text, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform,ScrollView, TextInput, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useContext, useEffect, useState } from 'react';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import { PostCallWithErrorResponse, postWithAuthCallWithErrorResponse } from '../../api/ApiServices';
import ApiConfig from '../../api/ApiConfig';
import Spinner from 'react-native-loading-spinner-overlay';
import { showMessage, hideMessage } from "react-native-flash-message";
import { COLORS } from './colors';
import { AppContext } from '../../user/AppContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

async function setName(value) {
  await AsyncStorage.setItem('name', value);
}
async function setMobile(value) {
  await AsyncStorage.setItem('mobile_no', value);
}
export default function ProfileDetails({navigation,route}) {

    const [loading,setLoading]=useState(false)
    //const {token}=route.params;
    const {token,email}=route.params;
    console.log("this is profile token....",token)
    const [data,setData]=useState({name:"",email:"",mobile_no:"",referral_code:"",equifax:true})
 

const handleReferrelSubmit = () =>{
setLoading(true)
  PostCallWithErrorResponse(ApiConfig.DIGIWILL_REFEREL_VERIFICATION , 
    {referral_code:data.referral_code,token:token}
    )
  .then((result) => {
    setLoading(false)
    if(result.json.status){
     
      showMessage({
        message: "Referrel code verified successfully",
        type: "success",
      });
    }
    else{
      showMessage({
        message: "Referrel code did not match",
        type: "danger",
      });
    }
  })
  .catch((error) => {
    showMessage({
      message: "Something went wrong",
      type: "danger",
    });
    console.log("api response", error);

  });

}

    const handleSubmit = ()=>{
      if(data.name==""){
        showMessage({
            message: "Please enter the Name",
            type: "danger",
          });
          return
      }
      
      if(data.mobile_no.length<10){
        showMessage({
            message: "Please enter the valid mobile number",
            type: "danger",
          });
          return
      }
       
        setLoading(true)
        PostCallWithErrorResponse(ApiConfig.DIGIWILL_USER_REGISTRATION , 
          {mobile_no:data.mobile_no.includes('+91') ? data.mobile_no : "+91"+data.mobile_no,email:email,name:data.name,equifax:data.equifax,referral_code:"",token:token}
          )
        .then((result) => {

          setLoading(false)
          console.log(result.json.result)
          if(result.json.result){
            console.log(data.name,data.email)
            setName(data.name)
            setMobile(data.mobile_no)

  showMessage({
    message: result.json.message,
    type: "success",
  });
  setTimeout(() => {
    navigation.navigate('Home',{name1:data.name})
  }, 1000);



         
          }
          else{
            showMessage({
              message: result.json.message,
              type: "danger",
            });

          }

         
       
        })
        .catch((error) => {
          showMessage({
            message: "Something went wrong",
            type: "danger",
          });
          console.log("api response", error);
    
        });
      }





  return (
  
  
  <KeyboardAvoidingView style={{flex:1}} behavior='padding'>
{
        
          <SafeAreaView style={styles.container}>
          <ScrollView style={{flex:1}}>
    
          
           <View style={styles.header}>
    
           <Text  style={{fontSize:22,color:'#FFFFFF',marginTop:10,paddingBottom:10,marginLeft:10,textAlign:'center',fontWeight:'bold'}}>
              Profile Details               </Text>
            
           </View>
{
  (loading) ? <Spinner color={COLORS.light_green}  visible={loading}/>:""
}
           
           <View>
            <Text style={{fontSize:25,fontWeight:'bold',color:COLORS.light_green_new,marginTop:30}}> Enter Your Name & Mobile</Text>
           </View>
           <View style={styles.body}>
            
           <TextInput
            style={styles.input}
            placeholder="FullName (as per Aasdhaar/PAN)"
            value={data.name}
            onChangeText = {(text)=>setData({...data,name:text})}
            placeholderTextColor="white" 
          />
          
    <TextInput
            style={styles.input}
            value={data.mobile_no}
            placeholder="Mobile Number"
            onChangeText = {(text)=>setData({...data,mobile_no:text})}
            keyboardType='numeric'
            placeholderTextColor="white" 
    
           
          />
            
    
    
    
   
           </View>
           {/* <View style={{flexDirection:'row',justifyContent:'space-between'}}>
        <TextInput
            style={styles.input2}
            value={data.referral_code}
            placeholder="Referral Code"
            onChangeText = {(text)=>setData({...data,referral_code:text})}
    
            placeholderTextColor={COLORS.light_green_new} 
    
           
          />
          
        <TouchableOpacity
        onPress={()=>handleReferrelSubmit()}
            style={{
            alignItems:'center',
            justifyContent:'center',
            
            marginTop:10,
            marginBottom:20
         }}
            
          >
            <Text  style={{fontSize:20,color:COLORS.light_green_new ,marginLeft:20,marginRight:20,marginTop:10,fontWeight:'bold'}}>Apply 

            </Text>
          </TouchableOpacity>
            </View>   */}
          
           </ScrollView>
           <TouchableOpacity
        onPress={()=>handleSubmit()}
            style={{width:Dimensions.get('window').width-32,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:COLORS.light_green_new,
            borderRadius:25,
            marginTop:10,
            marginBottom:20,
            marginLeft:16,
            marginRight:16
         
         }}
            
          >
            <Text  style={{fontSize:20,color:'black' }}>Continue 

            <AntDesign name="doubleright" size={20} marginLeft={3} color="black" />
            </Text>
          </TouchableOpacity>
       </SafeAreaView>

      } 


  
    
  </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
    container: {
     flex:1,
     backgroundColor:'black',
  
   
    },
    header:{
        flex:0.07,
        backgroundColor:COLORS.dark_grey,
      alignItems:'center'

    },
    body:{
        flex:0.4,
        backgroundColor:COLORS.dark_grey,
        marginTop:30,
        borderRadius:10,
       marginRight:10,
       marginLeft:10,
       alignItems:'center'
    },
    input:{
        backgroundColor:'black',
        width:305,
        height:60,
        marginBottom:20,
        marginTop:20,
        borderRadius:25,
        paddingLeft:10,
        fontSize:16,
        color:'white'
       



    },
    input2:{
        backgroundColor:'black',
      
        height:60,
        marginBottom:10,
        marginTop:20,
        borderRadius:10,
        paddingLeft:10,
        fontSize:16,
        color:'white',
        flex:230,
        marginLeft:30,
        borderColor:COLORS.light_green_new,
        borderWidth:2,
        borderStyle:'dotted'

    }
    
})
