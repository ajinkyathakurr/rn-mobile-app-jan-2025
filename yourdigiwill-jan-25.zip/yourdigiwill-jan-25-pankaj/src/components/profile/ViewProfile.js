import {
  StyleSheet,
  Modal,
  Text,
  TextInput,
  View,
  Button,
  Image,
  TouchableOpacity,
  TouchableHighlight,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import RBSheet from "react-native-raw-bottom-sheet";
import { useState, useRef, useEffect, useContext } from "react";
import {
  simpleGetCallWithErrorResponse,
  PostCallWithErrorResponse,
} from "../../../api/ApiServices.js";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";

import { COLORS } from "../colors";
import { ScrollView } from "react-native-gesture-handler";

import {
  showMessage,
 
} from "react-native-flash-message";

import { AppContext } from "../../../user/AppContext";

import ApiConfig from "../../../api/ApiConfig";
import Spinner from "react-native-loading-spinner-overlay";
import { useIsFocused } from "@react-navigation/native";
const relations = [
  "Father",
  "Mother",
  "Brother",
  "Sister",
  "Wife",
  "Brother-in-Law",
  "Father-in-Law",
  "Sister-in-Law",
  "Mother-in-Law",
  "Brother",
  "Sister",
  "Husband",
  "Son",
  "Daughter",
  "Friend",
  "Wife",
];

import VideoModal from "./VideoModal";

export default function ViewProfile({ navigation, route }) {
  const [loading, setLoading] = useState(false);
  const [state, setState] = useState([]);
  const { token } = useContext(AppContext);
  const [modal, showModal] = useState(false);
  const isfoused = useIsFocused();

 
  const [filepath, setfilePath] = useState("");

  
  const getProfile = () => {
    setLoading(true);
    simpleGetCallWithErrorResponse(ApiConfig.GET_PROFILE, { token: token })
      .then((data) => {
        if (data.json.result) {
          console.log(data);

          setState(data.json.data);

          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };
  
  const SendEmail = () => {
    setLoading(true);
    const formbody = new FormData();

    formbody.append("new_id", state.id);

    console.log(formbody);
    fetch(ApiConfig.SEND_EMAIL, {
      method: "POST",
      headers: {
        Authorization: `Token ${token}`,
      },
      body: formbody,
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (json) {
        console.log(json);
        setLoading(false);
        showMessage({
          message: json.message,
          type: "success",
        });
        navigation.navigate("Home");
      })
      .catch(function (error) {
        setTimeout(() => {
          setLoading(false);
          showMessage({
            message: json.message,
            type: "danger",
          });
        }, 1000);

        console.log(
          "There has been a problem with your fetch operation: " + error.message
        );

        throw error;
      });
  };
  useEffect(() => {
    getProfile();
  }, [isfoused]);

  return (
    <SafeAreaView style={{ height: "100%", backgroundColor: "#252836" }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <VideoModal modal={modal} showModal={showModal}/>
        <View>
          <TouchableOpacity onPress={() => navigation.navigate("Home")}>
            <AntDesign
              name="left"
              size={30}
              color="#FFFFFF"
              style={{ marginRight: 2 }}
            ></AntDesign>
          </TouchableOpacity>
        </View>
        <Text style={{ fontSize: 22, marginLeft: 30, color: "#FFFFFF" }}>
          View Profile
        </Text>
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            width: 80,
          }}
        >
          <TouchableOpacity
            onPress={() =>
              navigation.navigate("EditProfile", {
                name: state.legal_name,
                age: state.age,
                gender: state.gender,
                pan_no: state.pan_id,
                aadhar_no: state.national_id_card,
                image: state.profile_pic,
                id: state.user_address.id,
                state: state.user_address.state,
                city: state.user_address.city,
                address: state.user_address.name,
                marital_status: state.marital_status,
                dob: state.dob,
              })
            }
          >
            <FontAwesome
              name="edit"
              size={30}
              color={COLORS.light_green}
              style={{ marginRight: 10 }}
            ></FontAwesome>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              showModal(!modal);
            }}
          >
            <FontAwesome
              name="info-circle"
              size={30}
              color={COLORS.light_green}
              style={{ marginRight: 10 }}
            ></FontAwesome>
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ backgroundColor: "#252836", alignItems: "center" }}>
        <View>
          <Image
            source={{
              uri: filepath
                ? filepath
                : state.profile_pic != null
                ? state.profile_pic
                : "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/avatar.png",
            }}
            style={{ borderRadius: 50, width: 83, height: 83 }}
          ></Image>
        </View>
      </View>
      {state && state.length != 0 ? (
        <ScrollView>
          <View style={{ marginLeft: 20 }}>
            <Text
              style={{
                color: COLORS.light_green_new,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Full name
            </Text>
            <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
              {state.legal_name ? state.legal_name : "---------"}
            </Text>
          </View>
          <View style={{ marginLeft: 20, marginTop: 30 }}>
            <Text
              style={{
                color: COLORS.light_green_new,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Mobile number
            </Text>
            <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
              {state.mobile_no ? state.mobile_no : "---------"}
            </Text>
          </View>
          <View
            style={{
              marginLeft: 20,
              marginTop: 30,
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <View>
              <Text
                style={{
                  color: COLORS.light_green_new,
                  fontSize: 16,
                  fontWeight: "bold",
                }}
              >
                PAN number
              </Text>
              <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
                {state.pan_id ? state.pan_id : "---------"}
              </Text>
            </View>

            {(!state.pan_verified) ? (
               <TouchableOpacity onPress={()=>navigation.navigate("Settings",{openSheet:true})}>
              <View
                style={{
                  borderRadius: 20,
                  borderWidth: 1,
                  borderColor: COLORS.light_yello,
                  marginRight: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 15,
                    color: COLORS.light_yello,
                    margin: 3,
                    marginLeft: 5,
                    marginRight: 5,
                  }}
                >
                  Unverified
                </Text>
              </View>
              </TouchableOpacity>
            ) : (

              <View
                style={{
                  borderRadius: 20,
                  borderWidth: 1,
                  borderColor: COLORS.light_green_new,
                  marginRight: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    color: COLORS.light_green_new,
                    margin: 3,
                    marginLeft: 5,
                    marginRight: 5,
                  }}
                >
                  Verified
                </Text>
              </View>
            )}
          </View>
          <View
            style={{
              marginLeft: 20,
              marginTop: 30,
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <View>
              <Text
                style={{
                  color: COLORS.light_green_new,
                  fontSize: 16,
                  fontWeight: "bold",
                }}
              >
                Aadhar number
              </Text>
              <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
                {state.national_id_card ? state.national_id_card : "---------"}
              </Text>
            </View>

            {(!state.aadhar_verified) ? (
              <TouchableOpacity onPress={()=>navigation.navigate("Settings")}>
              <View
                style={{
                  borderRadius: 20,
                  borderWidth: 1,
                  borderColor: COLORS.light_yello,
                  marginRight: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 15,
                    color: COLORS.light_yello,
                    margin: 3,
                    marginLeft: 5,
                    marginRight: 5,
                  }}
                >
                  Unverified
                </Text>
              </View>
              </TouchableOpacity>
            ) : (
              <View
                style={{
                  borderRadius: 20,
                  borderWidth: 1,
                  borderColor: COLORS.light_green_new,
                  marginRight: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    color: COLORS.light_green_new,
                    margin: 3,
                    marginLeft: 5,
                    marginRight: 5,
                  }}
                >
                  Verified
                </Text>
              </View>
            )}
          </View>
          <View
            style={{
              marginLeft: 20,
              marginTop: 30,
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <View>
              <Text
                style={{
                  color: COLORS.light_green_new,
                  fontSize: 16,
                  fontWeight: "bold",
                }}
              >
                Email ID
              </Text>
              <Text style={{ color: "#FFFFFF", fontSize: 15, marginTop: 10 }}>
                {state.email ? state.email : "---------"}
              </Text>
            </View>

            {state.email && !state.email_verified ? (
              <TouchableOpacity onPress={() => SendEmail()}>
                <View
                  style={{
                    borderRadius: 20,
                    borderWidth: 1,
                    borderColor: COLORS.light_yello,
                    marginRight: 10,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 15,
                      color: COLORS.light_yello,
                      margin: 4,
                      marginLeft: 5,
                      marginRight: 5,
                    }}
                  >
                    Unverified
                  </Text>
                </View>
              </TouchableOpacity>
            ) : (
              <View
                style={{
                  borderRadius: 20,
                  borderWidth: 1,
                  borderColor: COLORS.light_green_new,
                  marginRight: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    color: COLORS.light_green_new,
                    margin: 3,
                    marginLeft: 5,
                    marginRight: 5,
                  }}
                >
                  Verified
                </Text>
              </View>
            )}
          </View>
          <View style={{ marginLeft: 20, marginTop: 30 }}>
            <Text
              style={{
                color: COLORS.light_green_new,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Gender
            </Text>
            <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
              {state.gender ? state.gender : "---------"}
            </Text>
          </View>
          <View style={{ marginLeft: 20, marginTop: 30 }}>
            <Text
              style={{
                color: COLORS.light_green_new,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Dob
            </Text>
            <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
              {state.dob ? state.dob : "---------"}
            </Text>
          </View>
          <View style={{ marginLeft: 20, marginTop: 30 }}>
            <Text
              style={{
                color: COLORS.light_green_new,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Age
            </Text>
            <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
              {state.age ? state.age : "---------"}
            </Text>
          </View>
          <View style={{ marginLeft: 20, marginTop: 30 }}>
            <Text
              style={{
                color: COLORS.light_green_new,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Marital Status
            </Text>
            <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
              {state.marital_status ? state.marital_status : "---------"}
            </Text>
          </View>
          <View style={{ marginLeft: 20, marginTop: 30 }}>
            <Text
              style={{
                color: COLORS.light_green_new,
                fontSize: 16,
                fontWeight: "bold",
              }}
            >
              Address
            </Text>
            <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
              {state.user_address.name ? state.user_address.name : "---------"}
            </Text>
          </View>
          <View style={{ flex: 1, flexDirection: "row" }}>
            <View style={{ marginLeft: 20, marginTop: 30 }}>
              <Text
                style={{
                  color: COLORS.light_green_new,
                  fontSize: 16,
                  fontWeight: "bold",
                }}
              >
                State
              </Text>
              <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
                {state.user_address.state
                  ? state.user_address.state
                  : "---------"}
              </Text>
            </View>
            <View style={{ marginLeft: 70, marginTop: 30 }}>
              <Text
                style={{
                  color: COLORS.light_green_new,
                  fontSize: 16,
                  fontWeight: "bold",
                }}
              >
                City
              </Text>
              <Text style={{ color: "#FFFFFF", fontSize: 18, marginTop: 10 }}>
                {state.user_address.city
                  ? state.user_address.city
                  : "---------"}
              </Text>
            </View>
          </View>
        </ScrollView>
      ) : (
        <Spinner color={COLORS.light_green} visible={loading} />
      )}
      
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 100,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
});
