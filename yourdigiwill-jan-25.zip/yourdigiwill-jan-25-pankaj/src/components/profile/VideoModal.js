import { Modal, Text, View ,TouchableOpacity} from "react-native";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { WebView } from "react-native-webview";
import { COLORS } from "../colors";
export default function VideoModal({modal,showModal,id}) {
  
  return (
    <Modal visible={modal} transparent={true} animationType="slide">
      <View style={{ width: 300, height: 400, margin: 45, marginTop: 200,backgroundColor:"#292e42",borderWidth:2,borderColor:COLORS.light_green,padding:10 ,borderRadius:20}}>
        <TouchableOpacity
        style={{marginLeft:250,marginBottom:10}}
          onPress={() => {
            showModal(!modal);
          }}
        >
          <FontAwesome name="close" size={25} color={COLORS.light_green}/>
        </TouchableOpacity>

        <WebView
          source={{
            uri: (id ?`https://www.youtube.com/embed/${id}?autoplay=1`:"https://www.youtube.com/embed/Apab5ekXBz8?autoplay=1"),
          }}
          style={{ flex: 1,borderRadius:20 }}
        />
      </View>
    </Modal>
  );
}
