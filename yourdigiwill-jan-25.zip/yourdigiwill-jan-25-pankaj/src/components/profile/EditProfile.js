import {
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Button,
  Image,
  TouchableOpacity,
  TouchableHighlight,
  Dimensions,
  KeyboardAvoidingView,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { SafeAreaView } from "react-native-safe-area-context";
import DatePicker from "react-native-date-picker";
import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";

import SelectDropdown from "react-native-select-dropdown";
import { COLORS } from "../colors";
import Enctypo from "react-native-vector-icons/Entypo";
import { showMessage, hideMessage } from "react-native-flash-message";
import RBSheet from "react-native-raw-bottom-sheet";
import Spinner from "react-native-loading-spinner-overlay/lib";
import ImagePicker from "react-native-image-crop-picker";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";

const relations = ["Male", "Female"];
const martial_status = ["Married", "UnMarried"];
const states = [
  "Andhra Pradesh",
  "Arunachal Pradesh",
  "Assam",
  "Bihar",
  "Chhattisgarh",
  "Goa",
  "Gujarat",
  "Haryana",
  "Himachal Pradesh",
  "Jammu and Kashmir",
  "Jharkhand",
  "Karnataka",
  "Kerala",
  "Madhya Pradesh",
  "Maharashtra",
  "Manipur",
  "Meghalaya",
  "Mizoram",
  "Nagaland",
  "Odisha",
  "Punjab",
  "Rajasthan",
  "Sikkim",
  "Tamil Nadu",
  "Telangana",
  "Tripura",
  "Uttarakhand",
  "Uttar Pradesh",
  "West Bengal",
  "Andaman and Nicobar Islands",
  "Chandigarh",
  "Dadra and Nagar Haveli",
  "Daman and Diu",
  "Delhi",
  "Lakshadweep",
  "Puducherry",
];
async function setEmail(value) {
  await AsyncStorage.setItem("email", value);
}
async function setName(value) {
  await AsyncStorage.setItem("name", value);
}

export default function EditProfile({ navigation, route }) {
  const [loading, setLoading] = useState(false);
  const { token } = useContext(AppContext);
  const [date, setDate] = useState(new Date().setDate(18));
  const [filepath, setfilePath] = useState("");
  const [open, setOpen] = useState(false);
  const bottomsheet = useRef();
  const {
    name,
    age,
    gender,
    pan_no,
    aadhar_no,
    image,
    id,
    state,
    city,
    address,
    marital_status,
    dob,
  } = route.params;
  const [data, setData] = useState({
    name: name,
    age: age,
    pan_no: pan_no,
    aadhar_no: aadhar_no,
    image: image,
    gender: gender,
    id: id ? id : "",
    state: state,
    city: city,
    address: address,
    marital_status: marital_status,
    dob: dob && dob ? new Date(dob) : null,
  });

  const [historydate, setHistorydate] = useState(new Date());
  const [doc, setDoc] = useState("");

  const handleDocChange = (selectedItem) => {
    setDoc(selectedItem);
  };

  const handleImagePick = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      compressImageQuality: 0.5,

      cropping: true,
    }).then((image) => {
      setfilePath(image.path);
      console.log(image);
    });
  };
  const handleSubmit = async () => {
    if (data.aadhar_no == "") {
      showMessage({
        message: "Please Enter Aadhar Number",
        type: "danger",
      });
      return;
    }
    if (data.pan_no == "") {
      showMessage({
        message: "Please Enter PAN",
        type: "danger",
      });
      return;
    }
    if (data.dob == "") {
      showMessage({
        message: "Please Enter Date of Birth",
        type: "danger",
      });
      return;
    }

    setLoading(true);
    const formbody = new FormData();
    if (filepath) {
      formbody.append("profile_pic", {
        uri: filepath,
        name: "photo.jpeg",
        filename: "imageName.png",
        type: "image/jpeg",
      });
    }

    formbody.append("name", data.name);
    formbody.append("email", data.email);
    formbody.append("mobile_no", data.mobile_no);
    formbody.append("relationship", data.relationship);
    formbody.append("age", data.age);
    if (id) {
      formbody.append("id", data.id);
      console.log(data.id);
    }
    formbody.append("gender", data.gender);
    formbody.append("address_name", data.address);
    formbody.append("state", data.state);
    formbody.append("city", data.city);
    formbody.append("marital_status", data.marital_status);
    formbody.append("NationalIDCard", data.aadhar_no);
    formbody.append("PANId", data.pan_no);
    formbody.append(
      "dob",
      !data.dob
        ? ""
        : data.dob.getFullYear() +
            "-" +
            (data.dob.getMonth() + 1) +
            "-" +
            data.dob.getDate()
    );

    console.log(token);
    console.log(formbody);

    fetch(ApiConfig.GET_PROFILE, {
      method: "put",
      headers: {
        Authorization: `Token ${token}`,
      },
      body: formbody,
    })
      .then(async function (response) {
        setLoading(false);
        if (data.email) setEmail(data.email);
        if (data.name) setName(data.name);
        const res = await response.json();
        console.log(res);
        navigation.navigate("Home");
        return res;
      })
      .catch(function (error) {
        console.log(
          "There has been a problem with your fetch operation: " + error.message
        );
       
        setLoading(false);

        navigation.navigate("EditProfile");
        throw error;
      });
  };

  return (
    <KeyboardAvoidingView
      style={{
        height: "100%",
        backgroundColor: "#252836",
        alignItems: "center",
      }}
      behavior="height"
    >
      <SafeAreaView>
        <View
          style={{
            backgroundColor: "#252836",
            height: 50,
            alignItems: "center",
            justifyContent: "space-between",
            flexDirection: "row",
            marginLeft: 5,
            marginRight: 5,
          }}
        >
          <TouchableOpacity onPress={() => navigation.navigate("ViewProfile")}>
            <AntDesign
              name="left"
              size={30}
              color="#FFFFFF"
              style={{ marginRight: 2 }}
            ></AntDesign>
          </TouchableOpacity>
          <Text style={{ fontSize: 22, color: "#FFFFFF" }}>Update Profile</Text>

          <View></View>
        </View>
        {loading ? <Spinner visible={loading} /> : <></>}

        <SafeAreaView style={{ flex: 1 }}>
          <ScrollView
            style={styles.container}
            showsVerticalScrollIndicator={false}
          >
            <TouchableOpacity
              onPress={() => handleImagePick()}
              style={{
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "row",
              }}
            >
              <Image
                source={{
                  uri: filepath
                    ? filepath
                    : image != null
                    ? image
                    : "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/avatar.png",
                }}
                style={{ borderRadius: 50, width: 83, height: 83 }}
              ></Image>
              <Image
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Group+26967.png",
                }}
                style={{
                  marginTop: 44,
                  marginLeft: -17,
                  color: COLORS.light_green,
                  height: 25,
                  width: 25,
                }}
              ></Image>

             
            </TouchableOpacity>
            <TextInput
              style={styles.input2}
              value={data.name}
              placeholder="Name"
              onChangeText={(text) => setData({ ...data, name: text })}
              placeholderTextColor="#8A8D9F"
            />
            <Text
              style={{
                color: COLORS.light_yello,
                fontSize: 13,
                marginLeft: 30,
              }}
            >
              As per Adhar / PAN
            </Text>

            <SelectDropdown
              data={relations}
              defaultValue={data.gender}
              buttonStyle={styles.dropDownstyle}
              onSelect={(selectedItem, index) => {
                setData({ ...data, gender: selectedItem });
                console.log(selectedItem, index);
              }}
             
              rowStyle={{ backgroundColor: "black" }}
              defaultButtonText="Select Gender"
              placeholderTextColor="#8A8D9F"
              dropdownIconPosition="left"
              rowTextStyle={{ color: "#FFFFFF" }}
              buttonTextStyle={styles.buttonTextStyle}
              buttonTextAfterSelection={(selectedItem, index) => {
                
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
               
                return item;
              }}
            />

            <TextInput
              style={styles.input}
              value={data.pan_no}
              editable={pan_no == "" ? true : false}
              placeholder="Pan Number"
              onChangeText={(text) => setData({ ...data, pan_no: text })}
              placeholderTextColor="#8A8D9F"
            />
            <TextInput
              style={styles.input}
              value={data.aadhar_no}
              editable={aadhar_no == "" ? true : false}
              placeholder="Aadhar Number"
              onChangeText={(text) => setData({ ...data, aadhar_no: text })}
              placeholderTextColor="#8A8D9F"
            />

            <TextInput
              style={styles.input}
              value={data.address}
              placeholder="Address"
              onChangeText={(text) => setData({ ...data, address: text })}
              placeholderTextColor="#8A8D9F"
            />

            <TextInput
              style={styles.input}
              value={data.age}
              placeholder="Age"
              onChangeText={(text) => setData({ ...data, age: text })}
              placeholderTextColor="#8A8D9F"
            />
            <SelectDropdown
              data={martial_status}
              defaultValue={data.marital_status}
              buttonStyle={styles.dropDownstyle}
              onSelect={(selectedItem, index) => {
                setData({ ...data, marital_status: selectedItem });
                console.log(selectedItem, index);
              }}
              
              rowStyle={{ backgroundColor: "black" }}
              defaultButtonText="Martial Status"
              dropdownIconPosition="left"
              rowTextStyle={{ color: "#FFFFFF" }}
              buttonTextStyle={styles.buttonTextStyle}
              buttonTextAfterSelection={(selectedItem, index) => {
              
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
                
                return item;
              }}
            />

            <SelectDropdown
              data={states}
              defaultValue={data.state ? data.state : ""}
              buttonStyle={styles.dropDownstyle}
              onSelect={(selectedItem, index) => {
                setData({ ...data, state: selectedItem });
                console.log(selectedItem, index);
              }}
              
              rowStyle={{ backgroundColor: "black" }}
              defaultButtonText="Select State"
              dropdownIconPosition="left"
              rowTextStyle={{ color: "#FFFFFF" }}
              buttonTextStyle={styles.buttonTextStyle}
              buttonTextAfterSelection={(selectedItem, index) => {
             
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
               
                return item;
              }}
            />

            <TouchableOpacity
              style={styles.input}
              onPress={() => setOpen(true)}
            >
              <Text
                style={{
                  fontSize: 16,
                  color: "#FFF",
                  marginTop: 10,
                  paddingBottom: 10,
                }}
              >
                {data.dob
                  ? data.dob.getFullYear() +
                    "-" +
                    (data.dob.getMonth() + 1) +
                    "-" +
                    data.dob.getDate()
                  : "Birth Date"}
              </Text>
            </TouchableOpacity>
            <DatePicker
              modal
              mode="date"
              open={open}
              minimumDate={new Date("1930-12-31")}
              maximumDate={new Date("2013-12-31")}
              date={data.dob ? data.dob : historydate}
              onConfirm={(date) => {
                setOpen(false);
                setData({ ...data, dob: date });
              }}
              onCancel={() => {
                setOpen(false);
              }}
            />

            <TextInput
              style={styles.input}
              value={data.city}
              placeholder="City"
              onChangeText={(text) => setData({ ...data, city: text })}
              placeholderTextColor="#FFFFFF"
            />

            <TouchableOpacity
              onPress={() => handleSubmit()}
              style={{
                width: 320,
                height: 45,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: COLORS.light_yello,
                borderRadius: 25,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 16, color: "black" }}>
                Update
                <AntDesign
                  name="doubleright"
                  size={13}
                  marginLeft={3}
                  color="black"
                />
              </Text>
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}
const styles = StyleSheet.create({
  header: {
    height: 100,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  input: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  input3: {
    backgroundColor: "black",
    width: 240,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  input2: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 5,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  buttonTextStyle: {
    color: "#FFFFFF",
    marginLeft: 0,
    fontSize: 16,
    textAlign: "left",
  },
  dropDownstyle: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    textAlign: "left",
  },
  frequencyinput: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    marginLeft: 10,
  },
});
