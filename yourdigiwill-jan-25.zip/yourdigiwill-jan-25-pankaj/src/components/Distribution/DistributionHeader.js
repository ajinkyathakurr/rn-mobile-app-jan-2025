import React from 'react'
import { StyleSheet, Text, View ,Button,Image,TouchableOpacity, SafeAreaView} from 'react-native';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
const DistributionHeader = ({navigation}) => {
  return (
<SafeAreaView  style={{marginBottom:20}}>
        <View style={{ backgroundColor: "#252836",marginTop:10,height:50,alignItems:'center',justifyContent:'space-between',flexDirection:'row'}}>
        <TouchableOpacity onPress={() => navigation.navigate("Home")}>
<AntDesign name='left' size={30} color='#FFFFFF' style={{marginRight:2,marginLeft:3}}></AntDesign>
</TouchableOpacity>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
   Distributions
        </Text>
        <View></View>
 
        </View>


        <View style={{ backgroundColor: "#252836",marginTop:10,height:50,justifyContent:'space-between',flexDirection:'row',alignItems:'center'}}>
        <Text
          style={{  fontSize: 16, color: "#FFFFFF" ,marginLeft:10}}
        >
   Asset
        </Text>
        <Text
          style={{  fontSize: 16, color: "#FFFFFF" ,marginLeft:10}}
        >
   Nominee
        </Text>
        <Text
          style={{  fontSize: 16, color: "#FFFFFF" ,marginRight:10}}
        >
   Distribution %
        </Text>
 
        </View>

        </SafeAreaView>

  )
}

export default DistributionHeader