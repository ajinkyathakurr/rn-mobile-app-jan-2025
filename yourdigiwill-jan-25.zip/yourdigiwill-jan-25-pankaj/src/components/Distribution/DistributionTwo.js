import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  TextInput,
  KeyboardAvoidingView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../../api/ApiServices";
import ApiConfig from "../../../api/ApiConfig";
import { AppContext } from "../../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay/lib";
import CheckBox from "react-native-check-box";
import { COLORS } from "../colors";
import AntDesign from "react-native-vector-icons/AntDesign";
import { useIsFocused } from "@react-navigation/native";
import { showMessage } from "react-native-flash-message";

export default function DistributionTwo({
  color,
  text,
  path,
  navigation,
  route,
}) {
  const { asset_name, asset_id } = route.params;

  const [active, setActive] = useState("shared_by_me");
  const [nominees, setNominees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectednominees, setselectedsetNominees] = useState([]);
  const { token } = useContext(AppContext);
  const [percentage, setPercentage] = useState([]);

  const getNominees = () => {
    console.log(asset_id);
    simpleGetCallWithErrorResponse(
      ApiConfig.GET_DISTRIBUTION_NOMINEE + `?asset_id=${asset_id}`,
      { token: token }
    )
      .then((data) => {
        if (data) {
          console.log(data);

          console.log("hiii");
          var arr = [];
          for (var i = 0; i < data.json.data.length; i++) {
            console.log("json data", data.json.data[i]);
            if (data.json.data[i].percentage != 0) {
              var nominee_id = data.json.data[i].nominee.id;
              console.log(nominee_id);
              var per = data.json.data[i].percentage;
              arr.push({ id: nominee_id, percent: per });
            }
            setPercentage([...percentage, ...arr]);
          }
          setNominees(data.json.data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const handleTextboxChange = (text, nominee_id) => {
    if (Number(text) > 100) {
      showMessage({
        message: "Percentage should be less than or equal to 100%",
        type: "warning",
      });
    }
    if (text != "") {
      if (percentage) {
        for (var i = 0; i < percentage.length; i++) {
          console.log(percentage[i]);
          if (nominee_id == percentage[i].id) {
            var array = [...percentage]; // make a separate copy of the array
            var index = array.indexOf(array[i]);
            if (index !== -1) {
              array.splice(index, 1);
              setPercentage(array);
            }
          }
        }
      }

      setPercentage([...percentage, { id: nominee_id, percent: text }]);
    }

    console.log(percentage);
  };

  const submitNominees = () => {
    setLoading(true);

    setTimeout(() => {
      
      PostCallWithErrorResponse(ApiConfig.ADD_DISTRIBUTION, {
        token: token,
        asset_id: asset_id,
        distribution: percentage,
      })
        .then((result) => {
          console.log(result);
          if (result) {
            setLoading(false)
            navigation.navigate("DistributionOne");
          }
        })
        .catch((error) => {
          console.log("api response", error);
        });
    }, 200);
  };

  useEffect(() => {
    getNominees();
  }, []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.light_grey }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
        <View>
          <View
            style={{
              
              flexDirection:"row",
              height: 50,
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <TouchableOpacity onPress={()=>{navigation.navigate("DistributionOne")}}>
              <AntDesign name="left" color={COLORS.white} style={{marginLeft:10}} size={30}/>
            </TouchableOpacity>
            <Text style={{ fontSize: 22, color: "#FFFFFF" }}>{asset_name}</Text>
            <View></View>
          </View>

          <View>
            <Text
              style={{
                fontSize: 20,
                color: "#FFFFFF",
                marginLeft: 10,
                marginTop: 20,
              }}
            >
              Select assign distribution percentage (%) to nominees below
            </Text>
          </View>

          <ScrollView>
            {nominees.length != 0 ? (
              nominees.map((single) => {
                return (
                  <View key={single.id} style={{ flexDirection: "row" }}>
                    <View
                      style={{
                        flex: 0.7,
                        backgroundColor: "#1F1D2B",
                        height: 70,
                        marginLeft: 16,
                        marginRight: 16,
                        marginTop: 10,
                        borderRadius: 10,
                        alignItems: "center",
                        justifyContent: "space-between",

                        flexDirection: "row",
                      }}
                    >
                      <View>
                        <View
                          style={{
                            width: 40,
                            height: 40,
                            borderColor: COLORS.light_green,
                            borderWidth: 1,
                            borderRadius: 50,
                            alignItems: "center",
                            marginLeft: 10,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 22,
                              color: "#FFFFFF",
                              marginTop:5
                            }}
                          >
                            {single.nominee.name[0]}
                          </Text>
                        </View>
                      </View>
                      <Text
                        style={{
                          fontSize: 17,
                          color: "#FFFFFF",
                        }}
                      >
                        {single.nominee.name}
                      </Text>
                      <View>
                        {/* <CheckBox
          style={{marginRight:5}}
          isChecked={selectednominees.indexOf(single.nominee.id) > -1 ? true : false}
          onClick={()=> { selectednominees.indexOf(single.nominee.id) > -1? setselectedsetNominees(selectednominees.filter((value)=>value!=single.nominee.id)): setselectedsetNominees(  [...selectednominees,single.nominee.id]) ;console.log(selectednominees)  }}
          // color={true ? '#0CFEBC' : undefined}
          checkBoxColor="#0CFEBC"
        /> */}
                      </View>
                    </View>

                    <View
                      style={{
                        flex: 0.3,
                        backgroundColor: "#1F1D2B",
                        height: 70,

                        marginRight: 16,
                        marginTop: 10,
                        borderRadius: 10,
                        alignItems: "center",
                        justifyContent: "center",
                        flexDirection: "row",
                      }}
                    >
                      <TextInput
                        value={single.percentage}
                        defaultValue={`${single.percentage}`}
                        placeholder={`${single.percentage}`}
                        onChangeText={(text) =>
                          handleTextboxChange(text, single.nominee.id)
                        }
                        style={{ color: "#FFFFFF", fontSize: 20 }}
                        placeholderTextColor="#8A8D9F"
                        keyboardType="numeric"
                      />
                    </View>
                  </View>
                );
              })
            ) : (
              <Spinner visible={loading} />
            )}
          </ScrollView>
        </View>

        <TouchableOpacity
          onPress={() => submitNominees()}
          style={{
            alignItems: "center",
            width: 60,
            position: "absolute",
            bottom: 30,
            right: 20,
            height: 60,
            color: "#FFFFFF",
            borderRadius: 50,
            justifyContent: "center",
            backgroundColor: "#FFBF35",
          }}
        >
          <AntDesign name="arrowright" size={24} color="black" />
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  toggleParent: {
    flexDirection: "row",
    backgroundColor: "black",
    justifyContent: "center",
    alignSelf: "center",
    borderRadius: 25,
    marginTop: 10,
    height: 37,
    borderColor: "#0CFEBC",
    borderWidth: 1,
  },
  header: {
    flex: 1,
  },
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
