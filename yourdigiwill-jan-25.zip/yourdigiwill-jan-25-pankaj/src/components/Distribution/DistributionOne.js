import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";

import { SafeAreaView } from "react-native-safe-area-context";

import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import DistributionHeader from "./DistributionHeader";
import { simpleGetCallWithErrorResponse } from "../../../api/ApiServices";
import ApiConfig from "../../../api/ApiConfig";
import { AppContext } from "../../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { COLORS } from "../colors";
import { useIsFocused } from "@react-navigation/native";
import Entypo from "react-native-vector-icons/Entypo";
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from "react-native-popup-menu";
export default function DistributionOne({ navigation }) {
  const [state, setState] = useState([]);
  const { token } = useContext(AppContext);
  const [percentage, setPercentage] = [];
  const isFocused = useIsFocused();
  const [loading, setLoading] = useState(true);

  const MenuFunction = (asset_name, asset_id) => {
    navigation.navigate("DistributionTwo", {
      asset_name: asset_name,
      asset_id: asset_id,
    });
  };

  useEffect(() => {
    setLoading(true);
    getAllDistribution();
  }, [isFocused]);

  const getAllDistribution = () => {
    console.log(token);
    console.log("hello");

    simpleGetCallWithErrorResponse(ApiConfig.GET_DISTRIBUTION, { token: token })
      .then((data) => {
        if (data) {
          console.log(data);
          setState(data.json);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <DistributionHeader navigation={navigation} />
      {loading ? (
        <Spinner color={COLORS.light_green} visible={loading}></Spinner>
      ) : (
        <ScrollView>
          {state && state.length != 0 ? (
            state.map((single) => {
              return (
                <>
                  <View key={single.distribution.asset_id} style={{ backgroundColor: "#252836" }}>
                    <Text
                      style={{
                        color: COLORS.light_yello,
                        fontSize: 22,
                        margin: 20,
                      }}
                    >
                      {single.category.category_name}
                    </Text>
                    {single.distribution.map((single_child1) => {
                      return (
                        <View
                          style={{
                            backgroundColor:
                              single_child1.total_distribution == "100"
                                ? ""
                                : COLORS.light_red,
                          }}
                        >
                          {single_child1.total_distribution != "100" ? (
                            <Text
                              style={{ color: "red", fontSize: 16, margin: 20 }}
                            >
                              {single_child1.remaining_distribution} % undefined
                            </Text>
                          ) : (
                            ""
                          )}
                          <View
                            style={{
                              flexDirection: "row",
                              justifyContent: "space-between",
                              marginLeft: 15,
                              marginRight: 15,
                            }}
                          >
                            <Text style={{ color: "white" ,width:100,marginBottom:5}}>
                              {single_child1.asset_name}
                            </Text>
                            <View>
                              {single_child1.nominees
                                ? single_child1.nominees.map(
                                    (single_child2) => {
                                      return (
                                        <View
                                          style={{ flexDirection: "column" }}
                                        >
                                          <Text
                                            style={{
                                              color: "white",
                                              marginBottom: 25,
                                            }}
                                          >
                                            {single_child2.nominee_name}
                                          </Text>
                                        </View>
                                      );
                                    }
                                  )
                                : ""}
                            </View>
                            <View>
                              {single_child1.nominees
                                ? single_child1.nominees.map(
                                    (single_child2) => {
                                      return (
                                        <View
                                          style={{ flexDirection: "column" }}
                                        >
                                          <Text
                                            style={{
                                              color: "white",
                                              marginBottom: 25,
                                            }}
                                          >
                                            {
                                              single_child2.distribution_percentage
                                            }{" "}
                                            %
                                          </Text>
                                        </View>
                                      );
                                    }
                                  )
                                : ""}
                            </View>

                            <View>
                              {single_child1.nominees
                                ? single_child1.nominees.map(
                                    (single_child2) => {
                                      return (
                                        <View style={{ marginBottom: 25 }}>
                                          <Menu>
                                            <MenuTrigger>
                                              <Entypo
                                                name="dots-three-vertical"
                                                size={22}
                                                color="#FFFFFF"
                                              />
                                            </MenuTrigger>

                                            <MenuOptions>
                                              <MenuOption
                                                onSelect={() =>
                                                  MenuFunction(
                                                    single_child1.asset_name,
                                                    single_child1.asset_id
                                                  )
                                                }
                                                text="Modify Distribution %"
                                              />
                                            </MenuOptions>
                                          </Menu>
                                        </View>
                                      );
                                    }
                                  )
                                : ""}
                            </View>
                          </View>
                          {single_child1.total_distribution == "100" ? (
                            ""
                          ) : (
                            <View style={{ alignItems: "center" }}>
                              <TouchableOpacity
                                onPress={() =>
                                  navigation.navigate("DistributionTwo", {
                                    asset_name: single_child1.asset_name,
                                    asset_id: single_child1.asset_id,
                                  })
                                }
                                style={{
                                  width: 90,
                                  height: 35,
                                  alignItems: "center",
                                  justifyContent: "center",
                                  backgroundColor: "#0CFEBC",
                                  borderRadius: 25,
                                  marginTop: 10,
                                  marginBottom: 20,
                                }}
                              >
                                <Text style={{ fontSize: 16, color: "black" }}>
                                  Select
                                </Text>
                              </TouchableOpacity>
                            </View>
                          )}
                        </View>
                      );
                    })}
                    <View></View>
                  </View>
                </>
              );
            })
          ) : (
            <View
              style={{
                alignItems: "center",
                justifyContent: "center",
                alignItems: "center",
                justifyContent: "center",
                marginTop: 150,
              }}
            >
              <TouchableOpacity
                onPress={() => navigation.navigate("Home")}
                style={{
                  width: 91,
                  height: 91,
                  borderRadius: 50,
                  color: "#FFFFFF",
                  marginRight: 21,
                  alignItems: "center",
                  justifyContent: "center",
                  marginTop: 10,
                  backgroundColor: "#252836",
                }}
              >
                <Image
                  style={styles.rndImage}
                  source={require("../../../assets/sharenow.png")}
                />
              </TouchableOpacity>
              <Text
                style={{
                  fontSize: 21,
                  color: "#FFFFFF",
                  marginTop: 5,
                  paddingBottom: 10,
                }}
              >
                Start Adding Assets Now!
              </Text>
            </View>
          )}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  header: {
    height: 100,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
