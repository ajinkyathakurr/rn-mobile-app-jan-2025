import { StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import LinearGradient from 'react-native-linear-gradient';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import { simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';

export default function Emptysubscription({navigation}) {


  return (
    <View
    style={{backgroundColor:'black',height:'100%',alignItems:'center',marginTop:50}}

  >

        <View>
            <Image source={{uri:'https://d2x7e1xt27q73s.cloudfront.net/clipart352614+1.png'}} style={{height:200,width:190}}>

            </Image>
        </View>
        <Text
        style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
You dont have any Active 
Subscriptions
        </Text>

        <TouchableOpacity
         onPress={()=>navigation.navigate('EnsuranceNewOne')}
            style={{width:Dimensions.get('screen').width-32,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#FFB721',
            borderRadius:25,
            marginTop:30,
            marginBottom:20,
            marginLeft:16
           
         }}
            
          >
            <Text  style={{fontSize:16,color:'#FFFFFF' }}>Take me to Ensurance Plan

            {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
            </Text>
          </TouchableOpacity>



  </View>
  )
}
const styles = StyleSheet.create({


  header:{
    height:100,
    flexDirection:'row',alignItems:'center',justifyContent:'space-between'

  }
  
  })