import {ScrollView, StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import {useState,useRef,useEffect,useContext} from 'react'
import LinearGradient from 'react-native-linear-gradient';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import { DeleteCallWithErrorResponse, simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import { AppContext } from '../../../user/AppContext';
import Emptysubscription from './Emptysubscription';
import Spinner from 'react-native-loading-spinner-overlay/lib';
import { COLORS } from '../colors';
import  Entypo  from "react-native-vector-icons/Entypo";

import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from 'react-native-popup-menu';
import { showMessage, hideMessage } from "react-native-flash-message";
import ReactNativeBiometrics, { BiometryTypes } from 'react-native-biometrics'
const rnBiometrics = new ReactNativeBiometrics()
export default function SubscriptionOne({navigation,route}) {
    const {plan_name,id} =route.params;
const [state,setState]=useState([])
const {token}=useContext(AppContext)
const [loading,setLoading]=useState(true)
    
const MenuFunction = (nominee_id,order_id)=>{

  if(state.nominees_data.length==1){
    showMessage({
      message: "You can't delete all nominees",
      type: "danger",
    });
    return 
  }


  rnBiometrics.simplePrompt({promptMessage: 'Confirm fingerprint'})
  .then((resultObject) => {
    const { success } = resultObject

    if (success) {
      console.log('successful biometrics provided')
      DeleteCallWithErrorResponse(ApiConfig.DIGIWILL_REMOVE_NOMINEE_FROM_ENSURANCE , 
        {
          nominee_id:nominee_id,
          order_id:order_id,
          token:token
      }
           )
         .then((result) => {
           console.log(result)
           if (result.json.result) {
            showMessage({
              message: "Nominee Removed Successfully",
              type: "success",
            });
            getAllSubscription()
    
           }
         })
         .catch((error) => {
           console.log("api response", error);
       
         });
    } else {
      console.log('user cancelled biometric prompt')
    }
  })
  .catch(() => {
    console.log('biometrics failed')
  })



 



}
useEffect(()=>{

        getAllSubscription()
        
        },[])
  const getAllSubscription = ()=>{
      console.log(id)
  
    simpleGetCallWithErrorResponse(ApiConfig.GET_SUBSCRIPTION_DETAIL + `?id=${id}`,{token:token})
      .then((data) => {
          
        if (data) {
            console.log(data)
            setState(data.json)
        setLoading(false)
        }
        setLoading(false)
      })
      .catch((error) => {
        console.log("api response", error);
  
      });
  
  }
  









  return (
    <View
    style={{backgroundColor:'black',height:'100%'}}

  >

<View style={{ backgroundColor: "#252836",marginTop:40,height:50,alignItems:'center',justifyContent:'center'}}>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
   {plan_name}
        </Text>

 
        </View>

        {

loading ? <Spinner color={COLORS.light_green} visible={loading}/>:
(

<>
          <View style={{justifyContent:'space-between',backgroundColor:COLORS.light_grey,marginTop:20,borderRadius:10,marginLeft:15,marginRight:15}}>
          <View style={styles.header}>
        
                  <View>
                  <Text
                   style={{  fontSize: 22, color: "#0CFEBC" ,marginLeft:10}}
                  >
                      {plan_name}        </Text>
  
                  </View>
  
  
            
          </View>
                  <View>
                  <Text
                   style={{   color: "#FFFFFF" ,marginLeft:10,marginBottom:20}}
                  >
                     Expiry Date:  {state.order_data.expiry_date}        </Text>
  

                  </View >

  
          </View>
          <View>
          <ScrollView style={styles.body}>
        {
          state.nominees_data.map((single)=>{
return (
  <TouchableOpacity
// onPress={()=>navigation.navigate('NomineeDetails',{name:single.name,email:single.email,mobile_no:single.mobile_no,age:single.age,relationship:single.relationship,address:single.address,gender:single.gender,incomplete_data:single.incomplete_data,kyc_completed:single.kyc_completed,image:single.image})}

  style={{
    width: Dimensions.get("screen").width - 32,
    backgroundColor: "#1F1D2B",
    height: 70,
    marginLeft: 16,
    marginRight: 16,
    marginTop: 10,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "space-between",
    flex: 1,
    flexDirection: "row",
  }}
>
<View style={{flexDirection:"row",alignItems:'center'}}>
<View
  
  style={{
    width:40,
    height:40,
    borderColor:COLORS.light_green,
    borderWidth:1,
    borderRadius:50,
    alignItems:"center",
    marginLeft:10,

  }}
  >
    <Text
      style={{
        
        fontSize: 22,
        color: "#FFFFFF",
       
      }}
    >

{single.name[0]}
    </Text>
  </View>
  <Text
    style={{
      
      fontSize: 17,
      color: "#FFFFFF",
      marginLeft:10
    }}
  >
    {single.name}
  </Text>
</View>
<View>

<Menu>

   
<MenuTrigger >
<Entypo name="dots-three-vertical" size={22} color="#FFFFFF" /> 

</MenuTrigger>


<MenuOptions>
<MenuOption onSelect={() => MenuFunction(single.id,state.order_data.id)} text='Delete' />

</MenuOptions>
</Menu>
</View>
  
</TouchableOpacity>
)


          })
        }
      

      </ScrollView>
          </View>

       </>   
          
)

  




        }
        
  



  </View>
  )
}
const styles = StyleSheet.create({


  header:{
    height:50,
    flexDirection:'row',alignItems:'center',justifyContent:'space-between'

  }
  
  })