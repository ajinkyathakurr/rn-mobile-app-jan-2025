import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../../api/ApiServices";
import ApiConfig from "../../../api/ApiConfig";
import { AppContext } from "../../../user/AppContext";
import Emptysubscription from "./Emptysubscription";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { COLORS } from "../colors";
import { showMessage } from "react-native-flash-message";

export default function Subscriptionlist({ navigation }) {
  const [state, setState] = useState([]);
  const { token } = useContext(AppContext);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    getAllSubscription();
  }, []);
  const getAllSubscription = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_SUBSCRIPTION, {
      token: token,
    })
      .then((data) => {
        if (data) {
          console.log(data);
          setState(data.json.data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const getInvoice = (order_id) => {
    setLoading(true);
    PostCallWithErrorResponse(ApiConfig.DOWNLOAD_INVOICE, {
      order_id: order_id,
      token: token,
    })
      .then((result) => {
        if (result) {
          console.log(result);
          showMessage({
            message: result.json.message,
            type: "success",
          });
        }
        setLoading(false);
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "center",
          justifyContent: "space-between",
          flexDirection: "row",
          marginLeft: 10,
          marginRight: 5,
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Settings")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontSize: 22, color: "#FFFFFF" }}>My Subscriptions</Text>

        <View></View>
      </View>

      {loading ? (
        <Spinner color={COLORS.light_green} visible={loading} />
      ) : state.length != 0 ? (
        state.map((single) => {
          return (
            <TouchableOpacity
              onPress={() =>
                navigation.navigate("SubscriptionOne", {
                  plan_name: single.order_product.plan_name,
                  id: single.order_id,
                })
              }
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                backgroundColor: "#252836",
                marginTop: 20,
                borderRadius: 10,
                marginLeft: 15,
                marginRight: 15,
              }}
            >
              <View style={styles.header}>
                <View>
                  <Text
                    style={{ fontSize: 22, color: "#0CFEBC", marginLeft: 10 }}
                  >
                    {single.order_product.plan_name}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => getInvoice(single.order_id)}
                style={{
                  borderRadius: 20,
                  backgroundColor: COLORS.light_green,
                  marginRight: 5,
                }}
              >
                <Text
                  style={{
                    color: "black",
                    margin: 5,
                    marginLeft: 15,
                    marginRight: 15,
                  }}
                >
                  Invoice
                </Text>
              </TouchableOpacity>
            </TouchableOpacity>
          );
        })
      ) : (
        <Emptysubscription navigation={navigation} />
      )}
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  header: {
    height: 80,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
});
