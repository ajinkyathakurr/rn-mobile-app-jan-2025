import { useContext, useEffect } from 'react';
import { StyleSheet, Text,View} from 'react-native';

import WebView from 'react-native-webview';
import ApiConfig from '../../../api/ApiConfig';
import { PostCallWithErrorResponse } from '../../../api/ApiServices';
import { AppContext } from '../../../user/AppContext';

export default function InvoiceWebView({navigation,route}) {
//const {name}=useContext(AppContext)

const {order_id}=route.params;
const {token}=useContext(AppContext)
const getInvoice = ()=>{

    PostCallWithErrorResponse(ApiConfig.DOWNLOAD_INVOICE , 
        {order_id:order_id,token:token}
           )
         .then((result) => {
     
           if (result) {
             console.log(result)
           }
         })
         .catch((error) => {
           console.log("api response", error);
       
         });
  
  }
  useEffect(()=>{
    getInvoice()
  },[])
  


  return (
    <View
    style={{height:'100%'}}

  >

<View style={{ backgroundColor: "#252836",marginTop:40,height:50,alignItems:'center',justifyContent:'center'}}>
        <Text
          style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" ,}}
        >
   Privacy Policy
        </Text>
        </View>
        <WebView source={{ uri: 'https://yourdigiwill.com/privacy-policy' }} styles={{height:'100%',width:'100%'}} />




  </View>
  )
}
const styles = StyleSheet.create({


  header:{
    height:100,
    flexDirection:'row',alignItems:'center',justifyContent:'space-between'

  }
  
  })