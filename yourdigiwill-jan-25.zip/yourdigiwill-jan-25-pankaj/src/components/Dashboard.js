import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Alert,
  BackHandler,
  Platform,
  Dimensions,
  TouchableOpacity,
} from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { SafeAreaView } from "react-native-safe-area-context";
import Ionicons from "react-native-vector-icons/Ionicons";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { useState, useEffect, useContext, useRef } from "react";
import {
  PostCallWithErrorResponse,
  getWithAuthCall,
  postWithAuthCall,
  simpleGetCall,
} from "../../api/ApiServices";
import VideoModal from "../components/profile/VideoModal"
import Spinner from "react-native-loading-spinner-overlay/lib";
import ApiConfig from "../../api/ApiConfig";
import LinearGradient from "react-native-linear-gradient";
import Contacts from "react-native-contacts";
import ReactNativeBiometrics, { BiometryTypes } from "react-native-biometrics";
import { AppContext } from "../../user/AppContext";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { COLORS } from "./colors";
import { showMessage, hideMessage } from "react-native-flash-message";
import { useIsFocused } from "@react-navigation/native";
import RBSheet from "react-native-raw-bottom-sheet";
import doc_arrow_down from "./../../assets/doc_arrow_down.png";
import doc_arrow_up from "./../../assets/doc_arrow_up.png";
import ManagerImage from "./../../assets/successionManager.png"
const rnBiometrics = new ReactNativeBiometrics();
let epochTimeSeconds = Math.round(new Date().getTime() / 1000).toString();
let payload = epochTimeSeconds + "some message";
const finance_all = [
  "Bank Investment",
  "Insurance",
  "Mutual Funds",
  "Shares",
  "Startup Investment",
  "Crypto Investment",
  "EPF",
  "NPS",
  "ESOP",
  "Other Investments",
];
const liability_all = ["Credit Card", "Loan", "Cash Borrowed"];
const non_finance_all = [
  "Real Estate",
  "Gold Loan",
  "Government Scheme",
  "Jewellery",
  "Creator Asset",
  "Chit Funds/Kitty Party",
];
const Tab = createBottomTabNavigator();

export default function Dashboard({ navigation, route }) {
  const { token, mobile_no, setToken, getEmail } = useContext(AppContext);
  const name1 = route.params;
  const focused = useIsFocused();
  const [active, setActive] = useState("Financial");
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const[pic,setPic]=useState();
  const[vid,seTvid]=useState(null);
  useEffect(() => {
   
    AsyncStorage.getItem('name').then((name) => {
      setName(name);
    });
    AsyncStorage.getItem('token').then((token) => {
      setToken(token);
    });
    
    
    AsyncStorage.getItem('email').then((email) => {
      setTimeout(() => {
        if (email == "" || email == null) {
          navigation.navigate("ProfileDetails", {
            token: token,
            mobile_no: mobile_no,
          });
        }
      }, 2000);
    });
  }, [focused]);

  
  const [assets, setAssets] = useState([]);
  const [modal,showModal]=useState(false);
  const checkExpressWillEligibility = () => {
    setLoading(true);
    getWithAuthCall(ApiConfig.CHECK_EXPRESSWILL_ELIGIBILITY).then((data) => {
     
      setLoading(false);
      console.log(data)
      if (data.status) {
        getWithAuthCall(ApiConfig.GET_EXPRESS_WILL).then((data) => {
          console.log(data);
          if (data.express_Will.length > 0) {
            navigation.navigate("ListingScreen", { data: data.express_Will });
          } 
          else {
            postWithAuthCall(ApiConfig.CREATE_EXPRESSWILL, {
              express_will_type: "myself",
            }).then((res) => {
              console.log(res);
              if (res.status) {
                getWithAuthCall(ApiConfig.GET_EXPRESS_WILL).then((data) => {
                  navigation.navigate("ListingScreen", {
                    data: data.express_Will,
                  });
                });
              } 
              else {
                showMessage({ message: res.message, type: "info" });
                RBSheetRef.current.close();
              }
            });
       
          }
        });
        RBSheetRef.current.close();
      } else {
        showMessage({
          message:
            "You are not eligible to create express will. Please complete both nominee KYC and distribution to create express will.",
          type: "info",
          backgroundColor: "purple",
          color: "white",
        });
      }
    });
  };

  const getAllAssets = () => {
    setLoading(true)
    simpleGetCall(ApiConfig.GET_ALL_ASSETS_LOGO)
      .then((data) => {
        if (data) {
          setLoading(false)
          setAssets(data);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
      console.log(pic)
      AsyncStorage.getItem('profile_pic').then((storedPic) => {
        if (storedPic) {
          
          setPic(storedPic);
        } else {
          
          getWithAuthCall(ApiConfig.GET_PROFILE).then((res) => {
            const profilePic = res.data.profile_pic;
            if (profilePic) {
              
              setPic(profilePic);
              AsyncStorage.setItem('profile_pic', profilePic);
            } else {
              // Handle the case when profile pic is not available from API or AsyncStorage
              console.log("Profile pic not found.");
            }
          }).catch((error) => {
            console.error("Error fetching profile pic:", error);
          });
        }
      }).catch((error) => {
        console.error("Error fetching profile pic from AsyncStorage:", error);
      });
  };


  useEffect(() => {
    getAllAssets();
  }, []);
  console.log("assets++++",assets);
  

  const RBSheetRef = useRef();

  return (
    <SafeAreaView style={{ backgroundColor: COLORS.light_grey_body }}>
      <VideoModal modal={modal} id={vid} showModal={showModal}/>
      <Spinner color={COLORS.light_green} visible={loading}/>
      <View style={styles.header}>
        <RBSheet
          ref={RBSheetRef}
          closeOnDragDown={true}
          closeOnPressMask={true}
          closeOnPressBack={true}
          height={650}
          customStyles={{
            wrapper: {
              backgroundColor: "#0909098f",
            },
            draggableIcon: {
              backgroundColor: "#ffe",
            },
            container: {
              borderTopLeftRadius: 20,
              borderTopRightRadius: 20,
              backgroundColor: "#2D3845",
              display: "flex",
              flexDirection: "column",
            },
          }}
        >
          <View
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              paddingHorizontal: 10,
            }}
          >
            <Text
              style={{
                color: "#F9BA00",
                fontSize: 20,
                fontWeight: "bold",
                marginLeft: 20,
                marginTop: 10,
                marginBottom: 10,
              }}
            >
              Self Express Will
            </Text>
            <Text
              style={{
                color: "#fff",
                textAlign: "center",
                fontSize: 30,
                fontWeight: "bold",
                marginLeft: 20,
                marginTop: 10,
                marginBottom: 10,
              }}
            >
              Create your Will in Minutes
            </Text>
            <Text
              style={{
                color: "#fff",
                textAlign: "center",
                fontSize: 15,
                marginLeft: 20,
                marginTop: 10,
                marginBottom: 10,
              }}
            >
              You can create your legal will for yourself or for others from
              below
            </Text>
            <View
              style={{
                marginTop: 20,
                width: "95%",
                height: 1,
                borderRadius: 10,
                backgroundColor: "#0CFEBC",
              }}
            ></View>
            <View
              style={{
                display: "flex",
                flexDirection: "row",
                width: "100%",
                justifyContent: "space-evenly",
                alignContent: "center",
              }}
            >
              <View
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "40%",
                }}
              >
                <TouchableOpacity
                  style={{
                    marginTop: 20,
                    width: 70,
                    height: 70,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "column",
                    borderRadius: 50,
                    backgroundColor: "#0CFEBC",
                    padding: 10,
                  }}
                  onPress={checkExpressWillEligibility}
                >
                  <Image
                    style={{
                      width: 50,
                      height: 50,
                    }}
                    source={doc_arrow_down}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: 15,
                    marginLeft: 20,
                    marginTop: 10,
                    marginBottom: 10,
                  }}
                >
                  Self express for myself
                </Text>
              </View>
              <View
                style={{
                  marginTop: 20,
                  width: 1,
                  height: "90%",
                  borderRadius: 10,
                  backgroundColor: "#0CFEBC",
                }}
              ></View>
              <View
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "40%",
                }}
              >
                <TouchableOpacity
                  style={{
                    marginTop: 20,
                    width: 70,
                    height: 70,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "column",
                    borderRadius: 50,
                    backgroundColor: "#F9BA00",
                    padding: 10,
                  }}
                  onPress={()=>showMessage({
                    message:
                      "Coming Soon",
                    type: "info",
                    backgroundColor: "purple",
                    color: "white",
                  })}
                >
                  <Image
                    style={{
                      width: 50,
                      height: 50,
                    }}
                    source={doc_arrow_up}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    color: "#fff",
                    textAlign: "center",
                    fontSize: 15,
                    marginLeft: 20,
                    marginTop: 10,
                    marginBottom: 10,
                  }}
                >
                  Will for others
                </Text>
              </View>
            </View>
            <View
              style={{
                marginTop: 30,
                width: "55%",
                height: "8%",
                borderRadius: 50,
                backgroundColor: "#F7D600",
              }}
            >
              <View
                style={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "100%",
                  height: "100%",
                }}
              >
                <Text
                  style={{
                    color: "#1F1D2B",
                    textAlign: "center",
                    fontSize: 20,
                    fontWeight: "bold",
                  }}
                >
                  Upload
                </Text>
                <Ionicons
                  name="cloud-upload-outline"
                  size={24}
                  color="black"
                  style={{
                    marginLeft: 10,
                  }}
                />
              </View>
            </View>
            <Text
              style={{
                color: "#8A8D9F",
                textAlign: "center",
                fontSize: 15,
                marginTop: 30,
              }}
            >
              By clicking 'Create will for myself' or 'Create will for others'
              you agree to our{" "}
              <Text
                style={{
                  color: "#0CFEBC",
                  textAlign: "center",
                  fontSize: 15,
                  marginTop: 20,
                }}
              >
                legal terms and conditions
              </Text>{" "}
              & also please check recheck all legal details before proceeding.
            </Text>
            <View
              style={{
                marginTop: 40,
                width: "40%",
                height: 8,
                borderRadius: 10,
                backgroundColor: "#0CFEBC",
              }}
            ></View>
          </View>
        </RBSheet>
        <View style={styles.first}>
          <TouchableOpacity
            onPress={() => navigation.navigate("ViewProfile")}
            style={{
              width: 50,
              height: 50,
              borderRadius: 25,
              backgroundColor: "#F73B3B",
              marginLeft: 21,
              alignItems: "center",
              justifyContent: "center",
              borderColor: "black",
              borderStyle: "solid",
              borderWidth: 1,
              marginTop: 5,
              
            }}
          >{
            (pic)?<Image style={{width:50,height:50,borderRadius:50}} source={{uri:pic}}/>:<Text style={{ fontSize: 16, color: "#FFFFFF" }}>
            {name ?name[0]:"D"}
          </Text>
          }
            
          </TouchableOpacity>
          <View style={{flex:1,flexDirection:'row',marginLeft:200,width:100,justifyContent:"space-evenly",marginRight:20}}>
          <TouchableOpacity
            onPress={() => navigation.navigate("Notification")}
            
          >
            
              <Ionicons name="notifications-outline" size={30} color="white" />
            
          </TouchableOpacity>
          <TouchableOpacity onPress={()=>{
            seTvid("Apab5ekXBz8")
            showModal(!modal)}}>
            <FontAwesome name="info-circle" size={30} color={COLORS.light_green}/>
          </TouchableOpacity>
          </View>
        </View>
        <View style={{ flex: 0.8 }}>
          <Text
            style={{
              fontSize: 24,
              color: COLORS.light_green_new,
              marginTop: 30,
              marginLeft: 21,
            }}
          >
            Welcome
          </Text>
          <Text
            style={{
              fontSize: 24,
              color: COLORS.light_green,
              marginTop: 10,
              marginLeft: 21,
              fontWeight: "bold",
            }}
          >
            {name1 ? name1.name1 : name}
          </Text>
        </View>
      </View>
      <ScrollView style={styles.body}>
        <View style={styles.subMenu}>
          <View style={{alignItems:"center"}}>
            <TouchableOpacity
              onPress={() => navigation.navigate("DistributionOne")}
              style={{
                width: 65,
                height: 65,
                borderRadius: 50,
                color: "#FFFFFF",
                // marginRight: 21,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 10,
                backgroundColor: "#252836",
              }}
            >
              <Image
                style={styles.rndImage}
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/assetdist.png",
                }}
              />
            </TouchableOpacity>
            <Text style={styles.subMenuLable}>Distributions</Text>
          </View>
          <View style={{alignItems:"center"}}>
            <TouchableOpacity
              onPress={() => navigation.navigate("EnsuranceNewOne")}
              style={{
                width: 65,
                height: 65,
                borderRadius: 50,
                color: "#FFFFFF",
                // marginRight: 21,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 10,
                backgroundColor: "#252836",
              }}
            >
              <Image
                style={styles.rndImage}
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/subscriptionicon.png",
                }}
              />
            </TouchableOpacity>
            <Text style={styles.subMenuLable}>Subscription</Text>
          </View>
          <View style={{alignItems:"center"}}>
            <TouchableOpacity
              onPress={() => navigation.navigate("CommunicationOne")}
              style={{
                width: 65,
                height: 65,
                borderRadius: 50,
                color: "#FFFFFF",
                // marginRight: 21,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 10,
                backgroundColor: "#252836",
              }}
            >
              <Image
                style={styles.rndImage}
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/communicate.png",
                }}
              />
            </TouchableOpacity>
            <Text style={styles.subMenuLable}>Communication</Text>
          </View>
          <View style={{alignItems:"center"}}>
            <TouchableOpacity
              onPress={() => {
navigation.navigate("Nominee")              }}
              style={{
                width: 65,
                height: 65,
                borderRadius: 50,
                color: "#FFFFFF",
                alignItems: "center",
                justifyContent: "center",
                marginTop: 10,
                backgroundColor: "#252836",
              }}
            >
              <Image
                style={styles.rndImage}
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/my_nominee.png",
                }}
              />
            </TouchableOpacity>
            <Text style={{ ...styles.subMenuLable }}>
             Nominees
            </Text>
          </View>
          {/* <View style={{alignItems:"center"}}>
            <TouchableOpacity
              onPress={() => {
                RBSheetRef.current.open();
              }}
              style={{
                width: 65,
                height: 65,
                borderRadius: 50,
                color: "#FFFFFF",
                alignItems: "center",
                justifyContent: "center",
                marginTop: 10,
                backgroundColor: "#252836",
              }}
            >
              <Image
                style={styles.rndImage}
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/will.png",
                }}
              />
            </TouchableOpacity>
            <Text style={{ ...styles.subMenuLable }}>
              Express Will
            </Text>
          </View> */}
        </View>
        <View style={styles.secondSection}>
          <View style={styles.secondSection1}>
            <TouchableOpacity
              style={{
                width: 30,
                height: 50,
                borderRadius: 50,
                color: "#FFFFFF",
                // marginRight: 21,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 5,
                backgroundColor: "black",
                marginLeft: 10,
              }}
            >
              <Image
                style={styles.rndImageSection}
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/assetliab.png",
                }}
              />
            </TouchableOpacity>
            <TouchableOpacity  onPress={() => navigation.navigate("MyAssetsAndLiablity")}
>
            <Text  style={{ color: COLORS.light_green_new, maxWidth: 90 }}>My Assets & Liabilities</Text>  
            </TouchableOpacity>
            {/* <TouchableOpacity
              onPress={() => navigation.navigate("MyAssetsAndLiablity")}
              style={{
                width: 73,
                height: 36,
                borderRadius: 18,
                color: "#FFFFFF",
                marginRight: 17,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 5,
                backgroundColor: "#FFA900",
                marginLeft: 8,
              }}
            >
              <Text style={{ fontSize: 14, color: "black" }}>View</Text>
            </TouchableOpacity> */}
          </View>
          <TouchableOpacity
            style={styles.secondSection2}
            onPress={() => navigation.navigate("ViewManagers")}
          >
           <Image source={ManagerImage} style={styles.rndImageSection}></Image>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.secondSection2}
            onPress={() => navigation.navigate("Nominee")}
          >
            <Image
              style={styles.rndImageSection1}
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/my_nominee.png",
              }}
            />
          </TouchableOpacity>
        </View>
        <ScrollView
          style={{ width: "100%" }}
          showsHorizontalScrollIndicator={true}
          decelerationRate={"fast"}
          horizontal={true}
        >
          {/* <Image
            style={{
              width: Dimensions.get("screen").width - 32,
              height: 160,
              marginLeft: 16,
              marginRight: 15,
              marginTop: 15,
              borderRadius: 10,
              marginBottom: 10,
            }}
            source={{
              uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/media/dashboard_banner/express_willsbanner_tDgkw6g.png",
            }}
          /> */}
          <TouchableOpacity onPress={()=>showMessage({message:
                      "This feature is currently unavailable but will be coming soon! Stay tuned!",
                    type: "info",
                    backgroundColor: "purple",
                    color: "white",position:"center"})}>
          <Image
            style={{
              width: Dimensions.get("screen").width - 32,
              height: 170,
              marginLeft: 16,
              marginRight: 15,
              marginTop: 15,
              borderRadius: 10,
              marginBottom: 10,
            }}
            source={{
              uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/media/dashboard_banner/after_you_banner_3.png",
            }}
          />
          </TouchableOpacity>
          
        </ScrollView>
        <View style={{flex:1,flexDirection:"row"}}>
        <Text
          style={{
            fontSize: 20,
            color: COLORS.light_green_new,
            marginLeft: 23,
            marginRight:23
          }}
        >
          Assets
        </Text>
        <TouchableOpacity onPress={()=>{
          seTvid("ziOalCd-Sq0")
          showModal(!modal)}}>
        <FontAwesome name="info-circle" size={24} color={COLORS.light_green}/>
        </TouchableOpacity>
        </View>
        
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            marginRight: 20,
            marginLeft: 20,
            marginTop: 10,
            marginBottom: 10,
          }}
        >
          <TouchableOpacity onPress={() => setActive("Financial")}>
            <Text
              style={{
                color: active == "Financial" ? COLORS.light_yello : "white",
                fontSize: 18,
              }}
            >
              Financial
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setActive("Non-Financial")}>
            <Text
              style={{
                color: active == "Non-Financial" ? COLORS.light_yello : "white",
                fontSize: 18,
              }}
            >
              Non-Financial
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setActive("Liabilities")}>
            <Text
              style={{
                color: active == "Liabilities" ? COLORS.light_yello : "white",
                fontSize: 18,
              }}
            >
              Liabilities
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.fourthSection}>

          {(assets)? assets.map(
            (single) => {
            return (
              <>
                {active == "Financial" &&
                finance_all.includes(single.category_name) ? (
                  <TouchableOpacity
                    onPress={() =>
                      navigation.navigate(single.category_name, {
                        category_id: single.id,
                      })
                    }
                    style={{
                      width: Dimensions.get("screen").width / 3 - 8,
                      backgroundColor: "#252836",
                      height: 88.47,
                      alignItems: "center",
                      justifyContent: "center",
                      margin: 4,
                      borderRadius: 10,
                    }}
                  >
                    <Image
                      style={{ height: 50, width: 50 }}
                      source={{ uri: single.category_icon }}
                    ></Image>
                    <Text style={{ fontSize: 13, color: "#FFFFFF" }}>
                      {single.category_name}
                    </Text>
                  </TouchableOpacity>
                ) : (
                  ""
                )}
                {active == "Non-Financial" &&
                non_finance_all.includes(single.category_name) ? (
                  <TouchableOpacity
                    onPress={() =>
                      navigation.navigate(single.category_name, {
                        category_id: single.id,
                      })
                    }
                    style={{
                      width: Dimensions.get("screen").width / 3 - 8,
                      backgroundColor: "#252836",
                      height: 88.47,
                      alignItems: "center",
                      justifyContent: "center",
                      margin: 4,
                      borderRadius: 10,
                    }}
                  >
                    <Image
                      style={{ height: 50, width: 50 }}
                      source={{ uri: single.category_icon }}
                    ></Image>
                    <Text style={{ fontSize: 13, color: "#FFFFFF" }}>
                      {single.category_name}
                    </Text>
                  </TouchableOpacity>
                ) : (
                  ""
                )}
                {active == "Liabilities" &&
                liability_all.includes(single.category_name) ? (
                  <TouchableOpacity
                    onPress={() =>
                      navigation.navigate(single.category_name, {
                        category_id: single.id,
                      })
                    }
                    style={{
                      width: Dimensions.get("screen").width / 3 - 8,
                      backgroundColor: "#252836",
                      height: 88.47,
                      alignItems: "center",
                      justifyContent: "center",
                      margin: 4,
                      borderRadius: 10,
                    }}
                  >
                    <Image
                      style={{ height: 50, width: 50 }}
                      source={{ uri: single.category_icon }}
                    ></Image>
                    <Text style={{ fontSize: 13, color: "#FFFFFF" }}>
                      {single.category_name}
                    </Text>
                  </TouchableOpacity>
                ) : (
                  ""
                )}
              </>
            )
          }
        ):<Spinner color={COLORS.light_green} visible={loading}></Spinner>}
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  fourthSection: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-around",
    alignItems: "center",
    marginBottom: 150,
  },
  rndImageSection1: {
    width: 50,
    height: 50,
  },
  rndImageSection: {
    width: 50,
    height: 50,
  },
  secondSection1: {
    backgroundColor: "rgba(12, 254, 188, 0.43)",
    height: 72,
    marginLeft: 16,
    borderRadius: 10,
    marginTop: 10,
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-evenly",
    alignItems: "center",
  },
  secondSection2: {
    flex: 0.4,
    backgroundColor: "rgba(12, 254, 188, 0.43)",
    height: 72,
    marginLeft: 10,
    borderRadius: 10,
    marginTop: 10,
    marginRight: 10,
    justifyContent: "center",
    alignItems: "center",
  },
  secondSection: {
    flex: 1,
    flexDirection: "row",
    marginTop: 15,
  },
  subMenuLable: {
    fontSize: 12,
    color: "white",
    marginTop: 5,
    textAlign:"center"
  },
  rndImage: {
    width: 70,
    height: 70,
  },
  subMenu: {
    flex: 1,
    flexDirection: "row",
    justifyContent: "space-between",
    marginHorizontal: 15,
    marginTop: 20,
  },

  body: {
    backgroundColor: "black",
    borderTopLeftRadius: 25,
    borderTopRightRadius: 25,
    marginBottom: 20,
  },
  roundbtn: {},
  header: {
    height: 135,
    backgroundColor: COLORS.light_grey,
  },
  first: {
    flex:0.2,
    width:"100%",
    
    flexDirection: "row",
    
    justifyContent:"space-between"
  },
});
