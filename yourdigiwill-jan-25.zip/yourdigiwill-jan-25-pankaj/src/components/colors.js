export const COLORS = {
    white: '#fff',
    black: '#000',
    grey:'#1F1D2B',
    light_grey:'#252836',
    light_green:'#0CFEBC',
    light_yello:'#FBB042',
    light_pink:'#F73B71',
    light_red:'rgba(247, 59, 59, 0.15)',
    red_shade:'#F52D6A',
    light_green_new:"#00FFA3"  , // your colors
    dark_grey:'#1F1D2B',
    light_grey_body:'#252836',
    pinkish_red:'#F73B71',
    dark_red:'#FF0000'
  }