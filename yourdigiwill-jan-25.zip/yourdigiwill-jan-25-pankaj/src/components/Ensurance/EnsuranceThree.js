import { StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import LinearGradient from 'react-native-linear-gradient';
import { PostCallWithErrorResponse, simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import { AppContext } from '../../../user/AppContext';
import { NavigationContainer } from '@react-navigation/native';
export default function EnsuranceThree({route,navigation}) {
const {nominee}=route.params;
const [plans,setPlan]=useState([])
const [loading,setLoading]=useState(true)
const {token} =useContext(AppContext)
const [Index, setIndex] = useState(0);

const getAllPlans= ()=>{

    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_PLANS + "?name=Ensurance",{token:token})
      .then((data) => {
          
        if (data) {
            console.log(data)
            setPlan(data.json.data)
         setLoading(false)
        }
      })
      .catch((error) => {
        console.log("api response", error);
  
      });
  
  }

  const handleSubmit = ()=>{

    PostCallWithErrorResponse(ApiConfig.DIGIWILL_START_PAYMENT , 
   {nominee_array:nominee,token:token,plan_id:Index}
      )
    .then((result) => {
      console.log(result)
      if (result.json) {
       navigation.navigate('EnsuranceFour',{data:result.json})
      }
    })
    .catch((error) => {
      console.log("api response", error);
  
    });
  
  }

useEffect(()=>{


getAllPlans()

},[])
  return (
    <View
    style={{backgroundColor:'black',height:'100%',flex:1}}

  >

<View style={{ backgroundColor: "#252836",marginTop:40,height:50,alignItems:'center',justifyContent:'center',flex:0.1}}>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
   Choose Plan
        </Text>
 
        </View>
        <View style={{flex:0.9}}>
        {
            plans.map((singlechild,index)=>{

                return (
                    <TouchableOpacity 
                    onPress={()=>setIndex(singlechild.id)}
                    style={{
                        height:50,
                        backgroundColor:'#2D3845',
                        marginBottom:10,
                        marginTop:10,
                        borderRadius:10,
                        marginRight:10,
                        marginLeft:10,
                        alignItems:'center',
                        flexDirection:'row',
                        justifyContent:'space-between',
                        borderColor:singlechild.id==Index? '#0CFEBC' :'black',
                        borderWidth:1
                    }}>
                    <View style={{width:10,backgroundColor:"red"}}>
                    
                    </View>
                                   <Text style={{color:"#FFFFFF"}}>{singlechild.plan_name}</Text>
                                   <View></View>
                                   <Text style={{color:"#FFFFFF",marginRight:5}}>₹ {singlechild.plan_price}</Text>
                                    </TouchableOpacity>
                )
            })
       }
        </View>


        <TouchableOpacity
         onPress={()=>handleSubmit()}
            style={{width:Dimensions.get('screen').width-32,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#0CFEBC',
            borderRadius:25,
          
            marginBottom:20,
            marginLeft:16
           
         }}
            
          >
            <Text  style={{fontSize:16,color:'#FFFFFF' }}>Subscribe

            {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
            </Text>
          </TouchableOpacity>



  </View>
  )
}
const styles = StyleSheet.create({

    section:{
   
    
    
    }
    
    
    })