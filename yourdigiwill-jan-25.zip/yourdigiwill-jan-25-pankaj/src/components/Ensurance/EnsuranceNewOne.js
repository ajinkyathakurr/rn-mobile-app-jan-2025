import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
  Platform,
} from "react-native";

import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import ToggleSwitch from "toggle-switch-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import RBSheet from "react-native-raw-bottom-sheet";
import { useIsFocused } from "@react-navigation/native";
import { COLORS } from "../colors";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../../api/ApiServices";
import Spinner from "react-native-loading-spinner-overlay";
import { ScrollView } from "react-native-gesture-handler";
import { getProducts, purchaseProduct } from "./IAPHelper";
import * as RNIap from 'react-native-iap';
import { showMessage } from "react-native-flash-message";

export default function EnsuranceNewOne({ navigation }) {
  const [loading, setLoading] = useState(false);
  const { token } = useContext(AppContext);
  const [state, setState] = useState(false);
  const [plans, setPlans] = useState([]);
  const [selectedPlan, seTselectedPlan] = useState();
  const focused = useIsFocused();
  const [products, setProducts] = useState([]);
  const RBSheetRef = useRef();

  //{"result":True,"message":"Already Subscribed.","order_id":order.id,"plan":plan.plan_name}
  const getSubscription = () => {
    setLoading(true);
    simpleGetCallWithErrorResponse(ApiConfig.CHECK_ALREADY_SUBSCRIBED, {
      token: token,
    })
      .then((data) => {
        console.log("get subscription",data);

        setLoading(false);
        if (data.json.result) {
          console.log("data.json.order_id",data.json.order_id);
          
          navigation.navigate("AlreadySubscribed", {
            order_id: data.json.order_id,
          });
          setState(true);
        }

      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  useEffect(() => {
    const initIapConnection = async () => {
      try {
        // Initialize the connection
        await RNIap.initConnection();
        console.log('IAP Connection Initialized');

        // Fetch products
        const availableProducts = await getProducts();
        console.log('Fetched Products:', availableProducts);
        setProducts(availableProducts);
      } catch (error) {
        console.warn('Error initializing IAP or fetching products:', error);
      }
    };

    // Initialize the connection and fetch products
    initIapConnection();

    // Set up purchase listener
    const purchaseListener = RNIap.purchaseUpdatedListener((purchase) => {
      console.log('Purchase Successful-------:', purchase);
      // Handle purchase (e.g., send to server for verification)
    });

    // Cleanup on unmount
    return () => {
      RNIap.endConnection();
      purchaseListener.remove();
      console.log('IAP Connection Closed and Listener Removed');
    };
  }, []);

  const handlePurchase = async (productId) => {
    setLoading(true)
    const product =  await purchaseProduct(productId);
    console.log("product----ß",product);
    
    if(product.transactionReceipt){
      console.log("verifyyyy====",product)
      PostCallWithErrorResponse(ApiConfig.DIGIWILL_VERIFY_PAYMENT,
        { ...product, token: token , platform : "ios" , ios_receipt:product.transactionReceipt,plan_product_id_ios:product.productId}
      )
        .then((result) => {
          console.log(result)
          if (result.json) {
            setLoading(false)
           showMessage({message:
            "Congratulations! You have successfully subscribed to DigiWill's Subscription.",
          type: "success",
          backgroundColor: "green",
          color: "white",position:"top"})
            setTimeout(() => {
              navigation.navigate('Home')
          }, 1000);
          }
        })
        .catch((error) => {
          console.log("api response", error);

        });
    }
   

  };

  console.log(Platform.OS);
  
  const showInfo = (id = 0) => {
    seTselectedPlan(id);
    RBSheetRef.current.open();
  };
  const getAllPlans = () => {
    simpleGetCallWithErrorResponse(
      ApiConfig.GET_ALL_PLANS + "?name=Ensurance",
      { token: token }
    )
      .then((data) => {
        if (data) {
          console.log("plan data===========>>>>",JSON.stringify(data));

          setPlans(data.json.data);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });

    console.log(plans);
  };

  const handleSubmit = (id) => {
    setLoading(true)
    if(Platform.OS=='android'){
    setLoading(true);
    PostCallWithErrorResponse(ApiConfig.ENSURANCE_PAY, {
      token: token,
      plan_id: id,
    })
      .then((result) => {
        console.log('Server Response   ',result);
        if (result.json.status) {
          setLoading(false);
          navigation.navigate("EnsuranceFour", { data: result.json, id: id });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
    }else{
      console.log("sdasfdesef")
      handlePurchase("11");
    }
  };

  useEffect(() => {
    getSubscription();
    getAllPlans();
    console.log(plans);
  }, []);

  return (
    <SafeAreaView
      style={{ backgroundColor: COLORS.light_grey_body, height: "100%" }}
    >
      <RBSheet
        ref={RBSheetRef}
        closeOnDragDown={false}
        closeOnPressMask={true}
        closeOnPressBack={true}
        height={650}
        customStyles={{
          wrapper: {
            backgroundColor: "#0909098f",
          },
          draggableIcon: {
            backgroundColor: "#ffe",
          },
          container: {
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            backgroundColor: "#2D3845",
            display: "flex",
            flexDirection: "column",
          },
        }}
      >
        {plans.length > 0 ? (
          <ScrollView style={{ padding: 20, paddingBottom: 50 }}>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Asset Discovey</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Ai powered discovery of all your assests
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Asset Addition</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>Manual Asset Addition</Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Asset Updates</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Ai powered automatic updates of all your assest records
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Central Nomination</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Nominee management across all investments, savings and assets
                  from one single platform
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>
                  Nominee Addition / Updates -{" "}
                  {selectedPlan == plans[0].id ? "10" : "50"}
                </Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Ai powered discovery of all your assests
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>
                  Succession Managers -{" "}
                  {selectedPlan == plans[0].id ? "5" : "50"}
                </Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Sharing & Communication of your assets with your CA, Lawyers,
                  Wealth-Managers, etc.
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              {/* <>
                <Text style={styles.planInfoText1}>
                  Express Will - {selectedPlan == plans[0].id ? "2" : "15"}
                </Text>
              </> */}
              <>
                <Text style={styles.planInfoText2}>
                  1 click E-sign will creation & Auto-will creation
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Record Communication</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Events of communication of wills and financial records
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Asset Discovey</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Ai powered discovery of all your assests
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Linked Account</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Real time communication of assets
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>
                  Financial and legal Advisory
                </Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Free of cost minimal document creation
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>
                  Human Interference Free
                </Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  No Human dependency required for Will & financial records
                  communication with your nominees
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Life Status Tracker Ai</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Track persons Life Status with Ai
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Data Storage</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Free unlimited data for financial records and wills
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>
                  After you Automated Wealth Transmission
                </Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  Updates Asset Records & Transmits Human Interference Free
                  Financial Records & WIlls transfer to registered nominees
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Claim it</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  All asset hand-held door-step claim service for dependants
                  nominees
                </Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>Platform Access</Text>
              </>
              <>
                <Text style={styles.planInfoText2}>Valid For Lifetime</Text>
              </>
            </View>
            <View style={{ margin: 5 }}>
              <>
                <Text style={styles.planInfoText1}>
                  Dedicated Service Manager
                </Text>
              </>
              <>
                <Text style={styles.planInfoText2}>Single point service</Text>
              </>
            </View>
            <View style={{ margin: 5, paddingBottom: 10 }}>
              <>
                <Text style={styles.planInfoText1}>
                  Tokenized + Encrypted Digital Records
                </Text>
              </>
              <>
                <Text style={styles.planInfoText2}>
                  State of Art tokenization + encryption for financial records
                </Text>
              </>
            </View>
          </ScrollView>
        ) : (
          <></>
        )}
      </RBSheet>

      <View
        style={{
          backgroundColor: "#252836",
          marginTop: 10,
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Home")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2, marginLeft: 3 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" }}>
          Subscribe Now
        </Text>
        <View></View>
      </View>
      {loading ? (
        <Spinner color={COLORS.light_green} visible={loading} />
      ) : (
        <></>
      )}
      <LinearGradient
        colors={["#053AA0", "#0500FF"]}
        style={{
          height: 170,
          backgroundColor: "rgba(5, 160, 129, 0.2)",
          marginTop: 20,
          borderRadius: 10,
          marginLeft: 10,
          marginRight: 10,
        }}
      >
        <View>
          <Image
            source={{
              uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/image+97.png",
            }}
            style={{ height: 100, width: 100, marginLeft: 20, marginRight: 10 }}
          ></Image>
        </View>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginRight: 10,
          }}
        >
          <View>
            <Text style={{ fontSize: 25, marginLeft: 20, fontWeight: "bold" }}>
              Free
            </Text>
            <Text
              style={{
                fontSize: 18,
                marginLeft: 20,
                fontWeight: "bold",
                color: COLORS.light_green_new,
              }}
            >
              Active
            </Text>
          </View>
          <View>
            {/* <AntDesign name="infocirlceo" size={25}>
              {" "}
            </AntDesign> */}
          </View>
        </View>
      </LinearGradient>


      {/* Pro */}
      <TouchableOpacity
        onPress={() => {
          if (plans) handleSubmit(plans.filter((plan)=>plan.plan_name == "Pro")[0].id);
        }}
      >
        <LinearGradient
          colors={["#FFA900", "#FFD44F", "#FFA900"]}
          style={{
            height: 170,
            backgroundColor: "rgba(5, 160, 129, 0.2)",
            marginTop: 20,
            borderRadius: 10,
            marginLeft: 10,
            marginRight: 10,
          }}
        >
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/image+98.png",
              }}
              style={{
                height: 105,
                width: 105,
                marginLeft: 20,
                marginRight: 10,
              }}
            ></Image>

            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/pngegg+1.png",
              }}
              style={{
                height: 105,
                width: 105,
                marginLeft: 20,
                marginRight: 10,
              }}
            ></Image>
          </View>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginRight: 10,
            }}
          >
            <View>
              <Text
                style={{ fontSize: 25, marginLeft: 20, fontWeight: "bold" }}
              >
                Pro
              </Text>
              <Text
                style={{ fontSize: 18, marginLeft: 20, fontWeight: "bold" }}
              >
                {plans && plans.length != 0
                  ? "@ ₹" + Platform.OS=="android"?(plans.filter((plan)=>plan.plan_name == "Pro")[0]?.plan_price):(plans.filter((plan)=>plan.plan_name == "Pro")[0]?.plan_ios_price ) + " / year"
                  : "loading"}
              </Text>
            </View>

            <TouchableOpacity onPress={() => showInfo(plans.filter((plan)=>plan.plan_name == "Pro")[0].id)}>
              <AntDesign name="infocirlceo" size={25}>
                {" "}
              </AntDesign>
            </TouchableOpacity>

          </View>
        </LinearGradient>
      </TouchableOpacity>
{/* Platinum */}
      {/* <TouchableOpacity onPress={() => handleSubmit(plans[1].id)}>
        <LinearGradient
          colors={["#99A1AB", "#EFF0F6", "#8A8D9F"]}
          style={{
            height: 170,
            backgroundColor: "rgba(5, 160, 129, 0.2)",
            marginTop: 20,
            borderRadius: 10,
            marginLeft: 10,
            marginRight: 10,
          }}
        >
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/image+99.png",
              }}
              style={{
                height: 105,
                width: 100,
                marginLeft: 20,
                marginRight: 10,
              }}
            ></Image>
            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/react-native-icons/pngegg+1.png",
              }}
              style={{
                height: 105,
                width: 105,
                marginLeft: 20,
                marginRight: 10,
              }}
            ></Image>
          </View>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginRight: 10,
            }}
          >
            <View>
              <Text
                style={{ fontSize: 25, marginLeft: 20, fontWeight: "bold" }}
              >
                Platinum
              </Text>
              <Text
                style={{ fontSize: 18, marginLeft: 20, fontWeight: "bold" }}
              >
                {plans && plans.length != 0
                  ? "@ ₹" + plans[1].plan_price + " / lifetime"
                  : "loading"}
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => {
                if (plans) showInfo(plans[1].id);
              }}
            >
              <AntDesign name="infocirlceo" size={25}>
                {" "}
              </AntDesign>
            </TouchableOpacity>
          </View>
        </LinearGradient>
      </TouchableOpacity> */}
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  planInfoText1: {
    color: COLORS.light_green_new,
    fontWeight: "bold",
    marginBottom: 4,
  },
  planInfoText2: { color: COLORS.white, marginBottom: 10 },
});
