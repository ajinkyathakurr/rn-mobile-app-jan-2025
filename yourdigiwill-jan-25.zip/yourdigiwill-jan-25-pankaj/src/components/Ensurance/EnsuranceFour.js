import { StyleSheet, Text, View, Button, Image, TouchableOpacity, Dimensions, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useRef, useEffect, useContext } from 'react'
import LinearGradient from 'react-native-linear-gradient';
import { PostCallWithErrorResponse, simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import { AppContext } from '../../../user/AppContext';
import RazorpayCheckout from 'react-native-razorpay';
import AntDesign from 'react-native-vector-icons/AntDesign'
import icon from "../../../assets/dwicon.png"
import { NavigationContainer } from '@react-navigation/native';
import { COLORS } from '../colors';
import { showMessage } from 'react-native-flash-message';
export default function EnsuranceFour({ route, navigation }) {
  const { data, id } = route.params;
  console.log(data);
  const [plans, setPlan] = useState([])
  const [loading, setLoading] = useState(true)
  const { token } = useContext(AppContext)
  const [Index, setIndex] = useState(0);
  const [code, setCode] = useState("")


  const handleCouponSubmit = (id) => {

    PostCallWithErrorResponse(ApiConfig.ENSURANCE_PAY,
      { token: token, plan_id: id, coupon_code: code }
    )
      .then((result) => {
        console.log(result)
        if (result.json) {
          if (result.json.message === "Invalid Coupon") {
            showMessage({
              message: "Invalid Cupon Code",
              type: "danger",
            });
          }
          else if (result.json.coupon_discount_value != 0) {
            showMessage({
              message: "promo code applied successfully",
              type: "success",
            });
          }


        }
      })
      .catch((error) => {
        console.log("api response", error);

      });

  }


  const handleSubmit = () => {
    console.log(data.order.order_id_razorpay, data.order.order_amount)
    var options = {
      description: 'Digiwill Subscription payment',
      image: icon,
      currency: 'INR',
      key: 'rzp_live_vMJUowugyM5w9E',
      amount: data.order.order_amount,
      name: 'Digiwill',
      order_id: data.order.order_id_razorpay,//Replace this with an order_id created using Orders API.
      prefill: {
        email: '',
        contact: '',
        name: ''
      },
      theme: { color: '#53a20e' }
    }


    RazorpayCheckout.open(options).then((data) => {
      // handle success
      console.log(data)
      alert(`Success: ${data.razorpay_payment_id}`);

      PostCallWithErrorResponse(ApiConfig.DIGIWILL_VERIFY_PAYMENT,
        { ...data, token: token }
      )
        .then((result) => {
          console.log(result)
          if (result.json) {
            navigation.navigate('Home')
          }
        })
        .catch((error) => {
          console.log("api response", error);

        });
    }).catch((error) => {
      // handle failure

      alert(`Error: Payment has been canceled`);
      navigation.goBack()
    });



  }


  return (
    <SafeAreaView
      style={{ backgroundColor: '#252836', height: '100%', flex: 1 }}

    >
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>

        <TouchableOpacity onPress={() => navigation.navigate('EnsuranceNewOne')}>
          <AntDesign name='left' size={30} color='#FFFFFF' style={{ marginRight: 2, marginLeft: 3 }}></AntDesign>
        </TouchableOpacity>

        <Text
          style={{ fontSize: 22, color: "#FFFFFF", fontWeight: 'bold' }}
        >
          Order Summary
        </Text>
        <View></View>
      </View>
      <View style={{ backgroundColor: "#252836", height: 50, alignItems: 'center', justifyContent: 'center', flex: 0.1 }}>



      </View>
      <View style={{ flex: 0.9, borderColor: '#FFFFFF', borderWidth: 1, marginLeft: 10, marginRight: 10, borderRadius: 10 }}>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20, marginLeft: 20, marginTop: 10 }}>

          <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: 'bold' }}>{data.plan_name}</Text>
          <View></View>
          <Text style={{ color: "#FFFFFF", marginRight: 5, fontSize: 20, fontWeight: 'bold' }}>₹{data.plan_price}</Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20, marginLeft: 20, marginTop: 10 }}>

          <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: 'bold' }}>Referral Bonus</Text>
          <View></View>
          <Text style={{ color: "#FFFFFF", marginRight: 5, fontSize: 20, fontWeight: 'bold' }}>₹{data.referral_bonus}</Text>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20, marginLeft: 20, marginTop: 10 }}>

          <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: 'bold' }}>Promotion Applied</Text>
          <View></View>
          <Text style={{ color: "#FFFFFF", marginRight: 5, fontSize: 20, fontWeight: 'bold' }}>₹{data.promotion}</Text>
        </View>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20, marginLeft: 20, marginTop: 10 }}>

          <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: 'bold' }}>Coupon Discount</Text>
          <View></View>
          <Text style={{ color: "#FFFFFF", marginRight: 5, fontSize: 20, fontWeight: 'bold' }}>₹{data.coupon_discount_value}</Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20, marginLeft: 20, marginTop: 10 }}>

          <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: 'bold' }}>Total</Text>
          <View></View>
          <Text style={{ color: "#FFFFFF", marginRight: 5, fontSize: 20, fontWeight: 'bold' }}>₹{data.price_after_promotion}</Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <TextInput
            style={styles.input2}
            value={code}
            placeholder="Enter Promo Code"
            onChangeText={(text) => setCode(text)}

            placeholderTextColor={COLORS.light_green_new}


          />

          <TouchableOpacity
            onPress={() => handleCouponSubmit(id)}
            style={{
              alignItems: 'center',
              justifyContent: 'center',

              marginTop: 10,
              marginBottom: 20
            }}

          >
            <Text style={{ fontSize: 20, color: COLORS.light_green_new, marginLeft: 20, marginRight: 20, marginTop: 10, fontWeight: 'bold' }}>Apply

            </Text>
          </TouchableOpacity>
        </View>

        <Text style={{ color: "#0CFEBC", marginLeft: 10, fontSize: 20, fontWeight: 'bold' }}>--------------------------------------</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20, marginLeft: 20, marginTop: 10 }}>

          <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: 'bold' }}>GST</Text>
          <View></View>
          <Text style={{ color: "#FFFFFF", marginRight: 5, fontSize: 20, fontWeight: 'bold' }}>₹{data.order.gst_amount}</Text>
        </View>

        <Text style={{ color: "#0CFEBC", marginLeft: 10 }}>--------------------------------------</Text>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginRight: 20, marginLeft: 20, marginTop: 10 }}>

          <Text style={{ color: "#0CFEBC", fontSize: 22, fontSize: 20, fontWeight: 'bold' }}>Payable Amount</Text>
          <View></View>
          <Text style={{ color: "#FFFFFF", marginRight: 5, fontSize: 22, fontSize: 20, fontWeight: 'bold' }}>₹{data.order.order_amount}</Text>
        </View>
      </View>


      <TouchableOpacity
        onPress={() => handleSubmit()}
        style={{
          width: Dimensions.get('screen').width - 32,
          height: 50,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: COLORS.light_green_new,
          borderRadius: 25,
          marginTop: 20,

          marginBottom: 20,
          marginLeft: 16

        }}

      >
        <Text style={{ fontSize: 16, color: 'white' }}>Pay Now

          {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
        </Text>
      </TouchableOpacity>




    </SafeAreaView>
  )
}
const styles = StyleSheet.create({

  input2: {
    backgroundColor: 'black',

    height: 60,
    marginBottom: 10,
    marginTop: 20,
    borderRadius: 10,
    paddingLeft: 10,
    fontSize: 16,
    color: 'white',
    flex: 230,
    marginLeft: 30,
    borderColor: COLORS.light_green_new,
    borderWidth: 2,
    borderStyle: 'dotted'

  }


})