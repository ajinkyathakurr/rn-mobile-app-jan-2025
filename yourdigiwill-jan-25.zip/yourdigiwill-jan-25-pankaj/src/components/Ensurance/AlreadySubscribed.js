import {
  StyleSheet,
  Text,
  View,

  TouchableOpacity,
  SafeAreaView,
  BackHandler

} from "react-native";
import AntDesign from "react-native-vector-icons/AntDesign";

import { useState,useEffect, useContext } from "react";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { COLORS } from "../colors";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import {
  simpleGetCallWithErrorResponse,
} from "../../../api/ApiServices";


export default function AlreadySubscribed({ navigation, route }) {
  const [loading, setLoading] = useState(false);
  const { token } = useContext(AppContext);
  const { order_id } = route.params;
  const [data, setData] = useState({});

  useEffect(() => {
    const backAction = () => {
      console.log("back");
      navigation.navigate("Dashboard");
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      "hardwareBackPress",
      backAction
    );

    return () => backHandler.remove();
  }, []);
console.log("order is ___",order_id);

  const getSubscriptionDetail = () => {
    console.log(ApiConfig.GET_SUBSCRIPTION_DETAIL + "?id=" + order_id);
    
    simpleGetCallWithErrorResponse(
      ApiConfig.GET_SUBSCRIPTION_DETAIL + "?id=" + order_id,
      { token: token }
    )
      .then((data) => {
        if (data.json.result) {
          setData(data.json);
        }
      })
      .catch((error) => {
        console.log("api response111", error);
      });
  };
  useEffect(() => {
    getSubscriptionDetail();
  }, []);

  return (
    <SafeAreaView style={{ backgroundColor: COLORS.black, height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          marginTop: 10,
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
         <TouchableOpacity onPress={() => navigation.navigate("Home")}>
                  <AntDesign
                    name="left"
                    size={30}
                    color="#FFFFFF"
                    style={{ marginRight: 2, marginLeft: 3 }}
                  ></AntDesign>
                </TouchableOpacity>
        <Text style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" }}>
          Digiwill Subscription
        </Text>
        <View></View>

      </View>
  
      <View>
        <View
          style={{
            height: 100,
            borderWidth: 1,
            borderStyle: "solid",
            backgroundColor: "#252836",
            marginTop: 20,
            borderRadius: 10,
            marginLeft: 16,
            marginRight: 16,
          }}
        >
          <Text
            style={{
              color: COLORS.light_green_new,
              marginLeft: 10,
              fontSize: 20,
              fontWeight: "bold",
              marginTop: 10,
            }}
          >
            {" "}
            Digiwill {data && data.plan_name ? data.plan_name : "loading"} Plan
          </Text>
          <Text
            style={{
              fontSize: 16,
              color: "#FFFFFF",
              marginLeft: 10,
              fontSize: 16,
              marginTop: 10,
            }}
          >
            Expiry Date :{" "}
            {data && data.expiry_data ? data.expiry_data : "loading"}
          </Text>
        </View>

        <View
          style={{
            height: 150,
            borderWidth: 1,
            borderStyle: "solid",
            backgroundColor: "#2D3845",
            marginTop: 20,
            borderRadius: 15,
            marginLeft: 16,
            marginRight: 16,
            borderColor: COLORS.light_green_new,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "flex-end",
              marginTop: -15,
              marginRight: 15,
            }}
          >
            <TouchableOpacity
              style={{
                height: 30,
                width: 100,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: COLORS.light_green_new,
                borderRadius: 25,

                marginLeft: 16,
              }}
            >
              <Text
                style={{ fontSize: 12, color: "white", fontWeight: "bold" }}
              >
                Activated
              </Text>
            </TouchableOpacity>
          </View>

          <Text
            style={{
              color: COLORS.light_green_new,
              marginLeft: 10,
              fontSize: 20,
              fontWeight: "bold",
              marginTop: 10,
            }}
          >
            Subscription Benefits
          </Text>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginRight: 20,
              marginLeft: 20,
            }}
          >
            <Text
              style={{
                color: "#FFFFFF",
                marginLeft: 10,
                
                fontWeight: "bold",
              }}
            >
              After You
            </Text>

            <TouchableOpacity
              onPress={() => navigation.navigate("CommunicationDetail")}
              style={{
                height: 30,
                width: 100,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: data.nominees_data
                  ? COLORS.grey
                  : COLORS.light_yello,
                borderRadius: 25,
                marginTop: 20,

                marginBottom: 20,
                marginLeft: 16,
              }}
              disabled={data.nominees_data ? true : false}
            >
              <Text
                style={{
                  fontSize: 12,
                  color: data.nominees_data ? COLORS.white : COLORS.black,
                }}
              >
                {data.nominees_data ? "Assigned" : "Assign now"}
              </Text>
            </TouchableOpacity>
          </View>
          <Text style={{ color: "#FFFFFF",
                marginLeft: 10,
                
                fontWeight: "bold",}}>15 Express Will Creation</Text>
        </View>

        <View>
          <Text
            style={{
              color: "white",
              marginLeft: 10,
              fontSize: 20,
              marginTop: 15,
            }}
          >
            {" "}
            Your Nominees
          </Text>

          {data && data.nominees_data && data.nominees_data.length != 0
            ? data.nominees_data.map((single) => {
                return (
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 10,
                      marginLeft: 10,
                      alignItems: "center",
                      marginTop: 10,
                      height: 60,
                      backgroundColor: COLORS.light_grey,
                      borderRadius: 10,
                    }}
                  >
                    <View
                      style={{ flexDirection: "row", alignItems: "center" }}
                    >
                      <View
                        style={{
                          width: 40,
                          height: 40,
                          borderColor: COLORS.light_green,
                          borderWidth: 1,
                          borderRadius: 50,
                          alignItems: "center",
                          marginLeft: 10,
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 22,
                            color: "#FFFFFF",
                            marginTop: 5,
                          }}
                        >
                          {single.name[0]}
                        </Text>
                      </View>
                      <Text
                        style={{
                          color: "white",
                          marginLeft: 20,
                          fontWeight: "bold",
                        }}
                      >
                        {single.name}
                      </Text>
                    </View>

                    <View></View>
                  </View>
                );
              })
            : ""}
        </View>
      </View>

      <TouchableOpacity
        onPress={() =>
          navigation.navigate("AddNomineeEnsurance", {
            order_id: data.order_data.id,
          })
        }
        style={{
          alignItems: "center",
          width: 60,
          position: "absolute",
          bottom: 40,
          right: 20,
          height: 60,
          color: "#FFFFFF",
          borderRadius: 50,
          justifyContent: "center",
          backgroundColor: "#FFBF35",
        }}
      >
        <FontAwesome name="plus" size={24} color="black" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({});
