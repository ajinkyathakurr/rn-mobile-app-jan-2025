import * as RNIap from 'react-native-iap';

const productIds = ["11","12"]; // Replace with your product IDs
const skus = {skus: [...productIds]};

export const getProducts = async () => {
  try {
    console.log("helloß.....");
    
    const products = await RNIap.getProducts(skus);
    console.log("products",products);
    
    return products;
  } catch (err) {
    console.warn(err);
  }
};


export const purchaseProduct = async (productId) => {
  console.log("Attempting to purchase product:", productId);

  try {
    // Initiate the purchase process
    const purchase = await RNIap.requestPurchase({sku: "11"}, false);
    console.log("Purchase successful:", purchase);
    
    // Validate the purchase here (e.g., using your server or Apple receipt validation)
    return purchase;
  } catch (err) {
    console.warn("Purchase failed:", err);

    // Handle known error structures
    if (err?.responseCode) {
      console.log("Response Code:", err.responseCode);
    }

    // Return error details
    return {
      success: false,
      error: err?.message || "Unknown error",
    };
  }
};

