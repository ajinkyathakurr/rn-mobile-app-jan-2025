import { StyleSheet, ScrollView,Text, View ,Button,Image,TouchableOpacity,ImageBackground,Dimensions,BackHandler} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import LinearGradient from 'react-native-linear-gradient';
import { simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import { AppContext } from '../../../user/AppContext';

export default function EnsuranceOne({navigation}) {
const {token}=useContext(AppContext)
const [state,setState]=useState(false)
  useEffect(()=>{

        getSubscription()
    
    },[])
const getSubscription = ()=>{

simpleGetCallWithErrorResponse(ApiConfig.CHECK_ALREADY_SUBSCRIBED,{token:token})
  .then((data) => {
    console.log(data)

    if (data.json.result) {
        setState(true)
    setLoading(false)
    }
  })
  .catch((error) => {
    console.log("api response", error);

  });

}


  return (
    <View
    style={{backgroundColor:'black',height:'100%'}}

  >

<View style={{ backgroundColor: "#252836",marginTop:40,height:50,alignItems:'center',justifyContent:'center'}}>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
   Ensurance
        </Text>
 
        </View>
        <ScrollView style={styles.body}>
     <ImageBackground source={require('../../../assets/ensurace1.png')} style={{height:370,marginLeft:10,marginRight:10}}>

<View style={{height:100,backgroundColor:'rgba(0,0,0,alpha)',top:300}}>
<Text 
          style={{  fontSize: 12, color: "#0CFEBC" ,}}
>Introducing</Text>
<Text 
          style={{  fontSize: 22, color: "#0CFEBC" ,}}
>Digiwill Ensurace Plan</Text>
<Text 
          style={{  fontSize: 17, color: "#0CFEBC" ,}}
>@ ₹ 10/day</Text>
</View>
     </ImageBackground>
<View style={{marginTop:10,flexDirection:'row',margin:10,flexWrap:'wrap'}}>
    <View style={{flex:1,width:Dimensions.get('screen').width/2-20,borderColor:'#0CFEBC',borderWidth:1,alignItems:'center',justifyContent:'center',marginRight:10,borderRadius:10,marginTop:10}}>
        <Image source={require('../../../assets/image8.png')} style={{height:48,width:48}}></Image>
        <Text  style={{  fontSize: 14, color: "#FFFFFF",maxWidth:100}}>
        Female service managers to help women and children.

        </Text>
    </View>
    <View style={{flex:1,width:Dimensions.get('screen').width/2-20,borderColor:'#0CFEBC',borderWidth:1,alignItems:'center',justifyContent:'center',marginRight:10,borderRadius:10,marginTop:10}}>
        <Image source={require('../../../assets/image8.png')} style={{height:48,width:48}}></Image>
        <Text  style={{  fontSize: 14, color: "#FFFFFF",maxWidth:100 }}>
        Female service managers to help women and children.

        </Text>
    </View>
    
    </View>  
    <View style={{marginTop:10,flexDirection:'row',margin:10,flexWrap:'wrap'}}>
    <View style={{flex:1,width:Dimensions.get('screen').width/2-20,borderColor:'#0CFEBC',borderWidth:1,alignItems:'center',justifyContent:'center',marginRight:10,borderRadius:10,marginTop:10}}>
        <Image source={require('../../../assets/image8.png')} style={{height:48,width:48}}></Image>
        <Text  style={{  fontSize: 14, color: "#FFFFFF",maxWidth:100}}>
        Female service managers to help women and children.

        </Text>
    </View>
    <View style={{flex:1,width:Dimensions.get('screen').width/2-20,borderColor:'#0CFEBC',borderWidth:1,alignItems:'center',justifyContent:'center',marginRight:10,borderRadius:10,marginTop:10}}>
        <Image source={require('../../../assets/image8.png')} style={{height:48,width:48}}></Image>
        <Text  style={{  fontSize: 14, color: "#FFFFFF",maxWidth:100 }}>
        Female service managers to help women and children.

        </Text>
    </View>
    
    </View>
    <View style={{marginTop:10,flexDirection:'row',margin:10,flexWrap:'wrap'}}>
    <View style={{flex:1,width:Dimensions.get('screen').width/2-20,borderColor:'#0CFEBC',borderWidth:1,alignItems:'center',justifyContent:'center',marginRight:10,borderRadius:10,marginTop:10}}>
        <Image source={require('../../../assets/image8.png')} style={{height:48,width:48}}></Image>
        <Text  style={{  fontSize: 14, color: "#FFFFFF",maxWidth:100}}>
        Female service managers to help women and children.

        </Text>
    </View>
    <View style={{flex:1,width:Dimensions.get('screen').width/2-20,borderColor:'#0CFEBC',borderWidth:1,alignItems:'center',justifyContent:'center',marginRight:10,borderRadius:10,marginTop:10}}>
        <Image source={require('../../../assets/image8.png')} style={{height:48,width:48}}></Image>
        <Text  style={{  fontSize: 14, color: "#FFFFFF",maxWidth:100 }}>
        Female service managers to help women and children.

        </Text>
    </View>
    
    </View>    
        </ScrollView>
        {
          state ? 

          <TouchableOpacity
          onPress={()=>navigation.navigate('Subscriptionlist')}
             style={{width:Dimensions.get('screen').width-32,
               height:50,
             alignItems:'center',
             justifyContent:'center',
             backgroundColor:'#0CFEBC',
             borderRadius:25,
             marginTop:10,
             marginBottom:20,
             marginLeft:16
            
          }}
             
           >
             <Text  style={{fontSize:16,color:'#FFFFFF' }}>Already Subscribed
 
             {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
             </Text>
           </TouchableOpacity>
:
<TouchableOpacity
onPress={()=>navigation.navigate('EnsuranceTwo')}
   style={{width:Dimensions.get('screen').width-32,
     height:50,
   alignItems:'center',
   justifyContent:'center',
   backgroundColor:'#0CFEBC',
   borderRadius:25,
   marginTop:10,
   marginBottom:20,
   marginLeft:16
  
}}
   
 >
   <Text  style={{fontSize:16,color:'#FFFFFF' }}>Subscribe

   {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
   </Text>
 </TouchableOpacity>

        }
       

  </View>
  )
}
const styles = StyleSheet.create({


body:{
borderRadius:10}

})