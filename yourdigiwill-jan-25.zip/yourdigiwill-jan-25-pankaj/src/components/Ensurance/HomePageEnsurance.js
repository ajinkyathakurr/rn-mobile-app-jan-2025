import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Border, Color, FontSize, Margin } from "../../../GlobalStyles.js";

const HomepageEnsurance = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homepageEnsurance}>
      {/* <Image
        style={styles.backgroundIcon}
        resizeMode="cover"
        source={require("../../../assets/background.png")}
      /> */}
      <View style={[styles.header, styles.headerLayout]}>
        <View style={[styles.statusBar, styles.headerLayout]}>
          <View style={styles.timePosition}>
            <View style={[styles.view, styles.timePosition]}>
              <Text style={[styles.text, styles.textTypo]}>9:41</Text>
            </View>
          </View>
          <Image
            style={styles.batteryIcon}
            resizeMode="cover"
            source={require("../../../assets/battery.png")}
          />
          <Image
            style={[styles.wifiIcon, styles.networkPosition]}
            resizeMode="cover"
            source={require("../../../assets/wifi.png")}
          />
          <View style={[styles.network, styles.networkPosition]}>
            <View style={[styles.rectangle96, styles.rectangleLayout]} />
            <View style={[styles.rectangle97, styles.rectangleLayout]} />
            <View style={[styles.rectangle98, styles.rectangleLayout]} />
            <View style={[styles.rectangle99, styles.rectangleLayout]} />
          </View>
        </View>
      </View>
      <Pressable
        style={styles.back}
        onPress={() => navigation.navigate("OldHomepageAssetRecording")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../../../assets/back.png")}
        />
      </Pressable>
      <LinearGradient
        style={[styles.homepageEnsuranceChild, styles.homepageLayout]}
        locations={[0, 1]}
        colors={["#053aa0", "#0500ff"]}
        useAngle={true}
        angle={180}
      />
      <Image
        style={[
          styles.materialSymbolsinfoOutlineIcon,
          styles.materialIconLayout,
        ]}
        resizeMode="cover"
        source={require("../../../assets/materialsymbolsinfooutlinerounded.png")}
      />
      <Text style={[styles.free, styles.freeTypo]}>{`Free `}</Text>
      <LinearGradient
        style={[styles.homepageEnsuranceItem, styles.homepageLayout]}
        locations={[0, 0.41, 1]}
        colors={["#ffa900", "#ffd44f", "#ffa900"]}
        useAngle={true}
        angle={180}
      />
      <Image
        style={[
          styles.materialSymbolsinfoOutlineIcon1,
          styles.materialIconLayout,
        ]}
        resizeMode="cover"
        source={require("../../../assets/materialsymbolsinfooutlinerounded1.png")}
      />
      <Text style={[styles.pro, styles.proTypo]}>Pro</Text>
      <LinearGradient
        style={[styles.homepageEnsuranceInner, styles.homepageLayout]}
        locations={[0, 0.38, 1]}
        colors={["#99a1ab", "#eff0f6", "#8a8d9f"]}
        useAngle={true}
        angle={180}
      />
      <Image
        style={[
          styles.materialSymbolsinfoOutlineIcon2,
          styles.materialIconLayout,
        ]}
        resizeMode="cover"
        source={require("../../../assets/materialsymbolsinfooutlinerounded1.png")}
      />
      <Text style={[styles.platinum, styles.proTypo]}>Platinum</Text>
      <View style={[styles.lifetimeWrapper, styles.wrapperPosition]}>
        <Text style={styles.lifetime}>@ ₹20,000 / lifetime</Text>
      </View>
      <View style={[styles.yearWrapper, styles.wrapperPosition]}>
        <Text style={styles.lifetime}>@ ₹3650 / year</Text>
      </View>
      <View style={[styles.just10dayWrapper, styles.wrapperLayout]}>
        <Text style={styles.just1dayTypo}>
          <Text style={styles.just}>{`@ Just `}</Text>
          <Text style={styles.day}>₹10/Day</Text>
        </Text>
      </View>
      <View style={[styles.just1dayWrapper, styles.wrapperLayout]}>
        <Text style={[styles.just1day, styles.just1dayTypo]}>
          <Text style={styles.just}>{`@ Just `}</Text>
          <Text style={styles.day}>₹1/Day</Text>
        </Text>
      </View>
      <Text style={[styles.dashboard, styles.textTypo]}>Subscribe Now</Text>
      <Text style={[styles.active, styles.freeTypo]}>Active</Text>
      <Image
        style={styles.image96Icon}
        resizeMode="cover"
        source={require("../../../assets/image-96.png")}
      />
      <Image
        style={styles.pngegg1Icon}
        resizeMode="cover"
        source={require("../../../assets/pngegg-1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  headerLayout: {
    height: 19,
    width: 345,
    position: "absolute",
  },
  timePosition: {
    width: 33,
    height: 19,
    left: 0,
    top: 0,
    position: "absolute",
  },
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.roboto,
    fontWeight: "700",
    top: "50%",
    position: "absolute",
  },
  networkPosition: {
    width: 17,
    top: 4,
    position: "absolute",
  },
  rectangleLayout: {
    width: 3,
    borderRadius: Border.br_2xs,
    position: "absolute",
    backgroundColor: Color.white,
  },
  homepageLayout: {
    backgroundColor: "transparent",
    height: 150,
    width: 337,
    borderRadius: Border.br_lg,
    left: 19,
    position: "absolute",
  },
  materialIconLayout: {
    height: 24,
    width: 24,
    left: 315,
    position: "absolute",
    overflow: "hidden",
  },
  freeTypo: {
    fontFamily: FontFamily.openSans,
    textAlign: "left",
    color: Color.white,
    position: "absolute",
  },
  proTypo: {
    color: Color.black,
    fontFamily: FontFamily.openSans,
    fontSize: FontSize.size_xl,
    left: "8.53%",
    textAlign: "left",
    fontWeight: "700",
    position: "absolute",
  },
  wrapperPosition: {
    height: "2.83%",
    left: "8.53%",
    position: "absolute",
  },
  wrapperLayout: {
    height: "9.61%",
    position: "absolute",
  },
  just1dayTypo: {
    textAlign: "center",
    color: Color.brown,
    fontWeight: "800",
    fontSize: FontSize.size_2xl,
    top: "0%",
    fontFamily: FontFamily.openSans,
    left: "0%",
    position: "absolute",
  },
  backgroundIcon: {
    width: 375,
    left: 0,
    top: 0,
    position: "absolute",
    height: 812,
  },
  text: {
    marginTop: -9.5,
    fontSize: FontSize.size_sm,
    color: Color.white,
    left: "0%",
    textAlign: "left",
    fontFamily: FontFamily.roboto,
    fontWeight: "700",
    top: "50%",
  },
  view: {
    overflow: "hidden",
  },
  batteryIcon: {
    left: 322,
    width: 22,
    height: 11,
    top: 4,
    position: "absolute",
  },
  wifiIcon: {
    left: 300,
    height: 12,
  },
  rectangle96: {
    top: 7,
    height: 4,
    left: 0,
  },
  rectangle97: {
    top: 5,
    left: 5,
    height: 6,
  },
  rectangle98: {
    top: 2,
    left: 9,
    height: 9,
  },
  rectangle99: {
    left: 14,
    height: 11,
    top: 0,
  },
  network: {
    left: 277,
    height: 11,
  },
  statusBar: {
    left: 0,
    top: 0,
  },
  header: {
    top: 11,
    left: 15,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  back: {
    left: 21,
    top: 56,
    width: 12,
    height: 20,
    position: "absolute",
  },
  homepageEnsuranceChild: {
    top: 97,
  },
  materialSymbolsinfoOutlineIcon: {
    top: 211,
  },
  free: {
    top: "22.78%",
    fontSize: FontSize.size_xl,
    left: "8.53%",
    fontFamily: FontFamily.openSans,
    fontWeight: "700",
  },
  homepageEnsuranceItem: {
    top: 268,
  },
  materialSymbolsinfoOutlineIcon1: {
    top: 382,
  },
  pro: {
    top: "43.1%",
  },
  homepageEnsuranceInner: {
    top: 439,
  },
  materialSymbolsinfoOutlineIcon2: {
    top: 556,
  },
  platinum: {
    top: "64.78%",
  },
  lifetime: {
    fontSize: FontSize.size_base,
    fontWeight: "600",
    top: "0%",
    color: Color.black,
    fontFamily: FontFamily.openSans,
    textAlign: "left",
    left: "0%",
    position: "absolute",
  },
  lifetimeWrapper: {
    width: "43.2%",
    top: "68.6%",
    right: "48.27%",
    bottom: "28.57%",
  },
  yearWrapper: {
    width: "32%",
    top: "47.17%",
    right: "59.47%",
    bottom: "50%",
  },
  just: {
    marginBlockStart: 0,
    marginBlockEnd: 0,
  },
  day: {
    margin: Margin.m_md,
  },
  just10dayWrapper: {
    width: "32.27%",
    top: "36.7%",
    right: "17.87%",
    bottom: "53.69%",
    left: "49.87%",
  },
  just1day: {
    width: "100%",
  },
  just1dayWrapper: {
    width: "33.07%",
    top: "58.5%",
    right: "17.33%",
    bottom: "31.9%",
    left: "49.6%",
  },
  dashboard: {
    marginTop: -355,
    left: "33.33%",
    fontSize: FontSize.size_lg,
    color: Color.gray_300,
    textAlign: "left",
    fontFamily: FontFamily.roboto,
    fontWeight: "700",
    top: "50%",
  },
  active: {
    top: 213,
    left: 32,
    fontSize: FontSize.size_xs,
  },
  image96Icon: {
    left: 268,
    width: 88,
    height: 99,
    top: 97,
    position: "absolute",
  },
  pngegg1Icon: {
    top: 273,
    left: 85,
    width: 108,
    height: 110,
    position: "absolute",
  },
  homepageEnsurance: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    flex: 1,
    overflow: "hidden",
    height: 812,
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default HomepageEnsurance;