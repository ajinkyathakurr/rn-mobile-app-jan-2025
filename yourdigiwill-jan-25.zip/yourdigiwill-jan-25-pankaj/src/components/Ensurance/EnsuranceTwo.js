import { StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions} from 'react-native';

import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import { ScrollView } from 'react-native-gesture-handler';
import Spinner from 'react-native-loading-spinner-overlay';
import  FontAwesome  from 'react-native-vector-icons/FontAwesome'; 
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import CheckBox from 'react-native-check-box';
import LinearGradient from 'react-native-linear-gradient';
import { AppContext } from '../../../user/AppContext';
import ApiConfig from '../../../api/ApiConfig';
import { PostCallWithErrorResponse, simpleGetCallWithErrorResponse } from '../../../api/ApiServices';

export default function EnsuranceTwo({navigation}) {

    const [sharedbymenominees,setSharedbymeNominees]=useState([])
    const [loading,setLoading]=useState(true)
    const [selectednominees,setselectedsetNominees]=useState([])
    const {token}=useContext(AppContext)



    const handleSubmit = ()=>{
        

    }


    const getAllSharedByMeNominees = ()=>{

        simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_NOMINEES,{token:token})
          .then((data) => {
              
            if (data) {
                console.log(data)
                setSharedbymeNominees(data.json.data)
             setLoading(false)
            }
          })
          .catch((error) => {
            console.log("api response", error);
      
          });
      
      }



useEffect(()=>{

 
    getAllSharedByMeNominees()
    
    },[])
    

  return (
    <View
    style={{backgroundColor:'black',height:'100%'}}

  >
<View style={{ backgroundColor: "#252836",marginTop:40,height:50,alignItems:'center',justifyContent:'center'}}>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
  Select Nominees
        </Text>
 
        </View>

        <ScrollView style={{flex:0.2}}>
        {
          sharedbymenominees.length !=0 ? 
   sharedbymenominees.map((single)=>{
return (
  <View
  style={{
    width: Dimensions.get("screen").width - 32,
    backgroundColor: "#1F1D2B",
    height: 70,
    marginLeft: 16,
    marginRight: 16,
    marginTop: 10,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "space-between",
    flex: 1,
    flexDirection: "row",
  }}
>
  <View>
    <Text
      style={{
        
        fontSize: 22,
        color: "#FFFFFF",
        marginLeft: 10,
      }}
    >
      {single.name[0]}
    </Text>
  </View>
  <Text
    style={{
      
      fontSize: 17,
      color: "#FFFFFF",
    }}
  >
    {single.name}
  </Text>
  <View>
  <CheckBox
          style={styles.checkbox}
          isChecked={selectednominees.indexOf(single.id) > -1 ? true : false}
          onClick={()=> { selectednominees.indexOf(single.id) > -1? setselectedsetNominees(selectednominees.filter((value)=>value!=single.id)): setselectedsetNominees(  [...selectednominees,single.id]) ;console.log(selectednominees)  }}
          // color={true ? '#0CFEBC' : undefined}
          checkBoxColor="#0CFEBC"
        />

  </View>

</View>
)


          })
          :
          
          <Spinner visible={loading}/>
        }
      

      </ScrollView>


      <LinearGradient
       colors={['#FFBF35','#FFA900']}
       style={{width:65,borderRadius:50,flex:0.1,left:'80%',bottom:'1%'}}
      
       >
       <TouchableOpacity
                onPress={() =>navigation.navigate('EnsuranceThree',{nominee:selectednominees})}
                style={{
                 width:65,
                    height:65,
                    borderRadius:50,
                    color:'#FFFFFF',
                alignItems:'center',
                 justifyContent:'center', 
             
                  
               }}
                >
                  
                  <AntDesign name="arrowright" size={24} color="black" />               
              </TouchableOpacity>
       </LinearGradient>


</View>
  )
}

const styles = StyleSheet.create({
    checkbox:{

        marginRight:5,
        color:'#0CFEBC',
        borderColor:'#0CFEBC'
    }


})