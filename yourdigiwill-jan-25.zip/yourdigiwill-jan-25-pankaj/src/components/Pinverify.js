import { StyleSheet, ScrollView, TextInput, TouchableOpacity, Text, View, Button, Image, ActivityIndicator, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
// import { AntDesign } from '@expo/vector-icons'; 
import Icon from 'react-native-vector-icons/AntDesign';

import AsyncStorage from '@react-native-async-storage/async-storage';

import { OtpInput } from "react-native-otp-entry";

import { showMessage, hideMessage } from "react-native-flash-message";
import ApiConfig from '../../api/ApiConfig';
import { DeleteCallWithErrorResponse, PostCallWithErrorResponse } from '../../api/ApiServices';
import { useContext } from 'react'
import { AppContext } from '../../user/AppContext';
import ReactNativeBiometrics, { BiometryTypes } from 'react-native-biometrics'
import { COLORS } from './colors';
const rnBiometrics = new ReactNativeBiometrics()
let epochTimeSeconds = Math.round((new Date()).getTime() / 1000).toString()
let payload = epochTimeSeconds + 'some message'
async function setToken(value) {
  await AsyncStorage.setItem('token', value);
}

export default function Pinverify({ route, navigation }) {
  const { token, pin,setName } = useContext(AppContext);
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState({ otp: "" })
  const { nominee, id } = route.params || "";



  useEffect(() => {
    AsyncStorage.getItem('name').then((name) => {
      setName(name)


    })


    setTimeout(() => {
      setLoading(false)
    }, 2000);

  }, [])

  useEffect(() => {
    if (nominee == 'signup') {
      rnBiometrics.simplePrompt({ promptMessage: 'Confirm fingerprint' })
        .then((resultObject) => {
          const { success } = resultObject

          if (success) {
            console.log('successful biometrics provided')
            navigation.navigate('Home')
          } else {
            console.log('user cancelled biometric prompt')
          }
        })
        .catch(() => {
          console.log('biometrics failed')
        })
    }



  }, [])


  const handleSubmit = async () => {
    if (data.otp == "" || data.otp.length != 4) {
      if (data.otp == "") {
        showMessage({
          message: "Please enter the valid otp",
          type: "danger",
        });
      }
      if (data.otp.length != 4) {
        showMessage({
          message: "Please enter atleast 4 digit otp",
          type: "danger",
        });
      }

      return
    }
    console.log(AsyncStorage.getItem('pin'))


    if (data.otp == pin) {

      if (nominee == "nominee") {

        DeleteCallWithErrorResponse(ApiConfig.DIGIWILL_ADD_NOMINEE,
          {
            id: id,
            token: token

          }
        )
          .then((result) => {
            console.log(result)
            if (result.json.result) {
              showMessage({
                message: "nominee Removed Successfully",
                type: "success",
              });
              setData({ otp: "" })
              navigation.navigate('Nominee')

            }
          })
          .catch((error) => {
            console.log("api response", error);

          });
      }
      if (nominee == "signup") {
        showMessage({
          message: "Verified successfully",
          type: "success",
        });
        setData({ otp: "" })
        navigation.navigate('Home')
      }
      
    }
    else {
      showMessage({
        message: "Invalid Pin",
        type: "danger",
      });

    }




  }
  return (


    <KeyboardAvoidingView style={{ flex: 1 }}>


      <SafeAreaView style={styles.container}>
        <ScrollView style={{ flex: 1, marginTop: 140 }}>



          <View style={styles.body}>
            <Text style={{ fontFamily: 'System', fontSize: 20, color: '#0CFEBC', marginTop: 30, marginBottom:20, fontWeight: 'bold', paddingTop: 1 }}>
              VERIFY MPIN
            </Text>

            <View style={styles.input}>


<OtpInput
                  numberOfDigits={4}
                  onTextChange={(text) => setData({ ...data, otp: text })}
                  // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
                  // onCodeChanged = {code => { this.setState({code})}}

                  // codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}    autoFocusOnLoad
                  keyboardAppearance	='dark'
                  onFilled={(text) => setData({ ...data, otp: text })}
                  theme={
                    {
                      pinCodeTextStyle:{color:"#0CFEBC"},
                      containerStyle:{width: '80%', height: 100,marginTop:10},
                      pinCodeContainerStyle: {borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:55,height:60,fontSize:20},
                      filledPinCodeContainerStyle: {borderBottomColor:'#0CFEBC',}
                    }
                  }
              />

            </View>

          

            <TouchableOpacity
              onPress={() => handleSubmit()}
              style={{
                width: 295,
                height: 50,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: COLORS.light_green_new,
                borderRadius: 25,
                marginTop: 10,
                marginBottom: 30,
                flexDirection: 'row'
              }}

            >
              <Text style={{ fontFamily: 'System', fontSize: 20, color: 'black', fontWeight: 'bold', marginRight: 5 }}>Verify Pin


              </Text>
              <Icon name="doubleright" size={20} marginLeft={3} color="black" />
            </TouchableOpacity>
          </View>

        </ScrollView>

      </SafeAreaView>






    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',



  },
  header: {
    flex: 0.07,
    backgroundColor: '#252836',
    alignItems: 'center'

  },
  body: {
    flex: 0.4,
    backgroundColor: COLORS.dark_grey,
    marginTop: 20,
    borderRadius: 10,
    marginRight: 10,
    marginLeft: 10,
    alignItems: 'center'
  },
  input: {
    flex: 1,
    flexDirection: 'row'




  }

})