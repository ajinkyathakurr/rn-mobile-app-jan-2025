import { StyleSheet, ScrollView, TextInput, TouchableOpacity,Text, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import Icon  from 'react-native-vector-icons/AntDesign';
import { PostCallWithErrorResponse, postWithAuthCallWithErrorResponse } from '../../api/ApiServices';
import ApiConfig from '../../api/ApiConfig';
import FlashMessage from "react-native-flash-message";
import { showMessage, hideMessage } from "react-native-flash-message";
import Spinner from 'react-native-loading-spinner-overlay';

export default function Login({navigation}) {

    const [loading,setLoading]=useState(false)
    const [data,setData]=useState({phone:""})
    useEffect(()=>{

setTimeout(() => {
    setLoading(false)
}, 2000);

    },[])

    const handleSubmit = ()=>{
      
      if(data.phone=="" || data.phone.length<10){
        if(data.phone==""){
          showMessage({
            message: "Please enter the valid Mobile number",
            type: "danger",
          });
        }
        if(data.phone.length<10){
          showMessage({
            message: "Please enter atleast 10 digit number",
            type: "danger",
          });
        }
        
        return 
      }
      setLoading(true)
      postWithAuthCallWithErrorResponse(ApiConfig.DIGIWILL_GENERATE_OTP , 
        {mobile_no:"+91"+data.phone,token:"12345"}
        )
      .then((result) => {
        console.log(result.json.result)
        if(result.json.message=='User does not exist'){
          setLoading(false)
          showMessage({
            message: "User Does not exist plese Sign Up",
            type: "danger",
          });
          return
 
        }
        if (result.json.result) {
         
        
            setLoading(false)
            navigation.navigate('OtpVerification',{
              phone:data.phone
            })
          
   
          
        }
      })
      .catch((error) => {
        console.log("api response", error);
  
      });
    }

  


  return (
  
  
  <KeyboardAvoidingView style={{flex:1}}>

         
          <SafeAreaView style={styles.container}>
          <ScrollView style={{flex:1}}>
          {
          loading ? 
          <Spinner visible={loading}/>

          :
          <>
           <View style={styles.header}>
    
           <Text  style={{fontFamily:'System',fontSize:22,color:'#FFFFFF',marginTop:10,paddingBottom:10}}>
                   Sign in
               </Text>
            
           </View>
           <View style={styles.body}>
        <Text style={{fontFamily:'System',fontSize:22,color:'#0CFEBC',marginTop:30}}> 
            Sign In to Account
        </Text>
          <TextInput
            style={styles.input}
            value={data.phone}
            placeholder="Mobile"
            keyboardType="numeric"
            onChangeText = {(text)=>setData({...data,phone:text})}
    
            placeholderTextColor="#8A8D9F" 
          />
    

    <TouchableOpacity
          onPress={()=>handleSubmit()}
            style={{width:295,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#0CFEBC',
            borderRadius:25,
            marginTop:10,
            marginBottom:30
         }}
            
          >
            <Text  style={{fontFamily:'System',fontSize:20,color:'black'}}>Next

            <Icon name="doubleright" size={20} marginLeft={3} color="black" />
            </Text>
          </TouchableOpacity>
           </View>
           <View style={{flex:0.5 ,alignItems:'center' ,marginTop:10,flexDirection:'row',justifyContent:'center'}}>
            <Text style={{fontFamily:'System',fontSize:16,color:'#FFFFFF'}}>
                Doesn't have Account?
                
            </Text >
            <Text 
            onPress={()=>{navigation.navigate('Signup')}}
            style={{fontFamily:'System',fontSize:16,color:'#0CFEBC',marginLeft:3}}>
                Sign Up
                
            </Text >
           </View></>

} 

           </ScrollView>
    
       </SafeAreaView>

    


  
    
  </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
    container: {
     flex:1,
     backgroundColor:'black',
  
   
    },
    header:{
        flex:0.07,
        backgroundColor:'#252836',
      alignItems:'center'

    },
    body:{
        flex:0.4,
        backgroundColor:"#252836",
        marginTop:20,
        borderRadius:10,
       marginRight:10,
       marginLeft:10,
       alignItems:'center'
    },
    input:{
        backgroundColor:'black',
        width:295,
        height:50,
        marginBottom:10,
        marginTop:10,
        borderRadius:25,
        paddingLeft:10,
        fontSize:16,
        color:'white'
       



    }
    
})