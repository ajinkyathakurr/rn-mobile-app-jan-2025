import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import Header from "./Header";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
  DeleteCallWithErrorResponse
} from "../../api/ApiServices";
import ApiConfig from "../../api/ApiConfig";
import { AppContext } from "../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import AntDesign from "react-native-vector-icons/AntDesign";
import CheckBox from "react-native-check-box";
import LinearGradient from "react-native-linear-gradient";
import { COLORS } from "./colors";
import Entypo from "react-native-vector-icons/Entypo";
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from "react-native-popup-menu";
import { showMessage } from "react-native-flash-message";

export default function MyAssetsAndLiablity({ navigation }) {
  const [assets, setSharedAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedassets, setselectedAssets] = useState([]);
  const { token } = useContext(AppContext);
  const handleAssetDelete=(id)=>{
    DeleteCallWithErrorResponse(ApiConfig.DELETE_ASSET,{"will_id":id}).then((res)=>{
      getAllAssets()
      showMessage({message:"Asset Deleted",type:"success"})
    }).catch(()=>showMessage({message:"Error deleting your assets",type:"danger"}))
  }
  const MenuFunction = (
    id,
    merchant,
    folio_no,
    fund_type,
    amount,
    transaction_history,
    message,
    category,
    origin,
    policy_no,
    policy_type,
    startup_name,
    platform_name,
    invested_date,
    investment_type,
    amount_invested,
    account_no,
    broker_name,
    stock_name,
    no_of_units,
    address,
    property_name,
    scheme_name,
    purchase_date,
    types,
    jewellery_form,
    company_name,
    issue_date,
    cliff_period,
    crypto_currency_name,
    opening_date,
    bank_name,
    uan_no,
    card_no,
    card_issuer,
    billing_date,
    loan_no,
    loan_type,
    rate_of_interest,
    tenure,
    investment_name,
    no_of_members,
    borrower_from,
    creators_username,
    social_media_handle,
    doc_file,
    bank_branch,
    account_type
  ) => {
    if (category.category_name == "Mutual Funds") {
      navigation.navigate("Mutual Funds", {
        metadata: {
          id: id,
          merchant: merchant,
          folio_no: folio_no,
          fund_type: fund_type,
          amount: amount,
          transaction_history: transaction_history,
          message: message,
          category_id: category.id,
          origin: origin,
          doc_file: doc_file,
        },
      });
    }

    if (category.category_name == "Insurance") {
      navigation.navigate("Insurance", {
        metadata: {
          id: id,
          merchant: merchant,
          policy_no: policy_no,
          policy_type: policy_type,
          amount: amount,
          transaction_history: transaction_history,
          message: message,
          category_id: category.id,
          origin: origin,
        },
      });
    }
    if (category.category_name == "Startup Investment") {
      navigation.navigate("Startup Investment", {
        metadata: {
          id: id,
          startup_name: startup_name,
          platform_name: platform_name,
          investment_date: invested_date,
          investment_type: investment_type,
          amount_invested: amount_invested,
          message: message,
          category_id: category.id,
          origin: origin,
        },
      });
    }
    if (category.category_name == "Shares") {
      navigation.navigate("Shares", {
        metadata: {
          id: id,
          broker_name: broker_name,
          stock_name: stock_name,
          no_of_units: no_of_units,
          amount: amount,
          message: message,
          category_id: category.id,
          origin: origin,
        },
      });
    }
    if (category.category_name == "Real Estate") {
      navigation.navigate("Real Estate", {
        metadata: {
          id: id,
          amount: amount,
          message: message,
          property_name: property_name,
          purchase_date: purchase_date,
          address: address,
          category_id: category.id,
          origin: origin,
        },
      });
    }
    if (category.category_name == "NPS") {
      navigation.navigate("NPS", {
        metadata: {
          id: id,
          amount: amount,
          message: message,
          transaction_history: transaction_history,
          account_no: account_no,
          scheme_name: scheme_name,
          category_id: category.id,
          origin: origin,
        },
      });
    }
    if (category.category_name == "Jewellery") {
      navigation.navigate("Jewellery", {
        metadata: {
          id: id,
          category_id: category.id,
          amount: amount,
          message: message,
          purchase_date: purchase_date,
          merchant: merchant,
          jewellery_form: jewellery_form,
          types: types,
          origin: origin,
        },
      });
    }
    if (category.category_name == "ESOP") {
      navigation.navigate("ESOP", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          origin: origin,
          company_name: company_name,
          no_of_units: no_of_units,
          issue_date: issue_date,
          cliff_period: cliff_period,
        },
      });
    }
    if (category.category_name == "Crypto Investment") {
      navigation.navigate("Crypto Investment", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          platform_name: platform_name,
          crypto_currency_name: crypto_currency_name,
          account_no: account_no,
        },
      });
    }
    if (category.category_name == "Bank Investment") {
      navigation.navigate("Bank Investment", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          bank_name: bank_name,
          investment_type: investment_type,
          account_no: account_no,
          opening_date: opening_date,
        },
      });
    }
    if (category.category_name == "EPF") {
      navigation.navigate("EPF", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          uan_no: uan_no,
        },
      });
    }
    if (category.category_name == "Credit Card") {
      navigation.navigate("Credit Card", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          card_no: card_no,
          card_issuer: card_issuer,
          billing_date: billing_date,
          account_no: account_no,
        },
      });
    }
    if (category.category_name == "Loan") {
      navigation.navigate("Loan", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          loan_no: loan_no,
          loan_type: loan_type,
          bank_name: bank_name,
          rate_of_interest: rate_of_interest,
          tenure: tenure,
        },
      });
    }
    if (category.category_name == "Government Scheme") {
      navigation.navigate("Government Scheme", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          scheme_name: scheme_name,
        },
      });
    }
    if (category.category_name == "Other Investments") {
      navigation.navigate("Other Investments", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          investment_type: investment_type,
          investment_name,
        },
      });
    }
    if (category.category_name == "Chit Funds/Kitty Party") {
      navigation.navigate("Chit Funds/Kitty Party", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          tenure,
          tenure,
          merchant: merchant,
          no_of_members: no_of_members,
        },
      });
    }
    if (category.category_name == "Cash Borrowed") {
      navigation.navigate("Cash Borrowed", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          tenure,
          tenure,
          borrower_from: borrower_from,
        },
      });
    }
    if (category.category_name == "Gold Loan") {
      navigation.navigate("Gold Loan", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          amount: amount,
          origin: origin,
          tenure,
          tenure,
          rate_of_interest: rate_of_interest,
          merchant: merchant,
        },
      });
    }
    if (category.category_name == "Creator Asset") {
      navigation.navigate("Creator Asset", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          platform_name: platform_name,
          social_media_handle: social_media_handle,
          creators_username: creators_username,
          origin: origin,
        },
      });
    }
    if (category.category_name == "Bank Account") {
      navigation.navigate("Bank Account", {
        metadata: {
          id: id,
          category_id: category.id,
          message: message,
          origin: origin,
          bank_name: bank_name,
          account_no: account_no,
          bank_branch: bank_branch,
          account_type: account_type,
        },
      });
    }
  };
  const getAllAssets = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_ASSETS, { token: token })
      .then((data) => {
        if (data) {
          console.log(data);
          setSharedAssets(data.json.asset_data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  useEffect(() => {
    getAllAssets();
  }, []);

  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "center",
          justifyContent: "space-between",
          flexDirection: "row",
          marginLeft: 10,
          marginRight: 5,
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Home")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontSize: 22, color: "#FFFFFF" }}>
          Assets And Liablities
        </Text>
        <View></View>
      </View>

      <ScrollView>
        {assets && assets.length != 0 ? (
          assets.map((single) => {
            return (
              <View>
                <Text
                  style={{
                    fontSize: 22,
                    color: "#FFB721",
                    marginTop: 20,
                    marginRight: 10,
                    marginLeft: 20,
                  }}
                >
                  {single.category.category_name}
                </Text>

                {single.assets.map((single_child) => {
                  return (
                    <View
                      style={{
                        backgroundColor: COLORS.light_grey,
                        // height: 70,
                        width: Dimensions.get("screen").width - 32,
                       
                        marginLeft: 16,
                        marginRight: 16,
                        marginTop: 10,
                        borderRadius: 10,
                      }}
                    >
                      <View
                        style={{
                          marginLeft: 16,
                          marginRight: 16,
                          marginTop: 15,
                          borderRadius: 10,
                          alignItems: "center",
                          justifyContent:"space-between",
                          flex: 1,
                          flexDirection: "row",
                        }}
                      >
                        <View style={{flex:1,flexDirection:'row',alignItems:'center'}}>
                        <View
                          style={{
                            width: 30,
                            height: 30,
                            borderColor: COLORS.light_green,
                            borderWidth: 1,
                            borderRadius: 50,
                            alignItems: "center",
                          }}
                        ><Text style={{color:COLORS.white,fontSize:20,marginTop:2}}>{single_child.title[0]}</Text></View>
                        <Text
                          style={{ 
                            fontSize: 17,
                            color: "#FFFFFF",
                            marginLeft:10
                           }}
                        >
                          {single_child.title}
                        </Text>
                        </View>
                        <View >
                          <Menu>
                            <MenuTrigger>
                              <Entypo name="dots-three-vertical" size={22} />
                            </MenuTrigger>

                            <MenuOptions>
                              <MenuOption
                                onSelect={() =>
                                  MenuFunction(
                                    single_child.id,
                                    single_child.merchant,
                                    single_child.folio_no,
                                    single_child.fund_type,
                                    single_child.amount,
                                    single_child.transaction_history,
                                    single_child.message,
                                    single_child.category,
                                    (origin = "edit"),
                                    single_child.policy_no,
                                    single_child.policy_type,
                                    single_child.startup_name,
                                    single_child.platform_name,
                                    single_child.invested_date,
                                    single_child.investment_type,
                                    single_child.amount_invested,
                                    single_child.account_no,
                                    single_child.broker_name,
                                    single_child.stock_name,
                                    single_child.no_of_units,
                                    single_child.address,
                                    single_child.property_name,
                                    single_child.scheme_name,
                                    single_child.purchase_date,
                                    single_child.types,
                                    single_child.jewellery_form,
                                    single_child.company_name,
                                    single_child.issue_date,
                                    single_child.cliff_period,
                                    single_child.crypto_currency_name,
                                    single_child.opening_date,
                                    single_child.bank_name,
                                    single_child.uan_no,
                                    single_child.card_no,
                                    single_child.card_issuer,
                                    single_child.billing_date,
                                    single_child.loan_no,
                                    single_child.loan_type,
                                    single_child.rate_of_interest,
                                    single_child.tenure,
                                    single_child.investment_name,
                                    single_child.no_of_members,
                                    single_child.borrower_from,
                                    single_child.creators_username,
                                    single_child.social_media_handle,
                                    single_child.doc_file,
                                    single_child.bank_branch,
                                    single_child.account_type
                                  )
                                }
                                color="#989898"
                              >
                                <Text style={{ color: "black", fontSize: 12 }}>
                                  Edit
                                </Text>
                              </MenuOption>
                              <MenuOption onSelect={()=>{
                                handleAssetDelete(single_child.id)
                              }}>
                                <Text>
                                  Delete
                                </Text>
                              </MenuOption>
                            </MenuOptions>
                          </Menu>
                        </View>
                      </View>
                      <View
                        style={{
                          flex: 1,
                          height: 1,
                          backgroundColor: "white",
                          marginLeft: 5,
                          marginRight: 5,
                          marginTop: 10,
                        }}
                      />

                      <View
                        style={{
                          flexDirection: "column",
                          marginBottom: 5,
                          marginLeft: 5,
                          marginTop: 5,
                        }}
                      >
                        {single_child.bank_name ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.bank_name}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.account_no ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.account_no}
                          </Text>
                        ) : (
                          ""
                        )}

                        {single_child.folio_no ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.folio_no}
                          </Text>
                        ) : (
                          ""
                        )}

                        {single_child.fund_type ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.fund_type}
                          </Text>
                        ) : (
                          ""
                        )}

                        {single_child.transaction_history ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.transaction_history}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.policy_no ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.policy_no}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.policy_type ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.policy_type}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.card_no ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.card_no}
                          </Text>
                        ) : (
                          ""
                        )}

                        {single_child.startup_name ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.startup_name}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.investment_type ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.investment_type}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.no_of_units ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.no_of_units}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.invested_date ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.invested_date}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.loan_no ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.loan_no}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.loan_type ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.loan_type}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.rate_of_interest ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.rate_of_interest}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.tenure ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.tenure}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.creators_username ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.creators_username}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.no_of_members ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.no_of_members}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.billing_date ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.billing_date}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.opening_date ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.opening_date}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.stock_name ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.stock_name}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.address ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.address}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.issue_date ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.issue_date}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.purchase_date ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.purchase_date}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.jewellery_form ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.jewellery_form}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.crypto_currency_name ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.crypto_currency_name}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.cliff_period ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.cliff_period}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.types ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.types}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.amount_invested ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.amount_invested}
                          </Text>
                        ) : (
                          ""
                        )}
                        {single_child.message ? (
                          <Text style={{ color: "#989898" }}>
                            {single_child.message}
                          </Text>
                        ) : (
                          ""
                        )}

                        {single_child.amount ? (
                          <Text style={{ color: "#989898" }}>
                            ₹{single_child.amount}
                          </Text>
                        ) : (
                          ""
                        )}
                        {
                          single_child.doc_file?<TouchableOpacity onPress={()=>{navigation.navigate("ViewDoc",{url:single_child.doc_file})}} style={{}}><Text style={{color:COLORS.light_green,fontSize:18,margin:10,marginLeft:180}}>View Docuument</Text></TouchableOpacity>:""
                        }
                      </View>
                    </View>
                  );
                })}
              </View>
            );
          })
        ) : (
          <Spinner color={COLORS.light_green} visible={loading} />
        )}

        
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
