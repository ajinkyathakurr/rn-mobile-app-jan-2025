import AsyncStorage from '@react-native-async-storage/async-storage'
import { createSlice } from '@reduxjs/toolkit'


export const authSlice = createSlice({
    name: 'auth',
    initialState: {
      token:  1,
    },
    reducers: {
      authtoken: (state,action) => {
        // Redux Toolkit allows us to write "mutating" logic in reducers. It
        // doesn't actually mutate the state because it uses the Immer library,
        // which detects changes to a "draft state" and produces a brand new
        // immutable state based off those changes
        console.log("action",action.payload)
        console.log("state-----",state)
        const token = action.payload
       state.token=token
       console.log("state after",state)
      }
     
    },
  })
  
  // Action creators are generated for each case reducer function
  export const { authtoken} = authSlice.actions
  
  export default authSlice.reducer