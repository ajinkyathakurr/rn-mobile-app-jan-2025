import {CounterReducer} from './Counter/CounterReducer'
import {UserReducer} from './User/UserReducer'
import {combineReducers} from 'redux'

export const rootReducer  =combineReducers({counter:CounterReducer,user:UserReducer})

