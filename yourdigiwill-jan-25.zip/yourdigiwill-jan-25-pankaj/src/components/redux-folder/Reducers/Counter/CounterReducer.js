const initialState={
    count:0
}

export const UserReducer = (initialState,action)=>{
    switch(action.type){
        case "addition":
            return {count:count+1}
    

    }


}