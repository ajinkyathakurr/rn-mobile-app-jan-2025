const initialState={
    uname:"",
    isLoggedIn:false,
    token:""
}

export const UserReducer = (initialState,action)=>{
    switch(action.type){
        case "setUname":
            return
        case "setToken":
            return {...initialState,token:action.token}

    }


}

