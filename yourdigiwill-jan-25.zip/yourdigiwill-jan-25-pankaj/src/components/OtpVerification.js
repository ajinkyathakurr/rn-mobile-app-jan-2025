import { StyleSheet, Text,ScrollView, TextInput, TouchableOpacity, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
// import { AntDesign } from '@expo/vector-icons'; 
import Icon  from 'react-native-vector-icons/AntDesign';
import { PostCallWithErrorResponse, postWithAuthCallWithErrorResponse } from '../../api/ApiServices';
import AsyncStorage from '@react-native-async-storage/async-storage';
import ApiConfig from '../../api/ApiConfig';
import { OtpInput } from "react-native-otp-entry";
import { showMessage, hideMessage } from "react-native-flash-message";
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 

import {
  getHash, requestHint,
  startOtpListener,
  useOtpVerify,

  removeListener
} from 'react-native-otp-verify';
import RNOtpVerify from 'react-native-otp-verify';
import { useContext } from 'react';
import { AppContext } from '../../user/AppContext';
import { COLORS } from './colors';
import Spinner from 'react-native-loading-spinner-overlay';
 async function setToken(value) {
  await AsyncStorage.setItem('token', value);
}
async function setPin(value) {
  await AsyncStorage.setItem('pin', value);
}
async function setName(value) {
  await AsyncStorage.setItem('name', value);
}
async function setMobile(value) {
  await AsyncStorage.setItem('mobile_no', value);
}
async function setEmail(value) {
  await AsyncStorage.setItem('email', value);
}
export default  function OtpVerification({route,navigation}) {
  

    const { phone,email,name } = route.params;
    const [loading,setLoading]=useState(false)
    const [data,setData]=useState({otp:""})


const handleResend = async ()=>{

 setLoading(true)
  if(phone=="" || phone.length<10){
    if(phone==""){
      showMessage({
        message: "Please enter the valid Mobile number",
        type: "danger",
      });
    }
    if(phone.length<10){
      showMessage({
        message: "Please enter atleast 10 digit number",
        type: "danger",
      });
    }
    
    return 
  }
  postWithAuthCallWithErrorResponse(ApiConfig.DIGIWILL_GENERATE_OTP , 
    {mobile_no:"+91"+phone,token:"12345"}
    )
  .then((result) => {
    console.log(result.json);
    if(result.json.message=='User does not exist'){
      setLoading(false)
      showMessage({
        message: "User Does not exist plese Sign Up",
        type: "danger",
      });
      return

    }
    if (result.json.result) {
      showMessage({
        message: "Otp sent successfully",
        type: "success",
      });
        setLoading(false)
        navigation.navigate('OtpVerification',{
          phone:phone
        })
      

      
    }
  })
  .catch((error) => {
    console.log("api response", error);

  });

}

    const  handleSubmit =async ()=>{
      if(data.otp=="" || data.otp.length!=4){
        if(data.otp==""){
          showMessage({
            message: "Please enter the valid otp",
            type: "danger",
          });
        }
        if(data.otp.length!=4){
          showMessage({
            message: "Please enter atleast 4 digit otp",
            type: "danger",
          });
        }
        
        return 
      }
      console.log("otp", {email: email,
        email_otp:data.otp,
        device_token:"1888888",
        device_type:"Ios",
        name:name ? name : "",
        email:email?email:"",
        terms_conditions:true

     })
         postWithAuthCallWithErrorResponse(ApiConfig.DIGIWILL_VERIFY_OTP , 
          {email: email,
           email_otp:data.otp,
           device_token:"1888888",
           device_type:"Ios",
           name:name ? name : "",
           email:email?email:"",
           terms_conditions:true

        }
          )
        .then(async(data) => {
          console.log(data.json.token)
          if(data.json.result==false){
            showMessage({
              message: data.json.message,
              type: "danger",
            });
            return
          }
          if (data.json.token) {
            console.log("profiledetails",data.json.token)
            console.log("profiledetails-email",data.json.user.email)
           await setToken(data.json.token)
           await setName(data.json.user.legal_name)
           await setEmail(data.json.user.email)
           
           if(data.json.user.pin==null ||  data.json.user.pin==""){
            navigation.navigate('Pincode',{token:data.json.token,email:email}) 
          }
           
           else{
            if(data.json.user.mobile_no == null ||  data.json.user.mobile_no==""){
              console.log('hello')
            //  navigation.navigate('LoginSignup')
            navigation.navigate('ProfileDetails',{token:data.json.token,email:data.json.user.email}) 
             }
            setMobile(data.json.user.mobile_no)
            if(data.json.user.pin==null ||  data.json.user.pin==""){
              navigation.navigate('Pincode',{token:data.json.token,email:email}) 
            }
            else{
              setPin(data.json.user.pin)
            }


            setTimeout(() => {
              navigation.navigate('Home') 
            }, 1000);
        
           }
     
        
              };
            

          }
        )
        .catch((error) => {
          console.log("api response", error);
    
        });
      }
  return (
  
  
  <KeyboardAvoidingView style={{flex:1}}>
{
         
          <SafeAreaView style={styles.container}>
          <ScrollView style={{flex:1}}>
    
          
           <View style={styles.header}>
            
            <TouchableOpacity onPress={() => navigation.navigate('LoginSignup')}>
<AntDesign name='left' size={30} color='#FFFFFF' style={{marginRight:2,marginLeft:3}}></AntDesign>
</TouchableOpacity>
     
           <Text  style={{fontSize:22,color:'#FFFFFF',marginTop:10,paddingBottom:10,fontWeight:'bold'}}>
                   Otp Verification
               </Text>
            <View>

            </View>
           </View>

          
        {loading ?     <Spinner color={COLORS.light_green}  visible={loading}/>:""}   

         
           <View style={styles.body}>
        <Text style={{fontSize:28,color:COLORS.light_green_new,marginTop:30,fontWeight:'bold'}}> 
        OTP Verification
        </Text>

        <Text style={{fontSize:16,color:COLORS.light_green_new,marginTop:30,textAlign:'center'}}> 
        An authentication code has been sent to {email}
        </Text>
<View style={styles.input}>
<OtpInput
    numberOfDigits={4}
    onTextChange	= {(text)=>setData({...data,otp:text})}
    // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
    // onCodeChanged = {code => { this.setState({code})}}

    // codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}    autoFocusOnLoad
    keyboardAppearance	='dark'
    onFilled =  {(text)=>setData({...data,otp:text})}
    theme={
      {
        pinCodeTextStyle:{color:"#0CFEBC"},
        containerStyle:{width: '80%', height: 100,marginTop:10},
        pinCodeContainerStyle: {borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:55,height:60,fontSize:20},
        filledPinCodeContainerStyle: {borderBottomColor:'#0CFEBC',}
      }
    }
/>

</View>
     
          {/* <TextInput
            style={styles.input}
            value={data.phone}
            placeholder="Otp"
            keyboardType="numeric"
            onChangeText = {(text)=>setData({...data,phone:text})}
    
            placeholderTextColor="#8A8D9F" 
          />

     */}

    <TouchableOpacity
          onPress={()=>handleSubmit()}
            style={{width:295,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:COLORS.light_green_new,
            borderRadius:25,
            marginTop:10,
            marginBottom:30
         }}
            
          >
            <Text  style={{fontSize:20,color:'#FFFFFF'}}>Verify Now

            <Icon name="doubleright" size={20} marginLeft={3} color="black" />
            </Text>
          </TouchableOpacity>
           </View>
           <View style={{flex:0.5 ,alignItems:'center' ,marginTop:10,flexDirection:'row',justifyContent:'center'}}>
           <Text style={{fontSize:16,color:'#FFFFFF'}}>
                Didn't Recieve code?
                
            </Text >
            <Text 
            onPress={()=>{handleResend()}}
            style={{fontSize:18,color:'#0CFEBC',marginLeft:3}}>
               Resend
                
            </Text >
           </View>
           </ScrollView>
    
       </SafeAreaView>

      } 


  
    
  </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
    container: {
     flex:1,
     backgroundColor:'black',
  
   
    },
    header:{
        flex:0.07,
        backgroundColor:'#252836',
      alignItems:'center',
      flexDirection:'row',
      justifyContent:'space-between'

    },
    body:{
        flex:0.4,
        backgroundColor:COLORS.light_grey,
        marginTop:20,
        borderRadius:10,
       marginRight:10,
       marginLeft:10,
       alignItems:'center'
    },
    input:{
     flex:1,
     flexDirection:'row'
       



    }
    
})