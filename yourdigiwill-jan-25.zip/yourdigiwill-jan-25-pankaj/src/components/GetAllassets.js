import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import Header from "./Header";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../api/ApiServices";
import ApiConfig from "../../api/ApiConfig";
import { AppContext } from "../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import AntDesign from "react-native-vector-icons/AntDesign";
import CheckBox from "react-native-check-box";
import LinearGradient from "react-native-linear-gradient";
import { COLORS } from "./colors";
export default function GetAllassets({ navigation, route }) {
  const { nominee_id } = route.params;

  const [assets, setSharedAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedassets, setselectedAssets] = useState([]);
  const { token } = useContext(AppContext);

  const handleSubmit = () => {
    console.log(selectedassets);
    PostCallWithErrorResponse(ApiConfig.SHARE_ASSET, {
      assets_array: selectedassets,
      token: token,
      nominee_id: nominee_id,
    })
      .then((result) => {
        console.log(result);
        if (result.json.status) {
          //  setData({name:"",relationship:"",age:"",email:"",phone:"",address:"",gender:""})
          //  getAllAssets()
          //  bottomsheet.current.close()
          navigation.navigate("Linked", { isadded: true });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const getAllAssets = () => {
    simpleGetCallWithErrorResponse(
      ApiConfig.GET_SHARABLE_ASSETS + `?nominee_id=${nominee_id}`,
      { token: token }
    )
      .then((data) => {
        if (data) {
          console.log(data);
          setSharedAssets(data.json.data);
          //  setLoading(false)
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  useEffect(() => {
    getAllAssets();
  }, []);

  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("LinkedAssets")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontSize: 22, color: "#FFFFFF" }}>Select Assets</Text>
        <View></View>
      </View>

      <ScrollView style={{ flex: 0.2 }}>
        {assets.length != 0 ? (
          assets.map((single) => {
            return (
              <View
                style={{
                  width: Dimensions.get("screen").width - 32,
                  backgroundColor: "#1F1D2B",
                  height: 70,
                  marginLeft: 16,
                  marginRight: 16,
                  marginTop: 10,
                  borderRadius: 10,
                  alignItems: "center",
                  justifyContent: "space-between",
                  flex: 1,
                  flexDirection: "row",
                }}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderColor: COLORS.light_green,
                    borderWidth: 1,
                    borderRadius: 50,
                    alignItems: "center",
                    marginLeft: 10,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 22,
                      color: "#FFFFFF",
                      marginTop:5
                    }}
                  >
                    {single.title[0]}
                  </Text>
                </View>
                <Text
                  style={{
                    fontSize: 17,
                    color: "#FFFFFF",
                  }}
                >
                  {single.title}
                </Text>
                <View>
                  <CheckBox
                    style={styles.checkbox}
                    isChecked={
                      selectedassets.indexOf(single.id) > -1 ? true : false
                    }
                    onClick={() => {
                      selectedassets.indexOf(single.id) > -1
                        ? setselectedAssets(
                            selectedassets.filter((value) => value != single.id)
                          )
                        : setselectedAssets([...selectedassets, single.id]);
                      console.log(selectedassets);
                    }}
                    // color={true ? '#0CFEBC' : undefined}
                    checkBoxColor="#0CFEBC"
                  />
                </View>
              </View>
            );
          })
        ) : (
          <Spinner visible={loading} />
        )}
      </ScrollView>

      <LinearGradient
        colors={["#FFBF35", "#FFA900"]}
        style={{
          width: 65,
          borderRadius: 50,
          flex: 0.1,
          left: "80%",
          bottom: "1%",
        }}
      >
        <TouchableOpacity
          onPress={() => handleSubmit()}
          style={{
            width: 65,
            height: 65,
            borderRadius: 50,
            color: "#FFFFFF",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <AntDesign name="arrowright" size={24} color="black" />
        </TouchableOpacity>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  checkbox: {
    marginRight: 5,
    color: "#0CFEBC",
    borderColor: "#0CFEBC",
  },
});
