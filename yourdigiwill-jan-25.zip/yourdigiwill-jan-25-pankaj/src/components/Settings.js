import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  TextInput,
  ActivityIndicator,
  Modal
} from "react-native";
import Header from "./Header";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import ToggleSwitch from "toggle-switch-react-native";
import { COLORS } from "./colors";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  simpleGetCallWithErrorResponse,
  PostCallWithErrorResponse,
  postWithAuthCall,
} from "../../api/ApiServices";
import { AppContext } from "../../user/AppContext";
import { useIsFocused } from "@react-navigation/native";
import RBSheet from "react-native-raw-bottom-sheet";
import ApiConfig from "../../api/ApiConfig";
import SelectDropdown from "react-native-select-dropdown";
import { showMessage, hideMessage } from "react-native-flash-message";

export default function Settings({ navigation ,route}) {
 
  
  
  //const {name}=useContext(AppContext)
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [activated_kyc, setKyc] = useState(false);
  const focused = useIsFocused();
  const bottomsheet = useRef();
  const [state, setState] = useState([]);
  const [data, setData] = useState({ aadhar_no: "", pan_no: "" });
  const [verifying, setverifying] = useState(false);
  const [panverifying, setpanverifying] = useState(false);
  const [aadharverifying, setaadharverifying] = useState(false);
  const [doc, setDoc] = useState("Aadhaar Card");
  const [loading, setLoading] = useState(false);
  const [clientId, setclientid] = useState("");
  const [modalVisible, setModalVisible] = useState(false);

  const { token,setPin } = useContext(AppContext);
  const handleKycValidation = () => {
    bottomsheet.current.open();
  };
  

  const getProfile = () => {
    setLoading(true);
    simpleGetCallWithErrorResponse(ApiConfig.GET_PROFILE, { token: token })
      .then((data) => {
        if (data.json.result) {
          console.log("============================");
          console.log(data);
          setState(data.json.data);
          setData({
            ...data,
            aadhar_no: data.json.data.national_id_card,
            pan_no: data.json.data.pan_id,
          });
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };
  useEffect(()=>{
    if(route.params)
    if(route.params.openSheet)
    bottomsheet.current.open()
  
    
  })
  useEffect(() => {
    AsyncStorage.getItem("name").then((name) => {
      setName(name);
    });

    AsyncStorage.getItem("email").then((email) => {
      setEmail(email);
    });
  }, [focused]);
  
  useEffect(() => {
    getProfile();
  }, [focused]);

  // Surepass Start

  const sendOtp = () => {
    if (data.aadhar_no.length != 12) {
      showMessage({
        message: "Please enter valid aadhar number",
        type: "danger",
      });
      return;
    }
    setverifying(true);

    console.log({ aadhar_number: data.aadhar_no, token: token });
    PostCallWithErrorResponse(ApiConfig.GENERATE_AADHAR_OTP, {
      aadhar_number: data.aadhar_no,
      token: token,
    })
      .then((result) => {
        console.log(result);
        setaadharverifying(false);
        if (result.json.status) {
          showMessage({
            message: result.json.message,
            type: "success",
          });
          setclientid(result.json.client_id);
        } else {
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
        setverifying(false);
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const VerifyPan = () => {
    if (data.pan_no.length != 10) {
      showMessage({
        message: "Please enter the valid pan no",
        type: "danger",
      });
      bottomsheet.current.close();
      return;
    }

    setpanverifying(true);
    PostCallWithErrorResponse(ApiConfig.VERIFY_PAN, {
      pan_id: data.pan_no,
      name: state.legal_name,
      mobile_no: state.mobile_no,
      origin: "user",
      token: token,
    })
      .then((result) => {
        console.log(result);
        setpanverifying(false);
        if (result.json.status) {
          showMessage({
            message: result.json.message,
            type: "success",
          });
          bottomsheet.current.close();
        } else {
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const SubmitAdharOtp = () => {
    setaadharverifying(true);

    console.log({ aadhar_number: state.national_id_card, token: token });
    PostCallWithErrorResponse(ApiConfig.SUBMIT_AADHAR_OTP, {
      otp: data.otp,
      client_id: clientId,
      name: state.legal_name,
      email: state.email,
      mobile_no: state.mobile_no,
      origin: "user",
      aadhar_number: data.aadhar_no,
      token: token,
    })
      .then((result) => {
        setaadharverifying(false);
        console.log(result);
        if (result.json.status) {
          showMessage({
            message: result.json.message,
            type: "success",
          });
          bottomsheet.current.close();
        } else {
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const handleDocChange = (selectedItem) => {
    setDoc(selectedItem);
  };

  // Surepass End

  const handleLogout = () => {
    setPin(null)
    AsyncStorage.clear();
    setTimeout(() => {
      navigation.navigate("LoginSignup");
    }, 1000);
  };
  const handleCancel = () => {
    setModalVisible(false);
  };

const handleDeleteAccount=()=>{
  deleteAccount();
  showMessage({message:"We are sad to see you go. your account will be deleted within 72 hours. Thank You",type:"info"})
  setModalVisible(false);
}
const deleteAccount =async()=>{
  postWithAuthCall(
    ApiConfig.DELETE_USER_ACCOUNT,{}
  ).then((response)=>{
     console.log('response',response);
     if(response?.status==true){
      showMessage({
        message: response?.message,
        type: "success",
      });
      handleLogout()
     }
  }).catch((err)=>{
     alert("Something went wrong");
  })
}


  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
          marginLeft: 10,
          marginRight: 5,
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Home")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" }}>
          Settings
        </Text>
        <View></View>
      </View>
      <TouchableOpacity
        onPress={() => navigation.navigate("ViewProfile")}
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          backgroundColor: "rgba(5, 160, 129, 0.2)",
          marginTop: 20,
          borderRadius: 10,
          marginLeft: 10,
          marginRight: 10,
        }}
      >
        <View style={styles.header}>
          <TouchableOpacity
            style={{
              width: 60,
              height: 60,
              borderRadius: 50,
              backgroundColor: "#F57025",
              marginLeft: 21,
              alignItems: "center",
              justifyContent: "center",
              borderColor: "black",
              borderStyle: "solid",
              borderWidth: 1,

              marginTop: 10,
            }}
          >
            {name ? (
              <Text
                style={{ fontFamily: "System", fontSize: 26, color: "#FFFFFF" }}
              >
                {name.charAt(0)}
              </Text>
            ) : (
              <></>
            )}
          </TouchableOpacity>
          <View>
            <Text
              style={{
                fontFamily: "System",
                fontSize: 16,
                color: "#0CFEBC",
                marginLeft: 5,
              }}
            >
              {state.legal_name ? state.legal_name : ""}
            </Text>
            <Text
              style={{
                fontFamily: "System",
                fontSize: 16,
                color: "#FFFFFF",
                marginLeft: 5,
              }}
            >
              {state.email ? state.email : ""}
            </Text>
          </View>
        </View>
        <AntDesign
          name="right"
          size={20}
          color="#FFFFFF"
          style={{ marginRight: 2 }}
        ></AntDesign>
      </TouchableOpacity>
      {state.kyc_completed ? (
        console.log("kyc_completed")
      ) : (
        <View>
          <TouchableOpacity
            onPress={() => {
              handleKycValidation();
            }}
            style={{
              marginBottom: 20,
              backgroundColor: "black",
              justifyContent: "center",
              alignItems: "center",
              height: 70,
              flexDirection: "row",
              borderColor: COLORS.light_yello,
              borderWidth: 1,
              borderRadius: 10,
              marginTop: 15,
            }}
          >
            <View>
              <Image
                source={{ uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector+(14).png" }}
                style={{ height: 30, width: 27, margin: 10 }}
              ></Image>
            </View>
            <View>
              <Text style={{ color: "#FFFFFF" }}>KYC Required</Text>
              <Text style={{ color: "#FFFFFF", marginRight: 10 }}>
                Update your KYC ,Its Easy and One Time
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      )}

     
      <TouchableOpacity
        onPress={() => navigation.navigate("Changepin")}
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: 20,
          marginLeft: 15,
          marginRight: 15,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Image
            source={{
              uri: "https://websiteimagesdigiwill1.s3.ap-south-1.amazonaws.com/Vector+(8).png",
            }}
            style={{ height: 22, width: 30, marginLeft: 10 }}
          ></Image>

          <Text
            style={{
              fontFamily: "System",
              fontSize: 18,
              color: "#FFFFFF",
              marginLeft: 15,
            }}
          >
            Change MPIN
          </Text>
        </View>

        <AntDesign
          name="right"
          size={20}
          color="#FFFFFF"
          style={{ marginRight: 2 }}
        ></AntDesign>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate("MyReminders")}
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: 20,
          marginLeft: 15,
          marginRight: 15,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Image
            source={{
              uri: "https://websiteimagesdigiwill1.s3.ap-south-1.amazonaws.com/ant-design_field-time-outlined+(1).png",
            }}
            style={{ height: 26, width: 26, marginLeft: 10 }}
          ></Image>

          <Text
            style={{
              fontFamily: "System",
              fontSize: 18,
              color: "#FFFFFF",
              marginLeft: 15,
            }}
          >
            My Reminders
          </Text>
        </View>
        <AntDesign
          name="right"
          size={20}
          color="#FFFFFF"
          style={{ marginRight: 2 }}
        ></AntDesign>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate("Subscriptionlist")}
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: 20,
          marginLeft: 15,
          marginRight: 15,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Image
            source={{
              uri: "https://websiteimagesdigiwill1.s3.ap-south-1.amazonaws.com/Vector+(12).png",
            }}
            style={{ height: 24, width: 23, marginLeft: 10 }}
          ></Image>

          <Text
            style={{
              fontFamily: "System",
              fontSize: 18,
              color: "#FFFFFF",
              marginLeft: 18,
            }}
          >
            Subscriptions
          </Text>
        </View>

        <AntDesign
          name="right"
          size={20}
          color="#FFFFFF"
          style={{ marginRight: 2 }}
        ></AntDesign>
      </TouchableOpacity>

      {/* <TouchableOpacity
        onPress={() => navigation.navigate("Reffral")}
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: 20,
          marginLeft: 15,
          marginRight: 15,
        }}
      >
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Image
            source={{
              uri: "https://websiteimagesdigiwill1.s3.ap-south-1.amazonaws.com/Vector+(12).png",
            }}
            style={{ height: 24, width: 23, marginLeft: 10 }}
          ></Image>
            <Text
            style={{
              fontFamily: "System",
              fontSize: 18,
              color: "#FFFFFF",
              marginLeft: 18,
            }}
          >
            Reffer and Earn
          </Text>
        </View>

        <AntDesign
          name="right"
          size={20}
          color="#FFFFFF"
          style={{ marginRight: 2 }}
        ></AntDesign>
      </TouchableOpacity> */}
      <TouchableOpacity
        style={{ alignItems: "center", flexDirection: "row" }}
        onPress={() => handleLogout()}
      >
        <Image
          style={{ width: 24, height: 23, marginTop: 20, marginLeft: 20 }}
          source={{
            uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector.png",
          }}
        ></Image>
        <Text
          style={{
            color: COLORS.red_shade,
            fontSize: 22,
            marginTop: 20,
            marginLeft: 20,
          }}
        >
          Sign Out
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={{ alignItems: "center", flexDirection: "row" }}
        onPress={() => {
           setModalVisible(true);
        }}
      >
        <AntDesign style={{ width: 24, height: 23, marginTop: 20, marginLeft: 20 }} name="delete" color={COLORS.light_green} size={25}/>
        <Text
          style={{
            color: COLORS.red_shade,
            fontSize: 22,
            marginTop: 20,
            marginLeft: 20,
          }}
        >
          Delete Account
        </Text>
      </TouchableOpacity>
      {/*  */}

      <RBSheet
        ref={bottomsheet}
        height={400}
        openDuration={250}
        customStyles={{
          container: {
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "#252836",
            borderRadius: 15,
            height: "auto",
          },
        }}
      >
        <ScrollView showsVerticalScrollIndicator={false}>
          <View>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Image
                source={{ uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector+(14).png" }}
                style={{ height: 30, width: 27, margin: 10 }}
              ></Image>
              <Text style={{ color: COLORS.light_yello, fontSize: 22 }}>
                User KYC
              </Text>
            </View>

            {/* fields start */}
            <Text
              style={{ color: COLORS.light_yello, fontSize: 12, marginLeft: 8 }}
            >
              Select Document
            </Text>

            <SelectDropdown
              data={["Aadhaar Card", "Pan Card"]}
              defaultValue={doc}
              buttonStyle={styles.dropDownstyle}
              onSelect={(selectedItem, index) => {
                handleDocChange(selectedItem);
              }}
              // dropdownStyle={{backgroundColor:'black'}}
              // dropdownOverlayColor='black'
              // dropdownBackgroundColor="black"
              rowStyle={{ backgroundColor: "black" }}
              defaultButtonText="Select Document"
              dropdownIconPosition="left"
              rowTextStyle={{ color: "#FFFFFF" }}
              buttonTextStyle={styles.buttonTextStyle}
              buttonTextAfterSelection={(selectedItem, index) => {
                // text represented after item is selected
                // if data array is an array of objects then return selectedItem.property to render after item is selected
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
                // text represented for each item in dropdown
                // if data array is an array of objects then return item.property to represent item in dropdown
                return item;
              }}
            />

            {doc == "Aadhaar Card" ? (
              <View>
                <Text
                  style={{
                    color: COLORS.light_yello,
                    fontSize: 12,
                    marginLeft: 8,
                  }}
                >
                  User's Aadhaar Card
                </Text>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <TextInput
                    style={styles.input3}
                    value={data.aadhar_no}
                    placeholder="Aadhar No"
                    onChangeText={(text) =>
                      setData({ ...data, aadhar_no: text })
                    }
                    placeholderTextColor="#FFFFFF"
                  />
                  <TouchableOpacity onPress={() => sendOtp()}>
                    {verifying ? (
                      <ActivityIndicator
                        size="large"
                        color={COLORS.light_yello}
                        style={{ color: COLORS.light_yello, marginLeft: 20 }}
                      />
                    ) : (
                      <Text
                        style={{ color: COLORS.light_yello, marginLeft: 20 }}
                      >
                        Send Otp
                      </Text>
                    )}
                  </TouchableOpacity>
                </View>
                <Text
                  style={{
                    color: COLORS.light_yello,
                    fontSize: 12,
                    marginLeft: 8,
                  }}
                >
                  Enter OTP
                </Text>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 20,
                  }}
                >
                  <TextInput
                    style={{ ...styles.input3, height: 50 }}
                    value={data.otp}
                    placeholder="Enter OTP"
                    onChangeText={(text) => setData({ ...data, otp: text })}
                    placeholderTextColor="#FFFFFF"
                  />

                  {aadharverifying ? (
                    <ActivityIndicator
                      size="large"
                      color={COLORS.light_yello}
                      style={{ color: COLORS.light_yello, marginLeft: 20 }}
                    />
                  ) : (
                    <TouchableOpacity onPress={() => SubmitAdharOtp()}>
                      <Text
                        style={{ color: COLORS.light_yello, marginLeft: 20 }}
                      >
                        Verify Otp
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            ) : (
              <View>
                <Text
                  style={{
                    color: COLORS.light_yello,
                    fontSize: 12,
                    marginLeft: 8,
                  }}
                >
                  User PAN Card
                </Text>

                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <TextInput
                    style={styles.input3}
                    value={data.pan_no}
                    placeholder="PAN Number"
                    onChangeText={(text) => setData({ ...data, pan_no: text })}
                    placeholderTextColor="#FFFFFF"
                  />
                  {panverifying ? (
                    <ActivityIndicator
                      size="large"
                      color={COLORS.light_yello}
                      style={{ color: COLORS.light_yello, marginLeft: 20 }}
                    />
                  ) : (
                    <TouchableOpacity onPress={() => VerifyPan()}>
                      <Text
                        style={{ color: COLORS.light_green, marginLeft: 20 }}
                      >
                        Verify
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}
          </View>
        </ScrollView>
      </RBSheet>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={{
          flex: 1,
          justifyContent: 'center',
          alignItems: 'center',
          backgroundColor: 'rgba(0,0,0,0.5)',
        }}>
          <View style={{
            width: 300,
            padding: 20,
            backgroundColor: 'white',
            borderRadius: 10,
            alignItems: 'center',
            backgroundColor:COLORS.dark_grey
          }}>
            <Text style={{ fontSize: 18, marginBottom: 20,color:COLORS.white }}>
              Are you sure you want to delete your account?
            </Text>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%' }}>
              <TouchableOpacity
                style={{ backgroundColor: COLORS.red_shade, padding: 10, borderRadius: 5, width: '45%', alignItems: 'center' }}
                onPress={handleDeleteAccount}
              >
                <Text style={{ color: 'white',fontSize: 18 }}>Yes</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={{ backgroundColor: COLORS.light_green, padding: 10, borderRadius: 5, width: '45%', alignItems: 'center' }}
                onPress={handleCancel}
              >
                <Text style={{ color: 'white',fontSize: 18 }}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  header: {
    height: 100,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  dropDownstyle: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    textAlign: "left",
  },
  input3: {
    backgroundColor: "black",
    width: 240,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  input2: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 5,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  buttonTextStyle: {
    color: "#FFFFFF",
    marginLeft: 0,
    fontSize: 16,
    textAlign: "left",
  },
});
