import { StyleSheet,ScrollView, TextInput, TouchableOpacity, Text, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState ,useRef} from 'react';
// import { AntDesign } from '@expo/vector-icons'; 
import Icon  from 'react-native-vector-icons/AntDesign';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import AsyncStorage from '@react-native-async-storage/async-storage';
import { OtpInput } from "react-native-otp-entry";
import { showMessage } from "react-native-flash-message";
import ApiConfig from '../../api/ApiConfig';
import {useContext} from 'react'
import { AppContext } from '../../user/AppContext';

async function setPin(value) {
  await AsyncStorage.setItem('pin', value);
}

export default  function Changepin({route,navigation}) {
    console.log(route)
    const { token,pin} = useContext(AppContext);
    const [loading,setLoading]=useState(false)
    const [data,setData]=useState({mpin:""})
    const [newdata,newsetData]=useState({mpin:""})
    const bottomsheet = useRef();



    useEffect(()=>{useContext

setTimeout(() => {
    setLoading(false)
}, 2000);

    },[])

    const handleSubmit = ()=>{
      
      setLoading(true)
      const formbody=new FormData() 

      formbody.append('old_pin',data.mpin);
     formbody.append('new_pin',newdata.mpin);
   
      console.log(formbody)
      fetch(ApiConfig.CHANGE_PIN,{ method:'post',
      headers:{  
    
        Authorization: `Token ${token}`
    
        } , body :formbody})
      .then(function(response){
    
        return response.json();
      })
      .then(function(json){
      if (json.result){
        setPin(newdata.mpin)
        setLoading(false)
        showMessage({
          message: json.message,
          type: "success",

        });
        navigation.navigate('Home')
    
      }
      else{
        showMessage({
          message:json.message,
          type: "danger",
         

        });
        navigation.navigate('Home')
      }
   
    
      })
      .catch(function(error) {
        bottomsheet.current.close()
        setTimeout(() => {
          setLoading(false)
          showMessage({
            message:json.message,
            type: "danger",
          });
          navigation.navigate('Home')
        }, 1000);
        
      
      console.log('There has been a problem with your fetch operation: ' + error.message);

    
        throw error;
      });




       
      }

  return (
  
  
  <KeyboardAvoidingView style={{flex:1}}>
{
          loading ? 
          <View style={{flex:1,justifyContent:"center",alignItems:"center"}}>
<ActivityIndicator size="small"  color="#0000ff" />

          </View>

          :
          <SafeAreaView style={styles.container}>
          <ScrollView style={{flex:1}}>
    
          
           <View style={styles.header}>
           <TouchableOpacity onPress={() => navigation.navigate('Home')}>
<AntDesign name='left' size={30} color='#FFFFFF' style={{marginRight:2}}></AntDesign>
</TouchableOpacity>
    
           <Text  style={{fontSize:22,color:'#FFFFFF',paddingBottom:10,marginTop:10}}>
                   Enter New MPIN 
               </Text>
            <View></View>
           </View>
           <View style={styles.body}>
        <Text style={{fontSize:22,color:'#0CFEBC',marginTop:30}}> 
        Your New MPIN Code
        </Text>
        <Text style={{fontSize:14,color:"#8A8D9F",marginTop:20}}> 
       To Setup your PIN code ,Enter 4 digit code then Confirm it below
        </Text>



    <Text style={{fontSize:14,color:"#8A8D9F",marginTop:10,paddingBottom:10,alignItems:'flex-start',marginLeft:25}}> 
       Enter Old MPIN
        </Text>
      
<View style={styles.input}>

      



<OtpInput
                  numberOfDigits={4}
                  onTextChange={(text) => setData({ ...data, otp: text })}
                  // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
                  // onCodeChanged = {code => { this.setState({code})}}

                  // codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}    autoFocusOnLoad
                  keyboardAppearance	='dark'
                  onFilled={(text)=>setData({...data,mpin:text})}
                  theme={
                    {
                      pinCodeTextStyle:{color:"#0CFEBC"},
                      containerStyle:{width: '80%', height: 100,marginTop:10},
                      pinCodeContainerStyle: {borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:55,height:60,fontSize:20},
                      filledPinCodeContainerStyle: {borderBottomColor:'#0CFEBC',}
                    }
                  }
              />

</View>



<Text style={{fontSize:14,color:"#8A8D9F",marginTop:20,paddingBottom:10}}> 
       Enter NEW MPIN
        </Text>

<View style={styles.input}>
{/* <OTPInputView
    style={{width: '80%'}}
    pinCount={4}
    onCodeChanged	= {(text)=>newsetData({...newdata,mpin:text})}
    // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
    // onCodeChanged = {code => { this.setState({code})}}
    codeInputFieldStyle={{borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:50,height:55,fontSize:20}}
    codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}
    autoFocusOnLoad
    keyboardAppearance	='dark'
    onCodeFilled =  {(text)=>newsetData({...newdata,mpin:text})}
/> */}
<OtpInput
        numberOfDigits={4}
        onTextChange={(text) => {(text)=>newsetData({...newdata,mpin:text})}}
        // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
        // onCodeChanged = {code => { this.setState({code})}}

        // codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}    autoFocusOnLoad
        keyboardAppearance	='dark'
        onFilled= {(text)=>newsetData({...newdata,mpin:text})}
        theme={
          {
            pinCodeTextStyle:{color:"#0CFEBC"},
            containerStyle:{width: '80%', height: 100,marginTop:10},
            pinCodeContainerStyle: {borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:55,height:60,fontSize:20},
            filledPinCodeContainerStyle: {borderBottomColor:'#0CFEBC',}
          }
        }
              />

</View>
     
          {/* <TextInput
            style={styles.input}
            value={data.phone}
            placeholder="Otp"
            keyboardType="numeric"
            onChangeText = {(text)=>setData({...data,phone:text})}
    
            placeholderTextColor="#8A8D9F" 
          />

     */}
  

    <TouchableOpacity
          onPress={()=>handleSubmit()}
            style={{width:295,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#0CFEBC',
            borderRadius:25,
            marginTop:20,
            marginBottom:10
         }}
            
          >
            <Text  style={{fontSize:20,color:'black'}}>Set Pin

            <Icon name="doubleright" size={20} marginLeft={3} color="black" />
            </Text>
          </TouchableOpacity>
          <TouchableOpacity   onPress={()=>navigation.navigate('SetupMPIN')}>
        
    
    {/* <Text  style={{fontSize:16,fontWeight:'bold',color:'#FFFFFF',paddingBottom:5,marginTop:10,paddingLeft:150}}>
            Forgot MPIN
        </Text> */}
     
    </TouchableOpacity>
           </View>
          
           
           </ScrollView>
    
       </SafeAreaView>

      } 


  
    
  </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
    container: {
     flex:1,
     backgroundColor:'black',
  
   
    },
    header:{
        flex:0.07,
        backgroundColor:'#252836',
      alignItems:'center',
      marginBottom:30,
      justifyContent:'space-between',
      flexDirection:'row',
      marginLeft:10,
      marginRight:5

    },
    body:{
        flex:0.4,
        backgroundColor:"#252836",
        marginTop:20,
        borderRadius:10,
       marginRight:10,
       marginLeft:10,
       alignItems:'center'
    },
    input:{
     flex:1,
     flexDirection:'row',
    



    }
    
})