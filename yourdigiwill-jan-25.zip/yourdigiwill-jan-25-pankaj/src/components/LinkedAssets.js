import {
  ScrollView,
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import Header from "./Header";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import { simpleGetCallWithErrorResponse ,DeleteCallWithErrorResponse} from "../../api/ApiServices";
import ApiConfig from "../../api/ApiConfig";
import { AppContext } from "../../user/AppContext";
import LinearGradient from "react-native-linear-gradient";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { COLORS } from "./colors";
import AntDesign from "react-native-vector-icons/AntDesign";
import Entypo from "react-native-vector-icons/Entypo";
import Spinner from "react-native-loading-spinner-overlay/lib";
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from "react-native-popup-menu";
import ReactNativeBiometrics, { BiometryTypes } from "react-native-biometrics";
const rnBiometrics = new ReactNativeBiometrics();
import { showMessage } from "react-native-flash-message";
export default function LinkedAssets({ color, text, path, navigation, route }) {
  const { nominee_id, name } = route.params;
  const [active, setActive] = useState("assets");
  const [nominees, setNominees] = useState([]);
  const [sharedbymenominees, setSharedbymeNominees] = useState([]);
  const [sharedbymeAssets, setSharedbymeAssets] = useState([]);
  const [loading, setLoading] = useState(true);
  const { token } = useContext(AppContext);
  const { biometryType } =  rnBiometrics.isSensorAvailable();

  const MenuFunction = (nominee_id) => {
    if (sharedbymeAssets.length == 1) {
      showMessage({
        message: "You can't delete all nominees",
        type: "danger",
      });
      return;
    }
   
    
    rnBiometrics
      .simplePrompt({ promptMessage: "Confirm fingerprint" })
      .then((resultObject) => {
        const { success } = resultObject;

        if (success) {
          console.log("successful biometrics provided");
          DeleteCallWithErrorResponse(ApiConfig.UNLINK_NOMINEE, {
            id: nominee_id,
          })
            .then((result) => {
              console.log(result);
              if (result.json.result) {
                showMessage({
                  message: "Asset Removed Successfully",
                  type: "success",
                });
                getAllSubscription();
              }
            })
            .catch((error) => {
              console.log("api response", error);
            });
        } else {
          console.log("user cancelled biometric prompt");
        }
      })
      .catch(() => {
        alert("No biometrics available")
        
      });
  };

  const getAllSharedByMeAssets = () => {
    setLoading(true)
    simpleGetCallWithErrorResponse(
      ApiConfig.GET_SHARED_ASSETS_AND_LIABLITY +
        `?nominee_id=${nominee_id}&will_type=${active}`,
      { token: token }
    )
      .then((data) => {
        if (data) {
         
          setSharedbymeAssets(data.json.Data);
          setLoading(false);
        }
      })
      .catch((error) => {
        showMessage({message:"Error Fetching data"})
      });
  };
  const getAllNominees = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_NOMINEES, { token: token })
      .then((data) => {
        if (data) {
          console.log(data);
          setNominees(data.json.data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };
  const handleAssetDelete=(assetid)=>{

     DeleteCallWithErrorResponse(ApiConfig.SHARE_ASSET,{id:nominee_id,assets_id:assetid}).then(async(res)=>{
      const resp = await res.json
      if(resp.status){
      showMessage({message:"Asset Deleted Sucessfully",type:"success"})
      getAllSharedByMeAssets()
      }
      else{
        showMessage({message:"Error deleting assets",type:"danger"})
      }
     })
  }

  useEffect(() => {
    // getAllNominees()
  
    getAllSharedByMeAssets();
  }, [active, navigation.isFocused()]);

  return (
    
    <SafeAreaView style={{ height: "100%", backgroundColor: "black" }}>
      <Spinner visible={loading}/>
      <View style={{ flex: sharedbymeAssets.length == 0 ? 0.8 : 0.3 }}>
        <View
          style={{
            backgroundColor: "#252836",
            height: 50,
            alignItems: "center",
            justifyContent: "space-between",
            flexDirection: "row",
            marginBottom: 10,
          }}
        >
          <TouchableOpacity
            onPress={() => navigation.goBack()}
          >
            <AntDesign
              name="left"
              size={30}
              color="#FFFFFF"
              style={{ marginRight: 2 }}
            ></AntDesign>
          </TouchableOpacity>
          <Text style={{ fontSize: 22, color: "#FFFFFF", marginLeft: 20 }}>
            {name}
          </Text>
          <View></View>
          <View></View>
          <View style={{ marginRight: 10 }}>
            <Menu>
              <MenuTrigger>
                <Entypo name="dots-three-vertical" size={22} color="#FFFFFF" />
              </MenuTrigger>

              <MenuOptions style={{ height: 30 }}>
                <MenuOption
                  onSelect={() => MenuFunction(nominee_id)}
                  text="Unlink"
                />
                
              </MenuOptions>
            </Menu>
          </View>
        </View>
        <View style={styles.toggleParent}>
          <TouchableOpacity
            onPress={() => setActive("assets")}
            style={{
              width: 108,
              height: 35,
              paddingLeft: 8,
              paddingRight: 8,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: active == "assets" ? "#0CFEBC" : "black",
              borderRadius: 25,
            }}
          >
            <Text
              style={{
                fontSize: 13,
                color: active == "assets" ? "black" : "#FFFFFF",
              }}
            >
              Assets
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => setActive("liability")}
            style={{
              width: 108,
              height: 35,
              paddingLeft: 8,
              paddingRight: 8,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: active == "liability" ? "#0CFEBC" : "black",
              borderRadius: 25,
            }}
          >
            <Text
              style={{
                fontSize: 13,
                color: active == "liability" ? "black" : "#FFFFFF",
              }}
            >
              Liablities
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      {active == "assets" ? (
        <>
          <ScrollView style={{ flex: 0.2 }}>
            {sharedbymeAssets.length != 0 ? (
              sharedbymeAssets.map((single) => {
                return (
                  <View
                    style={{
                      backgroundColor: COLORS.light_grey,
                      // height: 70,
                      width: Dimensions.get("screen").width - 32,

                      marginLeft: 16,
                      marginRight: 16,
                      marginTop: 10,
                      borderRadius: 10,
                    }}
                  >
                    <View
                      style={{
                        marginLeft: 16,
                        marginRight: 16,
                        marginTop: 15,
                        borderRadius: 10,
                        alignItems: "center",
                        justifyContent: "space-between",
                        flex: 1,
                        flexDirection: "row",
                      }}
                    >
                      <View
                        style={{
                          width: 30,
                          height: 30,
                          borderColor: COLORS.light_green,
                          borderWidth: 1,
                          borderRadius: 50,
                          alignItems: "center",
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 16,
                            color: "#FFFFFF",
                            marginTop:5
                          }}
                        >
                          {single.title[0]}
                        </Text>
                      </View>
                      <Text
                        style={{
                          fontSize: 17,
                          color: "#FFFFFF",
                        }}
                      >
                        {single.title}
                      </Text>
                      <View>
                      <Menu>
                            <MenuTrigger>
                              <Entypo name="dots-three-vertical" size={22} />
                            </MenuTrigger>

                            <MenuOptions>
                             
                              <MenuOption onSelect={()=>{
                                handleAssetDelete(single.id)
                              }}>
                                <Text>
                                  Delete
                                </Text>
                              </MenuOption>
                            </MenuOptions>
                          </Menu>
                      </View>
                    </View>
                    <View
                      style={{
                        flex: 1,
                        height: 1,
                        backgroundColor: "white",
                        marginLeft: 5,
                        marginRight: 5,
                        marginTop: 10,
                      }}
                    />

                    <View
                      style={{
                        flexDirection: "column",
                        marginBottom: 5,
                        marginLeft: 5,
                        marginTop: 5,
                      }}
                    >
                      <Text style={{ color: "#989898" }}>
                        {single.title}
                      </Text>

                      {single.amount ? (
                        <Text style={{ color: "#989898" }}>
                          ₹{single.amount}
                        </Text>
                      ) : (
                        ""
                      )}

                      {single.account_no ? (
                        <Text style={{ color: "#989898" }}>
                          {single.account_no}
                        </Text>
                      ) : (
                        ""
                      )}
                    </View>
                  </View>
                );
              })
            ) : (
              <View style={{ alignItems: "center", justifyContent: "center" }}>
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate("GetAllassets", {
                      nominee_id: route.params.nominee_id,
                    })
                  }
                  style={{
                    width: 91,
                    height: 91,
                    borderRadius: 50,
                    color: "#FFFFFF",
                    marginRight: 21,
                    alignItems: "center",
                    justifyContent: "center",
                    marginTop: 10,
                    backgroundColor: "#252836",
                  }}
                >
                  <Image
                    style={styles.rndImage}
                    source={require("../../assets/sharenow.png")}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: 21,
                    color: "#FFFFFF",
                    marginTop: 5,
                    paddingBottom: 10,
                  }}
                >
                  Start Sharing Now!
                </Text>
              </View>
            )}
          </ScrollView>

          <View
            style={{
              alignItems: "flex-end",
              marginRight: 10,
              marginBottom: 10,
            }}
          >
            <LinearGradient
              colors={["#FFBF35", "#FFA900"]}
              style={{ width: 65, borderRadius: 50 }}
            >
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("GetAllassets", {
                    nominee_id: nominee_id,
                  })
                }
                style={{
                  width: 65,
                  height: 65,
                  borderRadius: 50,
                  color: "#FFFFFF",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FontAwesome name="plus" size={24} color="black" />
              </TouchableOpacity>
            </LinearGradient>
          </View>
        </>
      ) : (
        <>
          <ScrollView style={{ flex: 0.2 }}>
            {sharedbymeAssets.length != 0 ? (
              sharedbymeAssets.map((single) => {
                return (
                  <View
                    style={{
                      backgroundColor: COLORS.light_grey,
                      // height: 70,
                      width: Dimensions.get("screen").width - 32,

                      marginLeft: 16,
                      marginRight: 16,
                      marginTop: 10,
                      borderRadius: 10,
                    }}
                  >
                    <View
                      style={{
                        marginLeft: 16,
                        marginRight: 16,
                        marginTop: 15,
                        borderRadius: 10,
                        alignItems: "center",
                        justifyContent: "space-between",
                        flex: 1,
                        flexDirection: "row",
                      }}
                    >
                      <View
                        style={{
                          width: 30,
                          height: 30,
                          borderColor: COLORS.light_green,
                          borderWidth: 1,
                          borderRadius: 50,
                          alignItems: "center",
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 16,
                            color: "#FFFFFF",
                            marginTop:5
                          }}
                        >
                          {single.title[0]}
                        </Text>
                      </View>
                      <Text
                        style={{
                          fontSize: 17,
                          color: "#FFFFFF",
                        }}
                      >
                        {single.title}
                      </Text>
                      <View>
                      <Menu>
                            <MenuTrigger>
                              <Entypo name="dots-three-vertical" size={22} />
                            </MenuTrigger>

                            <MenuOptions>
                             
                              <MenuOption onSelect={()=>{
                                handleAssetDelete(single.id)
                              }}>
                                <Text>
                                  Delete
                                </Text>
                              </MenuOption>
                            </MenuOptions>
                          </Menu>
                      </View>
                    </View>
                    <View
                      style={{
                        flex: 1,
                        height: 1,
                        backgroundColor: "white",
                        marginLeft: 5,
                        marginRight: 5,
                        marginTop: 10,
                      }}
                    />

                    <View
                      style={{
                        flexDirection: "column",
                        marginBottom: 5,
                        marginLeft: 5,
                        marginTop: 5,
                      }}
                    >
                      <Text style={{ color: "#989898" }}>
                        {single.title}
                      </Text>

                      {single.amount ? (
                        <Text style={{ color: "#989898" }}>
                          ₹{single.amount}
                        </Text>
                      ) : (
                        ""
                      )}

                      {single.account_no ? (
                        <Text style={{ color: "#989898" }}>
                          {single.account_no}
                        </Text>
                      ) : (
                        ""
                      )}
                    </View>
                  </View>
                );
              })
            ) : (
              <View style={{ alignItems: "center", justifyContent: "center" }}>
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate("GetAllassets", {
                      nominee_id: route.params.nominee_id,
                    })
                  }
                  style={{
                    width: 91,
                    height: 91,
                    borderRadius: 50,
                    color: "#FFFFFF",
                    marginRight: 21,
                    alignItems: "center",
                    justifyContent: "center",
                    marginTop: 10,
                    backgroundColor: "#252836",
                  }}
                >
                  <Image
                    style={styles.rndImage}
                    source={require("../../assets/sharenow.png")}
                  />
                </TouchableOpacity>
                <Text
                  style={{
                    fontSize: 21,
                    color: "#FFFFFF",
                    marginTop: 5,
                    paddingBottom: 10,
                  }}
                >
                  Start Sharing Now!
                </Text>
              </View>
            )}
          </ScrollView>

          <View
            style={{
              alignItems: "flex-end",
              marginRight: 10,
              marginBottom: 10,
            }}
          >
            <LinearGradient
              colors={["#FFBF35", "#FFA900"]}
              style={{ width: 65, borderRadius: 50 }}
            >
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate("GetAllassets", {
                    nominee_id: nominee_id,
                  })
                }
                style={{
                  width: 65,
                  height: 65,
                  borderRadius: 50,
                  color: "#FFFFFF",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FontAwesome name="plus" size={24} color="black" />
              </TouchableOpacity>
            </LinearGradient>
          </View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  toggleParent: {
    flexDirection: "row",
    backgroundColor: "black",
    justifyContent: "center",
    alignSelf: "center",
    borderRadius: 25,
    marginTop: 10,
    height: 37,
    borderColor: "#0CFEBC",
    borderWidth: 1,
  },
  header: {
    flex: 1,
  },
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
