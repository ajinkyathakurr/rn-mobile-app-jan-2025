import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
  BackHandler,
} from "react-native";

import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import ToggleSwitch from "toggle-switch-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useIsFocused } from "@react-navigation/native";
import { COLORS } from "../colors";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../../api/ApiServices";
import Spinner from "react-native-loading-spinner-overlay";
export default function CommunicationDetail({ navigation, route }) {
  const [loading, setLoading] = useState(false);
  const { token } = useContext(AppContext);
  const focused = useIsFocused();
  const [data, setData] = useState([]);

  const getNomineeList = () => {
    simpleGetCallWithErrorResponse(ApiConfig.ADD_NOMINEE_AFTERYOU, {
      token: token,
    })
      .then((data) => {
        if (data.json.status) {
          console.log(data.json);
          setData(data.json.data);
          //return Response({'result':True,'order_data':plans.data,'nominees_data':nominee_data.data,'plan_name':orders.order_product.plan_name,'expiry_data':expiry_duration,"assign":assign},status=status.HTTP_200_OK)
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };
  useEffect(() => {
    getNomineeList();
  }, [focused]);

  return (
    <SafeAreaView style={{ backgroundColor: COLORS.black, height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          marginTop: 10,
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Home")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2, marginLeft: 3 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" }}>
          Digiwill AfterYou
        </Text>

        <View></View>
      </View>
      {loading ? (
        <Spinner color={COLORS.light_green} visible={loading} />
      ) : (
        <></>
      )}

      <View>
        <View
          style={{
            height: 150,
            borderWidth: 1,
            borderStyle: "solid",
            backgroundColor: "#2D3845",
            marginTop: 20,
            borderRadius: 15,
            marginLeft: 16,
            marginRight: 16,
            borderColor: COLORS.light_green_new,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "flex-end",
              marginTop: -15,
              marginRight: 15,
            }}
          >
            <TouchableOpacity
              style={{
                height: 30,
                width: 100,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: COLORS.light_green_new,
                borderRadius: 25,

                marginLeft: 16,
              }}
            >
              <Text
                style={{ fontSize: 12, color: "white", fontWeight: "bold" }}
              >
                Activated
                {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
              </Text>
            </TouchableOpacity>
          </View>

          <Text
            style={{
              color: COLORS.light_green_new,
              marginLeft: 10,
              fontSize: 20,
              fontWeight: "bold",
              marginTop: 10,
            }}
          >
            Digiwill Afteryou Plan
          </Text>

          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              marginRight: 20,
              marginLeft: 20,
            }}
          >
            <Text
              style={{
                color: "#FFFFFF",
                marginLeft: 10,
                fontSize: 20,
                fontWeight: "bold",
              }}
            >
              Expiry Date
            </Text>

            <TouchableOpacity
              onPress={() => navigation.navigate("CommunicationAddNominee")}
              style={{
                height: 30,
                width: 100,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: COLORS.light_yello,
                borderRadius: 25,
                marginTop: 20,

                marginBottom: 20,
                marginLeft: 16,
              }}
            >
              <Text style={{ fontSize: 12, color: "black" }}>
                Add Nominee
                {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <View>
          <Text
            style={{
              color: "white",
              marginLeft: 10,
              fontSize: 20,
              marginTop: 15,
            }}
          >
            {" "}
            Your Nominees
          </Text>

          {data && data.length != 0
            ? data.map((single) => {
                return (
                  <View
                    style={{
                      flexDirection: "row",
                      justifyContent: "space-between",
                      marginRight: 10,
                      marginLeft: 10,
                      alignItems: "center",
                      marginTop: 10,
                      height: 60,
                      backgroundColor: COLORS.light_grey,
                      borderRadius: 10,
                    }}
                  >
                    <View
                      style={{ flexDirection: "row", alignItems: "center" }}
                    >
                      <View
                        style={{
                          width: 40,
                          height: 40,
                          borderColor: COLORS.light_green,
                          borderWidth: 1,
                          borderRadius: 50,
                          alignItems: "center",
                          marginLeft: 10,
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 22,
                            color: "#FFFFFF",
                            marginTop:5
                          }}
                        >
                          {single.name[0]}
                        </Text>
                      </View>
                      <Text
                        style={{
                          color: "white",
                          marginLeft: 20,
                          fontWeight: "bold",
                        }}
                      >
                        {single.name}
                      </Text>
                    </View>

                    <View></View>
                  </View>
                );
              })
            : ""}
        </View>
      </View>

      <TouchableOpacity
        onPress={() => navigation.navigate("CommunicationAddNominee")}
        style={{
          alignItems: "center",
          width: 60,
          position: "absolute",
          bottom: 40,
          right: 20,
          height: 60,
          color: "#FFFFFF",
          borderRadius: 50,
          justifyContent: "center",
          backgroundColor: "#FFBF35",
        }}
      >
        <FontAwesome name="plus" size={24} color="black" />
      </TouchableOpacity>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({});
