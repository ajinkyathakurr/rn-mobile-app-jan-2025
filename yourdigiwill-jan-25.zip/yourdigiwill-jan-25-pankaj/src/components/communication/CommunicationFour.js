import { StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import LinearGradient from 'react-native-linear-gradient';
import { PostCallWithErrorResponse, simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import { AppContext } from '../../../user/AppContext';
import RazorpayCheckout from 'react-native-razorpay';
import icon from "../../../assets/dwicon.png"
import { NavigationContainer } from '@react-navigation/native';
export default function CommunicationFour({route,navigation}) {
const {data}=route.params;
const [plans,setPlan]=useState([])
const [loading,setLoading]=useState(true)
const {token} =useContext(AppContext)
const [Index, setIndex] = useState(0);


  const handleSubmit = ()=>{
    var options = {
        description: 'Credits towards consultation',
        image: icon,
        currency: 'INR',
        key: 'rzp_live_vMJUowugyM5w9E',
        amount: data.order.order_amount,
        name: 'Digiwill',
        order_id: data.order.order_id_razorpay,//Replace this with an order_id created using Orders API.
        prefill: {
          email: '',
          contact: '',
          name: ''
        },
        theme: {color: '#53a20e'}
      }
      RazorpayCheckout.open(options).then((data) => {
        // handle success
        console.log(data)
        alert(`Success: ${data.razorpay_payment_id}`);

        PostCallWithErrorResponse(ApiConfig.COMMUNICATION_VERIFICATION , 
          {...data,token:token}
               )
             .then((result) => {
               console.log(result)
               if (result.json) {
                navigation.navigate('Home')
               }
             })
             .catch((error) => {
               console.log("api response", error);
           
             });
      }).catch((error) => {
        // handle failure

        alert(`Error: Payment was cancelled`);
        navigation.goBack()
      });
  

  
  }


  return (
    <SafeAreaView
    style={{backgroundColor:'#252836',height:'100%',flex:1}}

  >

<View style={{ backgroundColor: "#252836",marginTop:10,height:50,alignItems:'center',justifyContent:'center',flex:0.1}}>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
   Order Summery
        </Text>
 
        </View>
        <View style={{flex:0.9,borderColor:'#FFFFFF',borderWidth:1,marginLeft:10,marginRight:10,borderRadius:10}}>
        
                    <View style={{flexDirection:'row',justifyContent:'space-between',marginRight:20,marginLeft:20,marginTop:10}}>
              
                                   <Text style={{color:"#FFFFFF"}}>{data.plan_name}</Text>
                                   <View></View>
                                   <Text style={{color:"#FFFFFF",marginRight:5}}>₹{data.plan_price}</Text>
                                    </View>
                                    <View style={{flexDirection:'row',justifyContent:'space-between',marginRight:20,marginLeft:20,marginTop:10}}>
              
              <Text style={{color:"#FFFFFF"}}>Promotion Applied</Text>
              <View></View>
              <Text style={{color:"#FFFFFF",marginRight:5}}>₹{data.promotion}</Text>
               </View>
               <View style={{flexDirection:'row',justifyContent:'space-between',marginRight:20,marginLeft:20,marginTop:10}}>
              
              <Text style={{color:"#FFFFFF"}}>Total</Text>
              <View></View>
              <Text style={{color:"#FFFFFF",marginRight:5}}>₹{data.price_after_promotion}</Text>
               </View>
               <Text  style={{color:"#0CFEBC" ,marginLeft:10}}>--------------------------------------</Text>
               <View style={{flexDirection:'row',justifyContent:'space-between',marginRight:20,marginLeft:20,marginTop:10}}>
             
              <Text style={{color:"#FFFFFF"}}>Taxes</Text>
              <View></View>
              <Text style={{color:"#FFFFFF",marginRight:5}}>₹{data.order.gst_amount}</Text>
               </View>
               <View style={{flexDirection:'row',justifyContent:'space-between',marginRight:20,marginLeft:20,marginTop:10}}>
             
             <Text style={{color:"#FFFFFF"}}>Coupon discount</Text>
             <View></View>
             <Text style={{color:"#FFFFFF",marginRight:5}}>₹{data.coupon_discount}</Text>
              </View>
               <Text  style={{color:"#0CFEBC" ,marginLeft:10}}>--------------------------------------</Text>
               <View style={{flexDirection:'row',justifyContent:'space-between',marginRight:20,marginLeft:20,marginTop:10}}>
             
             <Text style={{color:"#0CFEBC",fontSize:22}}>Payable Amount</Text>
             <View></View>
             <Text style={{color:"#FFFFFF",marginRight:5,fontSize:22}}>₹{data.order.order_amount}</Text>
              </View>
        </View>


        <TouchableOpacity
         onPress={()=>handleSubmit()}
            style={{width:Dimensions.get('screen').width-32,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#0CFEBC',
            borderRadius:25,
            marginTop:20,
          
            marginBottom:20,
            marginLeft:16
           
         }}
            
          >
            <Text  style={{fontSize:16,color:'#FFFFFF' }}>Subscribe

            {/* <AntDesign name="doubleright" size={20} marginLeft={3} color="black" /> */}
            </Text>
          </TouchableOpacity>
          



  </SafeAreaView>
  )
}
const styles = StyleSheet.create({

    section:{
   
    
    
    }
    
    
    })