import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";

import LinearGradient from "react-native-linear-gradient";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import { simpleGetCallWithErrorResponse } from "../../../api/ApiServices";
import { COLORS } from "../colors";
import bg from "../../../assets/afteryoubg.png";
import RBSheet from 'react-native-raw-bottom-sheet';
export default function CommunicationTwo({
  color,
  text,
  path,
  navigation,
  route,
}) 
{
  const RBSheetRef=useRef()
  return (
    <LinearGradient
      colors={["#2D3845", "#05A081", "#2D3845"]}
      style={{ height: "100%" }}
    >
      <RBSheet
       ref={RBSheetRef}
       closeOnDragDown={false}
       closeOnPressMask={true}
       closeOnPressBack={true}
       
       height={650}
       customStyles={{
         wrapper: {
           backgroundColor: "#0909098f"
         },
         draggableIcon: {
           backgroundColor: "#ffe"
         },
         container: {
           borderTopLeftRadius: 20,
           borderTopRightRadius: 20,
           backgroundColor: "#2D3845",
           display: 'flex',
           flexDirection: 'column',
         }
       }}
        >
          <ScrollView style={{padding:20,paddingBottom:50}}>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Asset Discovey</Text></>
              <><Text style={styles.planInfoText2}>Ai powered discovery of all your assests</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Asset Addition</Text></>
              <><Text style={styles.planInfoText2}>Manual Asset Addition</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Asset Updates</Text></>
              <><Text style={styles.planInfoText2}>Ai powered automatic updates of all your assest records</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Central Nomination</Text></>
              <><Text style={styles.planInfoText2}>Nominee management across all investments, savings and assets from one single platform</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Nominee Addition / Updates - 10</Text></>
              <><Text style={styles.planInfoText2}>Ai powered discovery of all your assests</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Succession Managers - 5</Text></>
              <><Text style={styles.planInfoText2}>Sharing & Communication of your assets with your CA, Lawyers, Wealth-Managers, etc.</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Express Will - 1</Text></>
              <><Text style={styles.planInfoText2}>1 click E-sign will creation & Auto-will creation</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Record Communication</Text></>
              <><Text style={styles.planInfoText2}>Events of communication of wills and financial records</Text></>
            </View>
            
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Linked Account</Text></>
              <><Text style={styles.planInfoText2}>Real time communication of assets</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Financial and legal Advisory</Text></>
              <><Text style={styles.planInfoText2}>Free of cost minimal document creation</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Human Interference Free</Text></>
              <><Text style={styles.planInfoText2}>No Human dependency required for Will & financial records communication with your nominees</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Life Status Tracker Ai</Text></>
              <><Text style={styles.planInfoText2}>Track persons Life Status with Ai</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Data Storage</Text></>
              <><Text style={styles.planInfoText2}>Free unlimited data for financial records and wills</Text></>
            </View>
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>After you Automated Wealth Transmission</Text></>
              <><Text style={styles.planInfoText2}>Updates Asset Records & Transmits Human Interference Free Financial Records & WIlls transfer to registered nominees</Text></>
            </View>
           
            <View style={{margin:5}}>
              <><Text style={styles.planInfoText1}>Platform Access</Text></>
              <><Text style={styles.planInfoText2}>Valid For Lifetime</Text></>
            </View>
           
            <View style={{margin:5,paddingBottom:10}}>
              <><Text style={styles.planInfoText1}>Tokenized + Encrypted Digital Records</Text></>
              <><Text style={styles.planInfoText2}>State of Art tokenization + encryption for financial records</Text></>
            </View>          

          </ScrollView>
        </RBSheet>

      <Image style={{ height: "100%", width: "100%" }} source={bg}></Image>
      <SafeAreaView>
        <View style={{ marginTop: 30 }}></View>
      </SafeAreaView>
      <TouchableOpacity
        onPress={() => RBSheetRef.current.open()}
        style={{
          width: 247,
          height: 35,
          alignItems: "center",
          justifyContent: "center",
          borderWidth:2,
          borderRadius: 25,
          borderColor:COLORS.light_green,
          marginTop: 10,
          marginBottom: 19,
          position: "absolute",
          bottom: 83,
          backgroundColor:'#1F1D2B',
          left: 69,
        }}
      ><Text style={{color:'#FFFFFF'}}>Know More</Text>
        
      </TouchableOpacity>

      <TouchableOpacity
        onPress={() => navigation.navigate("CommunicationThree")}
        style={{
          width: Dimensions.get("window").width - 32,
          height: 50,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#1F1D2B",
          borderRadius: 25,
          marginTop: 10,
          marginBottom: 20,
          position: "absolute",
          bottom: 0,
          marginLeft: 16,
        }}
      >
        <Text style={{ fontSize: 20, color: "#FFFFFF", fontWeight: "bold" }}>
          Get Started
        </Text>
      </TouchableOpacity>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  toggleParent: {
    flexDirection: "row",
    backgroundColor: "black",
    justifyContent: "center",
    alignSelf: "center",
    borderRadius: 25,
    marginTop: 10,
    height: 37,
    borderColor: "#0CFEBC",
    borderWidth: 1,
  },
  header: {
    flex: 1,
  },
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
  planInfoText1:{color:COLORS.light_green_new,fontWeight:'bold',marginBottom:4},
  planInfoText2:{color:COLORS.white,marginBottom:10}
});
