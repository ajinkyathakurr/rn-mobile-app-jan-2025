import React, { useRef } from 'react'
import { View, Text, Image, TouchableOpacity, ScrollView } from 'react-native'
import back from './../../../assets/back1.png'
import limited_time from './../../../assets/limited_time.png'
import free_banner from './../../../assets/free_banner.png'
import AntDesign from 'react-native-vector-icons/AntDesign'
import Entypo from 'react-native-vector-icons/Entypo'
import RBSheet from 'react-native-raw-bottom-sheet'
import { COLORS } from '../colors'

const infoData = [
    {
        title: "Asset Discovery",
        description: "AI powered discovery of all financial and non-financial assets .",
        free: false,
        pro: true,
        platinum: true
    },
    {
        title: "Asset Addition - 5",
        description: "Manual asset addition.",
        free: true,
        pro: true,
        platinum: true
    },
    {
        title: "Asset Updates",
        description: "AI powered automatic updates of all financial and non-financial assets.",
        free: false,
        pro: true,
        platinum: true
    },
    {
        title: "Central Nomination",
        description: "Nominee management across all investments, savings and assets from one single platform.",
        free: false,
        pro: true,
        platinum: true
    },
    {
        title: "Nominee Addition/Updates - 3",
        description: "Nominee and nominee contact details updates through your phone.",
        free: true,
        pro: true,
        platinum: true
    }
]


const FrequencyListingScreen = ({ navigation, route }) => {
    const freeSheetRef = useRef();
    const proSheetRef = useRef();
    const platinumSheetRef = useRef();

    return (
        <View style={{
            flex: 1,
            backgroundColor: '#252836',
            padding: 20

        }}>
            <RBSheet
                ref={freeSheetRef}
                closeOnDragDown={true}
                closeOnPressMask={true}
                closeOnPressBack={true}
                height={650}
                customStyles={{
                    wrapper: {
                        backgroundColor: "#0909098f"
                    },
                    draggableIcon: {
                        backgroundColor: "#ffe"
                    },
                    container: {
                        borderTopLeftRadius: 20,
                        borderTopRightRadius: 20,
                        backgroundColor: "#2D3845",
                        display: 'flex',
                        flexDirection: 'column',
                    }
                }}
            >
                <ScrollView >
                    {
                        infoData.map((item, index) => {
                            return (
                                <View style={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                }}>
                                    <View style={{
                                        display: 'flex',
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                    }}>
                                        <Text style={{
                                            color: COLORS.light_green,
                                            fontSize: 20,
                                            fontWeight: 'bold',
                                            marginLeft: 20,
                                        }}>{item.title}</Text>
                                        <View style={{
                                            marginLeft: 20,
                                            display: 'flex',
                                            flexDirection: 'row',
                                            alignItems: 'center',
                                            justifyContent: "center"
                                        }}>
                                            {
                                                !item.free ? <Entypo name="cross" size={30} color="red" /> : <Entypo name="check" size={30} color="red" />
                                            }
                                        </View>

                                    </View>
                                    <Text style={{
                                        color: 'white',
                                        fontSize: 15,
                                        marginLeft: 20,
                                        marginRight: 20,
                                        marginBottom: 20
                                    }}>{item.description}</Text>
                                </View>
                            )
                        })
                    }
                </ScrollView>
            </RBSheet>

            <RBSheet
                ref={proSheetRef}
                closeOnDragDown={true}
                closeOnPressMask={true}
                closeOnPressBack={true}
                height={650}
                customStyles={{
                    wrapper: {
                        backgroundColor: "#0909098f"
                    },
                    draggableIcon: {
                        backgroundColor: "#ffe"
                    },
                    container: {
                        borderTopLeftRadius: 20,
                        borderTopRightRadius: 20,
                        backgroundColor: "#2D3845",
                        display: 'flex',
                        flexDirection: 'column',
                    }
                }}
            >
                <ScrollView >
                    {
                        infoData.map((item, index) => {
                            return (
                                <View style={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                }}>
                                    <View style={{
                                        display: 'flex',
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                    }}>
                                        <Text style={{
                                            color: COLORS.light_green,
                                            fontSize: 20,
                                            fontWeight: 'bold',
                                            marginLeft: 20,
                                        }}>{item.title}</Text>
                                        <View style={{
                                            marginLeft: 20,
                                            display: 'flex',
                                            flexDirection: 'row',
                                            alignItems: 'center',
                                            justifyContent: "center"
                                        }}>
                                            {
                                                !item.pro ? <Entypo name="cross" size={30} color="red" /> : <Entypo name="check" size={30} color="red" />
                                            }
                                        </View>

                                    </View>
                                    <Text style={{
                                        color: 'white',
                                        fontSize: 15,
                                        marginLeft: 20,
                                        marginRight: 20,
                                        marginBottom: 20
                                    }}>{item.description}</Text>
                                </View>
                            )
                        })
                    }
                </ScrollView>
            </RBSheet>

            <RBSheet
                ref={platinumSheetRef}
                closeOnDragDown={true}
                closeOnPressMask={true}
                closeOnPressBack={true}
                height={650}
                customStyles={{
                    wrapper: {
                        backgroundColor: "#0909098f"
                    },
                    draggableIcon: {
                        backgroundColor: "#ffe"
                    },
                    container: {
                        borderTopLeftRadius: 20,
                        borderTopRightRadius: 20,
                        backgroundColor: "#2D3845",
                        display: 'flex',
                        flexDirection: 'column',
                    }
                }}
            >
                <ScrollView >
                    {
                        infoData.map((item, index) => {
                            return (
                                <View style={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                }}>
                                    <View style={{
                                        display: 'flex',
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                    }}>
                                        <Text style={{
                                            color: COLORS.light_green,
                                            fontSize: 20,
                                            fontWeight: 'bold',
                                            marginLeft: 20,
                                        }}>{item.title}</Text>
                                        <View style={{
                                            marginLeft: 20,
                                            display: 'flex',
                                            flexDirection: 'row',
                                            alignItems: 'center',
                                            justifyContent: "center"
                                        }}>
                                            {
                                                !item.platinum ? <Entypo name="cross" size={30} color="red" /> : <Entypo name="check" size={30} color="red" />
                                            }
                                        </View>

                                    </View>
                                    <Text style={{
                                        color: 'white',
                                        fontSize: 15,
                                        marginLeft: 20,
                                        marginRight: 20,
                                        marginBottom: 20
                                    }}>{item.description}</Text>
                                </View>
                            )
                        })
                    }
                </ScrollView>
            </RBSheet>


            <View style={{
                display: 'flex',
                flexDirection: 'row',
                alignItems: 'center',
            }}>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    borderColor: 'white',
                    borderWidth: 1,
                    borderRadius: 25,
                    padding: 10
                }}>
                    <Image source={back} style={{
                        height: 20,
                        width: 20,
                    }} />
                </View>

                <Text style={{
                    color: 'white',
                    fontSize: 25,
                    marginLeft: 80,
                    fontWeight: 'bold'
                }}>Frequency</Text>

            </View>
            <View style={{
                display: 'flex',
                flexDirection: 'column',
                alignContent: 'center',
                marginTop: 20
            }}>
                <View style={{
                    width: "100%",
                    borderRadius: 15,
                    display: 'flex',
                    flexDirection: 'column',
                    backgroundColor: "#053AA0"
                }}

                >
                    <View style={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'flex-end',
                    }}>
                        <Image source={free_banner} style={{
                            height: 100,
                            width: 100,
                        }} />
                    </View>
                    <Text style={{
                        color: 'white',
                        marginLeft: 20,
                        fontSize: 35,
                        fontWeight: 'bold'
                    }}>Free</Text>
                    <View style={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                    }}>

                        <Text style={{
                            color: 'white',
                            fontSize: 20,
                            marginLeft: 20,
                            marginBottom: 20
                        }}>Active</Text>
                        <TouchableOpacity onPress={() => freeSheetRef.current.open()}>
                            <AntDesign name="infocirlceo" size={20} color="white" style={{
                                marginRight: 20,
                            }} />
                        </TouchableOpacity>
                    </View>
                </View>
                <TouchableOpacity style={{
                    marginTop: 20,
                    backgroundColor: "#FFA900",
                    width: "100%",
                    borderRadius: 15,
                    display: 'flex',
                    padding: 20,
                    flexDirection: 'column',
                    alignItems: 'flex-end',
                }}
                    onPress={() => navigation.navigate('PaymentDetailsScreen', {
                        plan: "Pro",
                        price: 3650.0,
                        promotion: 1825.0,
                        total: 1825.0,
                        gst:330.0
                    })}
                >
                    <View style={{
                        display: 'flex',
                        width: "100%",
                        flexDirection: 'row',
                        justifyContent: 'space-evenly',
                        alignItems: 'center',
                    }}>
                        <Image source={limited_time} style={{
                            height: 100,
                            width: 100,
                        }} />

                        <Text style={{
                            color: 'white',
                            fontSize: 25,
                            width: '40%',
                            fontWeight: 'bold',
                            color: "#F73B71"
                        }}>@Just Rs10/Day</Text>

                    </View>
                    <View style={{
                        display: 'flex',
                        flexDirection: 'column',
                        width: "100%",
                    }}>
                        <View style={{
                            display: 'flex',
                            flexDirection: 'column',
                        }}>
                            <Text style={{
                                color: 'black',
                                fontSize: 35,
                                fontWeight: 'bold'
                            }}>Pro</Text>
                            <Text style={{
                                color: 'black',
                                fontSize: 18,
                                textDecorationLine: 'line-through',
                                fontWeight: 'bold'
                            }}>@ Rs.3560 / Year</Text>
                            <View style={{
                                display: 'flex',
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}>

                                <Text style={{
                                    color: 'black',
                                    fontSize: 18,
                                    fontWeight: 'bold',
                                }}>Rs 1825/year</Text>
                                <TouchableOpacity onPress={() => proSheetRef.current.open()}>
                                    <AntDesign name="infocirlceo" size={20} color="black" />
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity style={{
                    marginTop: 20,
                    backgroundColor: "#99A1AB",
                    width: "100%",
                    borderRadius: 15,
                    display: 'flex',
                    padding: 20,
                    flexDirection: 'column',
                    alignItems: 'flex-end',
                }}
                    onPress={() => navigation.navigate('PaymentDetailsScreen', {
                        plan: "Platinum",
                        price: 19999.0,
                        promotion: 10000,
                        total: 9999,
                        gst:1800.0
                    })}
                >
                    <View style={{
                        display: 'flex',
                        width: "100%",
                        flexDirection: 'row',
                        justifyContent: 'space-evenly',
                        alignItems: 'center',
                    }}>
                        <Image source={limited_time} style={{
                            height: 100,
                            width: 100,
                        }} />

                        <Text style={{
                            color: 'white',
                            fontSize: 25,
                            width: '40%',
                            fontWeight: 'bold',
                            color: "#F73B71"
                        }}>@Just Rs 1/Day</Text>

                    </View>
                    <View style={{
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'space-between',
                        width: "100%",
                    }}>
                        <View style={{
                            display: 'flex',
                            flexDirection: 'column',
                        }}>
                            <Text style={{
                                color: 'black',
                                fontSize: 35,
                                fontWeight: 'bold'
                            }}>Platinum</Text>
                            <Text style={{
                                color: 'black',
                                fontSize: 18,
                                textDecorationLine: 'line-through',
                                fontWeight: 'bold'
                            }}

                            >@ Rs.19999 / Lifetime</Text>
                            <View style={{
                                display: 'flex',
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}>

                                <Text style={{
                                    color: 'black',
                                    fontSize: 18,
                                    fontWeight: 'bold',
                                }}>Rs 9999/year</Text>
                                <TouchableOpacity onPress={() => platinumSheetRef.current.open()}>
                                    <AntDesign name="infocirlceo" size={20} color="black" />
                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>
                </TouchableOpacity>
            </View>
        </View>
    )
}

export default FrequencyListingScreen