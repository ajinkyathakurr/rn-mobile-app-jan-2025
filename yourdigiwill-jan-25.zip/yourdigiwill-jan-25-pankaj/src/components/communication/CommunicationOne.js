import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";

import LinearGradient from "react-native-linear-gradient";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import { simpleGetCallWithErrorResponse } from "../../../api/ApiServices";
import { COLORS } from "../colors";
import AntDesign from "react-native-vector-icons/AntDesign";
import { showMessage } from "react-native-flash-message";
export default function CommunicationOne({
  color,
  text,
  path,
  navigation,
  route,
}) {
  const [active, setActive] = useState(false);
  const [height,setHeight]=useState(80)
  const [loading, setLoading] = useState(true);
 
  const [sharedwithme, setSharedwithmeNominees] = useState([]);

  const [message, setMessage] = useState("");
  const [fromsubscription, setfromsubscription] = useState(false);
  const [frequenciesdata,seTfrequenciesdata]=useState([])
  const { token } = useContext(AppContext);
  

  const handleFrequency=(frqType,isActive)=>{
    if(!isActive)
    navigation.navigate("ChooseFrequency",{frequency:frqType})
    else{
      showMessage({message:"Update feature coming soon",type:"info"})
    }
  }

  const getSubscriptionStatus = () => {
    setLoading(true);
    simpleGetCallWithErrorResponse(ApiConfig.AFTERYOU_PLAN_CHECK, {
      token: token,
    })
      .then((data) => {
       

        if (data.json.subscribed || data.json.from_subscription) {
          setActive(true);
          setMessage(data.json.message);
          const {frequency}=data.json
          
          let newFrequencies = [...frequenciesdata];

if (frequency.monthly) newFrequencies.push("monthly");
if (frequency.quarterly) newFrequencies.push("quarterly");
if (frequency.halfyearly) newFrequencies.push("halfyearly");
if (frequency.yearly) newFrequencies.push("yearly");

seTfrequenciesdata(newFrequencies);
          setfromsubscription(data.json.from_subscription);
        }
        setLoading(false);
      })

      .catch((error) => {
        console.log("api response", error);
      });
    simpleGetCallWithErrorResponse(ApiConfig.GET_SHARED_WITH_ME, {
      token: token,
    })
      .then((data) => {
        if (data) {
          console.log(data);
          setSharedwithmeNominees(data.json.data);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  useEffect(() => {
    getSubscriptionStatus();
   
  }, [navigation.isFocused()]);
  
  return (
    <LinearGradient
      colors={["#2D3845", "#05A081", "#2D3845"]}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={{ flex: 1 }}>
        <View>
          <View
            style={{
              height: 50,
              alignItems: "center",
              justifyContent: "center",
              justifyContent: "space-between",
              flexDirection: "row",
            }}
          >
            <TouchableOpacity onPress={() => navigation.navigate("Home")}>
              <AntDesign
                name="left"
                size={30}
                color="#FFFFFF"
                style={{ marginRight: 3 }}
              ></AntDesign>
            </TouchableOpacity>
            <Text style={{ fontSize: 22, color: "#FFFFFF" }}>
              Communication
            </Text>
            <View></View>
          </View>
        </View>
        {loading ? (
          <Spinner color={COLORS.light_green} visible={loading} />
        ) : (
          <></>
        )}

        <View>
          <TouchableOpacity
            onPress={() => {
              // active
              //   ? navigation.navigate("CommunicationNominee")
              //   : navigation.navigate("CommunicationTwo");
              showMessage({
                message: "This feature is currently unavailable but will be coming soon! Stay tuned!",
                type: "info",
                position:"center"
              });
            }}
            style={{
              height: 80,
              width: Dimensions.get("window").width - 32,
              backgroundColor: COLORS.dark_grey,
              marginLeft: 16,
              marginRight: 16,
              marginTop: 20,
              alignItems: "center",
              flexDirection: "row",
              borderRadius: 10,
            }}
          >
            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Badges_Icon_Boder_radius_28-5.png",
              }}
              style={{ height: 50, width: 50, marginLeft: 10 }}
            ></Image>

            <Text
              style={{
                color: "#FFFFFF",
                fontSize: 22,
                fontWeight: "bold",
                marginLeft: 20,
              }}
            >
              After You
            </Text>

            {active ? (
              <Text
                style={{
                  color: COLORS.light_green_new,
                  marginLeft: 20,
                  maxWidth: 150,
                }}
              >
                {message}
              </Text>
            ) : (
              <></>
            )}
          </TouchableOpacity>

          <View
            style={{
              height: height,
              overflow:"hidden",
              width: Dimensions.get("window").width - 32,
              backgroundColor: COLORS.dark_grey,
              marginLeft: 16,
              marginRight: 16,
              marginTop: 20,
              padding: 10,
              flexDirection: "column",
              borderRadius: 10,

            }}
          >
            <TouchableOpacity
              style={{
                width: "auto",
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 20,
              }}
              onPress={() => {
                if(!message)
                navigation.navigate("EnsuranceNewOne");
                else{
                  if(height==80)
                  setHeight(250)
                else setHeight(80)
                }
                
              }}
            >
              <Image
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Badges_Icon_Boder_radius_28.png",
                }}
                style={{ height: 50, width: 50, marginLeft: 10 }}
              ></Image>

              <Text
                style={{
                  color: "#FFFFFF",
                  fontSize: 22,
                  fontWeight: "bold",
                  marginLeft: 20,
                }}
              >
                Frequency
              </Text>
              {active?
              <Text style={{color:COLORS.light_green,marginLeft:20}}>Active</Text>:<></>}
              
            </TouchableOpacity>
            <View>
              <TouchableOpacity
                style={{
                  flexDirection: "row",
                  width: "100%",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom:17,
                  paddingHorizontal:10,
                }}
                onPress={()=>handleFrequency("monthly",(frequenciesdata.indexOf("monthly")>-1))}
              >
                <View style={{flexDirection:"row",width:"80%",justifyContent:"space-between"}}>
                <Text style={{ color: COLORS.white,}}>Monthly</Text>
                <Text style={{ color: !(frequenciesdata.indexOf("monthly")>-1)  ? COLORS.light_green : COLORS.light_yello }}>
                  {!(frequenciesdata.indexOf("monthly")>-1) ? "less effective" : "Activated"}
                </Text>
                <View></View>
                </View>
                <AntDesign name="right" size={25} color={COLORS.white} />
              </TouchableOpacity>
            </View>
            <View>
              <TouchableOpacity
             onPress={()=>handleFrequency("quarterly",(frequenciesdata.indexOf("quarterly")>-1))}
                style={{
                  flexDirection: "row",
                  width: "100%",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom:17,
                  paddingHorizontal:10,
                }}
                
              >
                <View style={{flexDirection:"row",width:"80%",justifyContent:"space-between"}}>
                <Text style={{ color: COLORS.white,}}>Quarterly</Text>
                <Text style={{ color:!(frequenciesdata.indexOf("quarterly")>-1)  ? COLORS.light_green : COLORS.light_yello }}>
                  {!(frequenciesdata.indexOf("quarterly")>-1 ) ? "effective" : "Activated"}
                </Text>
                <View></View>
                </View>
                <AntDesign name="right" size={25} color={COLORS.white} />
              </TouchableOpacity>
            </View>
            <View>
              <TouchableOpacity
             onPress={()=>handleFrequency("halfyearly",(frequenciesdata.indexOf("halfyearly")>-1))}
                style={{
                  flexDirection: "row",
                  width: "100%",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom:17,
                  paddingHorizontal:10,
                }}
              >
                <View style={{flexDirection:"row",width:"80%",justifyContent:"space-between"}}>
                <Text style={{ color: COLORS.white,}}>HalfYearly</Text>
                <Text style={{ color: !(frequenciesdata.indexOf("halfyearly")>-1)  ? COLORS.light_green : COLORS.light_yello }}>
                  {!(frequenciesdata.indexOf("halfyearly")>-1)  ? "moderate effective" : "Activated"}
                </Text>
                <View></View>
                </View>
                <AntDesign name="right" size={25} color={COLORS.white} />
              </TouchableOpacity>
            </View>
            <View>
              <TouchableOpacity
             onPress={()=>handleFrequency("yearly",(frequenciesdata.indexOf("yearly")>-1))}
                style={{
                  flexDirection: "row",
                  width: "100%",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom:17,
                  paddingHorizontal:10,
                }}
              >
                <View style={{flexDirection:"row",width:"86%",justifyContent:"space-between"}}>
                <Text style={{ color: COLORS.white,}}>Yearly</Text>
                <Text style={{ color: !(frequenciesdata.indexOf("yearly")>-1)  ? COLORS.light_green : COLORS.light_yello }}>
                  {!(frequenciesdata.indexOf("yearly")>-1)  ? "risky" : "Activated"}
                </Text>
                <View></View>
                </View>
                <AntDesign name="right" size={25} color={COLORS.white} />
              </TouchableOpacity>
            </View>
           
           
           
          </View>
          {/* <View
            style={{
              height: 80,
              width: Dimensions.get("window").width - 32,
              backgroundColor: COLORS.dark_grey,
              marginLeft: 16,
              marginRight: 16,
              marginTop: 20,
              alignItems: "center",
              flexDirection: "row",
              borderRadius: 10,
            }}
          >
            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Badges_Icon_Boder_radius_28-1.png",
              }}
              style={{ height: 50, width: 50, marginLeft: 10 }}
            ></Image>

            <Text
              style={{
                color: "#FFFFFF",
                marginLeft: 20,
                fontSize: 22,
                fontWeight: "bold",
              }}
            >
              Event
            </Text>
            <Text style={{ color: "#05A081", marginLeft: 10 }}>
              Coming soon
            </Text>
          </View> */}
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  toggleParent: {
    flexDirection: "row",
    backgroundColor: "black",
    justifyContent: "center",
    alignSelf: "center",
    borderRadius: 25,
    marginTop: 10,
    height: 37,
    borderColor: "#0CFEBC",
    borderWidth: 1,
  },
  header: {
    flex: 1,
  },
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
