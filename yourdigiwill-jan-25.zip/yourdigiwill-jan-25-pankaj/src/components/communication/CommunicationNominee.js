import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Feather from "react-native-vector-icons/Feather";
import { useState, useRef, useEffect, useContext } from "react";
import DatePicker from "react-native-date-picker";
import LinearGradient from "react-native-linear-gradient";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import {
  getWithAuthCall,
  postWithAuthCall,
  simpleGetCallWithErrorResponse,
} from "../../../api/ApiServices";
import { COLORS } from "../colors";
import CheckBox from "react-native-check-box";
import AntDesign from "react-native-vector-icons/AntDesign";
import { showMessage } from "react-native-flash-message";
export default function CommunicationNominee({ navigation, route }) {
  const [Nominees,seTNominees]=useState([])
  const [loading,seTloading]=useState(false)
  const getNomineeData=()=>{
    seTloading(true)
    getWithAuthCall(ApiConfig.ADD_NOMINEE_AFTERYOU).then((res)=>{

      if(res.status){
        seTNominees(res.data);
        seTloading(false)
      }
    })
    .catch(()=>{
      seTloading(false)
      showMessage({message:"Error occured while getting your data",type:"danger"})
    })
  }
  useEffect(() => {
    getNomineeData()
  }, []);

  return (
    <LinearGradient
      colors={["#2D3845", "#05A081", "#2D3845"]}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={{ flex: 1 }}>
        <View>
          <View
            style={{
              height: 50,
              alignItems: "center",
              justifyContent: "center",
              justifyContent: "space-between",
              flexDirection: "row",
            }}
          >
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <AntDesign
                name="left"
                size={30}
                color="#FFFFFF"
                style={{ marginRight: 3 }}
              ></AntDesign>
            </TouchableOpacity>
            <Text style={{ fontSize: 22, color: "#FFFFFF" }}>After You .</Text>
            <View></View>
          </View>
        </View>
<View style={styles.badge}>
  <Text style={{color:COLORS.light_green,textAlign:"center"}} >Activated under Subscriptions</Text>
  </View>
        <View>
          <View>
            <Text
              style={{
                color: COLORS.white,
                fontSize: 20,
                fontWeight: "bold",
                margin: 20,
              }}
            >
              My Nominees
            </Text>
          </View>

          <ScrollView style={{ height: 250 }}>
            {loading ?<Spinner visible={loading} color={COLORS.light_green} size={30}/>:
              Nominees.map((nominee,id)=>{
                return(<View
                id={nominee.id}
              style={{
                width: Dimensions.get("screen").width - 32,
                backgroundColor: "#1F1D2B",
                height: 70,
                marginLeft: 16,
                marginRight: 16,
                marginTop: 10,
                borderRadius: 10,
                alignItems: "center",
                justifyContent: "space-between",
                flex: 1,
                flexDirection: "row",
              }}
            >
              <View
                style={{
                  width: 40,
                  height: 40,
                  borderColor: COLORS.light_green,
                  borderWidth: 1,
                  borderRadius: 50,
                  alignItems: "center",
                  marginLeft: 10,
                }}
              >
                <Text
                  style={{
                    fontSize: 22,
                    color: "#FFFFFF",
                    marginTop: 5,
                  }}
                >
                  {nominee.name[0]}
                </Text>
              </View>
              <Text
                style={{
                  fontSize: 17,
                  color: "#FFFFFF",
                  marginRight:40
                }}
              >
                {nominee.name}
              </Text>
              <View></View>
            </View>)
              })
            }
            
          </ScrollView>
        </View>
        <TouchableOpacity onPress={()=>{navigation.navigate("CommunicationAddNominee")}} style={{backgroundColor:COLORS.light_yello,width:50,height:50,borderRadius:50,justifyContent:"center",alignItems:"center",position:"absolute",bottom:50,right:50}}><Text style={{fontSize:35,marginTop:-5,fontWeight:"bold"}}>+</Text></TouchableOpacity>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  DatePicker: {
    width: "80%",
    flexDirection: "row",
    justifyContent: "space-between",
    height: 50,
    backgroundColor: COLORS.light_green,
    alignItems: "center",
    paddingHorizontal: 15,
    borderRadius: 50,
  },
  DateSection: {
    width: "90%",
    marginLeft: "5%",
    alignItems: "center",
    height: 200,
    justifyContent: "space-around",
    borderColor: COLORS.black,
    borderWidth: 0.5,
    borderRadius: 10,
  },
  checkbox: {
    marginRight: 15,

    borderColor: "#0CFEBC",
  },
  SubmitButton: {
    width: 80,
    height: 40,
    backgroundColor: COLORS.light_yello,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 30,
  },
  badge:{
   height:30,
   width:250,
   backgroundColor:COLORS.dark_grey,
   color:COLORS.light_green,
   borderRadius:50,
   
   marginHorizontal:10,
   paddingVertical:5
  }
});
