import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Feather from "react-native-vector-icons/Feather";
import { useState, useRef, useEffect, useContext } from "react";
import DatePicker from "react-native-date-picker";
import LinearGradient from "react-native-linear-gradient";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import { getWithAuthCall, postWithAuthCall, simpleGetCallWithErrorResponse } from "../../../api/ApiServices";
import { COLORS } from "../colors";
import CheckBox from "react-native-check-box";
import AntDesign from "react-native-vector-icons/AntDesign";
import { showMessage } from "react-native-flash-message";
export default function ChooseFrequency({ navigation, route }) {
  const [date, setDate] = useState(new Date());
  const [open, setOpen] = useState(false);
  const [nominees,setNominees]=useState([])
  const [SelectedNominees,setSelectedNominees]=useState([])
  
  const [loading,seTloading]=useState(false)

  const {frequency}=route.params
  const getNomineeData=()=>{
    seTloading(true)
    getWithAuthCall(ApiConfig.GET_NOMINEE_COMMUNICATION).then((res)=>{
        setNominees(res.data)
        seTloading(false)
    }).catch(()=>{
        seTloading(false)
    })
    
  }
  useEffect(()=>{
    getNomineeData()
  },[])

  const handleSubmit=()=>{
    const dateStr=date.getFullYear().toString()+"-"+(date.getMonth()+1).toString()+"-"+date.getDate().toString()
     if(SelectedNominees.length<0){
        showMessage({message:"Add atleast one nominee",type:"danger"});
        return;
     }
     postWithAuthCall(ApiConfig.ADD_NOMINEE_FREQUENCY,{"nominee_array":SelectedNominees,"frequency_type":frequency,"frequency_date":dateStr}).then((res)=>{
        console.log(res)
        if(res.status){
        showMessage({message:res.message+"to"+res.frequency_type,type:"success"})
        navigation.goBack();
       }
       else{
        showMessage({message:"error occured",type:"danger"})
        navigation.goBack();
       }
   }).catch((err)=>{
    console.log(err)
   // navigation.goBack();
   })
  }

  return (
    <LinearGradient
      colors={["#2D3845", "#05A081", "#2D3845"]}
      style={{ flex: 1 }}
    >
      <SafeAreaView style={{ flex: 1 }}>
        <View>
          <View
            style={{
              height: 50,
              alignItems: "center",
              justifyContent: "center",
              justifyContent: "space-between",
              flexDirection: "row",
            }}
          >
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <AntDesign
                name="left"
                size={30}
                color="#FFFFFF"
                style={{ marginRight: 3 }}
              ></AntDesign>
            </TouchableOpacity>
            <Text style={{ fontSize: 22, color: "#FFFFFF" }}>
              Communications
            </Text>
            <View></View>
          </View>
        </View>
        <View style={styles.DateSection}>
          <Text
            style={{
              color: COLORS.light_green,
              fontSize: 20,
              fontWeight: "bold",
            }}
          >
            Select Date and Nominee
          </Text>
          
          <TouchableOpacity
            style={styles.DatePicker}
            onPress={() => setOpen(true)}
          >
            <Feather name="calendar" size={30} color={COLORS.black} />
            <Text>{date.getFullYear().toString()+"-"+(date.getMonth()+1).toString()+"-"+date.getDate().toString()}</Text>
            <DatePicker
            modal
            open={open}
            date={date}
            onConfirm={(date) => {
              setOpen(false);
              setDate(date);
            }}
            onCancel={() => {
              setOpen(false);
            }}
          />
            <Feather name="chevron-down" size={30} color={COLORS.black} />
          </TouchableOpacity>
          <View></View>
        </View>
        <View>
          <View>
            <Text style={{color:COLORS.white,fontSize:20,fontWeight:"bold",margin:20}}>My Nominees</Text>
          </View>{
            loading?<Spinner color={COLORS.grey} visible={loading} />:
          
          <ScrollView style={{height:250}}>
            {
                nominees.map((Nominee,id)=>{
                    return(
                    <View
                    id={Nominee.id}
                        style={{
                          width: Dimensions.get("screen").width - 32,
                          backgroundColor: "#1F1D2B",
                          height: 70,
                          marginLeft: 16,
                          marginRight: 16,
                          marginTop: 10,
                          borderRadius: 10,
                          alignItems: "center",
                          justifyContent: "space-between",
                          flex: 1,
                          flexDirection: "row",
                        }}
                      >
                        <View
                          style={{
                            width: 40,
                            height: 40,
                            borderColor: COLORS.light_green,
                            borderWidth: 1,
                            borderRadius: 50,
                            alignItems: "center",
                            marginLeft: 10,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 22,
                              color: "#FFFFFF",
                              marginTop: 5,
                            }}
                          >
                            {Nominee.name[0]}
                          </Text>
                        </View>
                        <Text
                          style={{
                            fontSize: 17,
                            color: "#FFFFFF",
                          }}
                        >
                          {Nominee.name}
                        </Text>
                        <View>
                          <CheckBox
                            style={styles.checkbox}
                            isChecked={
                                SelectedNominees.indexOf(Nominee.id)>-1?true:false
                            }
                            onClick={() => {
                                SelectedNominees.indexOf(Nominee.id)>-1?
                                setSelectedNominees(SelectedNominees.filter(
                                    (value) => value != Nominee.id
                                  )):
                                setSelectedNominees([...SelectedNominees,Nominee.id])
                            }} // color={true ? '#0CFEBC' : undefined}
                            checkBoxColor="#0CFEBC"
                          />
                        </View>
                      </View>
                    )
                })
            }
            
           
           
          </ScrollView>}
        </View>
        <View style={{flex:1,justifyContent:"center",alignItems:"center"}}>
        <TouchableOpacity style={styles.SubmitButton} onPress={()=>{handleSubmit()}}>
            <Text>Save</Text>
        </TouchableOpacity>
        </View>
      </SafeAreaView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  DatePicker: {
    width: "80%",
    flexDirection: "row",
    justifyContent: "space-between",
    height: 50,
    backgroundColor: COLORS.light_green,
    alignItems: "center",
    paddingHorizontal: 15,
    borderRadius: 50,
  },
  DateSection: {
    width: "90%",
    marginLeft: "5%",
    alignItems: "center",
    height: 200,
    justifyContent: "space-around",
    borderColor: COLORS.black,
    borderWidth: 0.5,
    borderRadius: 10,
  },
  checkbox: {
    marginRight: 15,

    borderColor: "#0CFEBC",
  },
  SubmitButton:{
    width:80,
    height:40,
    backgroundColor:COLORS.light_yello,
    justifyContent:"center",
    alignItems:"center",
    borderRadius:30

  }
});
