import React from 'react'
import { View, Text, Image, TouchableOpacity, TextInput } from 'react-native'
import back from './../../../assets/back1.png'
import { COLORS } from '../colors'
import AntDesign from 'react-native-vector-icons/AntDesign'
import { SafeAreaView } from 'react-native-safe-area-context'

const PaymentDetailsScreen = ({ navigation, route }) => {

    const {plan,price,promotion,total,gst} = route.params

    return (
        <SafeAreaView style={{
            flex: 1,
            backgroundColor: '#252836',
            padding: 20,
            display: 'flex',
            flexDirection: 'column',

        }}>
            <View style={{
                display: 'flex',
                flexDirection: 'row',
            }}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Image source={back} style={{
                        width: 20,
                        height: 20,
                    }} />
                </TouchableOpacity>

                <Text style={{
                    color: 'white',
                    fontSize: 20,
                    marginLeft: '25%',
                    fontWeight: 'bold'
                }}>Order summary</Text>

            </View>
            <View style={{
                display: 'flex',
                flexDirection: 'column',
                marginTop: 40,
                borderWidth: 1,
                borderColor: 'white',
                borderRadius: 10,

            }}>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    marginTop: 10
                }}>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>{plan}</Text>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>₹ {price}</Text>
                </View>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 10,
                    paddingVertical: 5
                }}>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>Referral bonus</Text>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>₹ 0.0</Text>
                </View>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 10,
                    paddingVertical: 5
                }}>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>Promotion applied</Text>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>₹ {promotion}</Text>
                </View>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 10,
                    paddingVertical: 5
                }}>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>Coupon discount</Text>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>₹ 0.0</Text>
                </View>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 10,
                    paddingVertical: 5
                }}>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>Total</Text>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>₹ {total}</Text>
                </View>

                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                }}>
                    <View style={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        backgroundColor: "#0CFEBC4E",
                        padding: 10,
                        borderColor: COLORS.light_green_new,
                        borderWidth: 2,
                        borderRadius: 10,
                        marginTop: 20,
                        borderStyle: 'dashed',
                        width: '80%',
                    }}>
                        <TextInput placeholder="Enter promo code" style={{
                            color: 'white',
                            fontSize: 20,
                            width: '80%',
                        }}

                            placeholderTextColor={COLORS.light_green}
                        />
                        <TouchableOpacity>
                            <Text style={{
                                color: COLORS.light_green,
                                fontSize: 20,
                            }}>Apply</Text>
                        </TouchableOpacity>
                    </View>
                </View>
                <View style={{
                    width: '85%',
                    marginTop: 20,
                    height: 1,
                    backgroundColor: "#0CFEBC4E",
                    alignSelf: 'center',
                }} />
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 10,
                    paddingVertical: 5
                }}>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>GST</Text>
                    <Text style={{
                        color: 'white',
                        fontSize: 20,
                    }}>₹ {gst}</Text>

                </View>

                <View style={{
                    width: '85%',
                    marginTop: 20,
                    height: 1,
                    backgroundColor: COLORS.light_green,
                    alignSelf: 'center',
                }} />

                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingHorizontal: 10,
                    paddingVertical: 5,
                    marginBottom: 10,
                    marginTop: 10
                }}>
                    <Text style={{
                        color: COLORS.light_green,
                        fontSize: 25,
                    }}>Payable amount</Text>
                    <Text style={{
                        color: COLORS.light_green,
                        fontSize: 25,
                    }}>₹ {total +gst}</Text>

                </View>
            </View>
            <View style={{
                display: 'flex',
                flexDirection: 'column',
                marginTop: 20,
                justifyContent: 'center',
            }}>
                <Text style={{
                    color: 'white',
                    fontSize: 15,
                    textAlign: 'center',
                }}>By placing your order, you agree to DigiWill's</Text>
                <Text style={{
                    color: COLORS.light_green,
                    fontSize: 15,
                    textAlign: 'center',
                }}> Privacy Policy Usage Service and Terms and Conditions</Text>
            </View>
            <View style={{
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: 90,
            }}>
                <Text style={{
                    color: COLORS.light_green,
                    fontSize: 25,
                    fontWeight: 'bold'
                }}>Pay now </Text>
                <TouchableOpacity style={{
                    backgroundColor: COLORS.light_green,
                    padding: 10,
                    marginLeft: 10,
                    borderRadius: 25,
                }}>
                    <AntDesign name='arrowright' size={30} />
                </TouchableOpacity>
            </View>
        </SafeAreaView>
    )
}

export default PaymentDetailsScreen