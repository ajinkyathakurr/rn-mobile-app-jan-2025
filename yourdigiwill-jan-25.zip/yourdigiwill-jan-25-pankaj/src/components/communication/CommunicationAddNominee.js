import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  SafeAreaView,
} from "react-native";
import { useState, useRef, useEffect, useContext } from "react";
import Spinner from "react-native-loading-spinner-overlay";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import AntDesign from "react-native-vector-icons/AntDesign";
import CheckBox from "react-native-check-box";
import LinearGradient from "react-native-linear-gradient";
import { AppContext } from "../../../user/AppContext";
import ApiConfig from "../../../api/ApiConfig";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../../api/ApiServices";
import { showMessage } from "react-native-flash-message";
import { COLORS } from "../colors";

export default function CommunicationAddNominee({ navigation, route }) {
  const [sharedbymenominees, setSharedbymeNominees] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectednominees, setselectedsetNominees] = useState([]);
  const { token } = useContext(AppContext);

  const handleSubmit = () => {
    console.log(selectednominees);
    setLoading(true);
    PostCallWithErrorResponse(ApiConfig.ADD_NOMINEE_AFTERYOU, {
      nominee_array: selectednominees,
      token: token,
    })
      .then((result) => {
        console.log(result);
        setLoading(false);
        if (result.json.status) {
          //  setData({name:"",relationship:"",age:"",email:"",phone:"",address:"",gender:""})
          //  getAllAssets()
          //  bottomsheet.current.close()
          showMessage({
            message: "Nominee added to communication successfully",
            type: "success",
          });
          navigation.navigate("CommunicationDetail");
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const getAllSharedByMeNominees = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_NOMINEE_COMMUNICATION, {
      token: token,
    })
      .then((data) => {
        if (data) {
          console.log(data);
          setSharedbymeNominees(data.json.data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  useEffect(() => {
    getAllSharedByMeNominees();
  }, []);

  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          marginTop: 10,
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <TouchableOpacity
          onPress={() => navigation.navigate("CommunicationDetail")}
        >
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2, marginLeft: 3 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" }}>
          Select Nominees
        </Text>

        <View></View>
      </View>

      {loading ? (
        <Spinner color={COLORS.light_green} visible={loading} />
      ) : (
        <></>
      )}

      <ScrollView style={{ flex: 0.2 }}>
        {sharedbymenominees.length != 0 ? (
          sharedbymenominees.map((single) => {
            return (
              <View
                style={{
                  width: Dimensions.get("screen").width - 32,
                  backgroundColor: "#1F1D2B",
                  height: 70,
                  marginLeft: 16,
                  marginRight: 16,
                  marginTop: 10,
                  borderRadius: 10,
                  alignItems: "center",
                  justifyContent: "space-between",
                  flex: 1,
                  flexDirection: "row",
                }}
              >
                <View
                  style={{
                    width: 40,
                    height: 40,
                    borderColor: COLORS.light_green,
                    borderWidth: 1,
                    borderRadius: 50,
                    alignItems: "center",
                    marginLeft: 10,
                  }}
                >
                  <Text
                    style={{
                      marginTop: 5,
                      fontSize: 22,
                      color: "#FFFFFF",
                    }}
                  >
                    {single.name[0]}
                  </Text>
                </View>
                <Text
                  style={{
                    fontFamily: "Roboto-Regular",
                    fontSize: 17,
                    color: "#FFFFFF",
                  }}
                >
                  {single.name}
                </Text>
                <View>
                  <CheckBox
                    style={styles.checkbox}
                    isChecked={
                      selectednominees.indexOf(single.id) > -1 ? true : false
                    }
                    onClick={() => {
                      selectednominees.indexOf(single.id) > -1
                        ? setselectedsetNominees(
                            selectednominees.filter(
                              (value) => value != single.id
                            )
                          )
                        : setselectedsetNominees([
                            ...selectednominees,
                            single.id,
                          ]);
                      console.log(selectednominees);
                    }}
                    // color={true ? '#0CFEBC' : undefined}
                    checkBoxColor="#0CFEBC"
                  />
                </View>
              </View>
            );
          })
        ) : (
          <View
            style={{
              alignItems: "center",
              justifyContent: "center",
              marginTop: 150,
            }}
          >
            <TouchableOpacity
              onPress={() => navigation.navigate("AddNominee")}
              style={{
                width: 91,
                height: 91,
                borderRadius: 50,
                color: "#FFFFFF",
                marginRight: 21,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 10,
                backgroundColor: "#252836",
              }}
            >
              <Image
                style={styles.rndImage}
                source={require("../../../assets/sharenow.png")}
              />
            </TouchableOpacity>
            <Text
              style={{
                fontSize: 21,
                color: "#FFFFFF",
                marginTop: 5,
                paddingBottom: 10,
              }}
            >
              Add Nominee
            </Text>
          </View>
        )}
      </ScrollView>

      <LinearGradient
        colors={["#FFBF35", "#FFA900"]}
        style={{
          width: 65,
          borderRadius: 50,
          flex: 0.1,
          left: "80%",
          bottom: "1%",
        }}
      >
        <TouchableOpacity
          onPress={() => handleSubmit()}
          style={{
            width: 65,
            height: 65,
            borderRadius: 50,
            color: "#FFFFFF",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <AntDesign name="arrowright" size={24} color="black" />
        </TouchableOpacity>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  checkbox: {
    marginRight: 15,

    borderColor: "#0CFEBC",
  },

  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
