import { StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions} from 'react-native';
import Header from './Header';
import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import LinearGradient from 'react-native-linear-gradient';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import ToggleSwitch from 'toggle-switch-react-native'
import { COLORS } from './colors';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppContext } from '../../user/AppContext';
import { useIsFocused } from '@react-navigation/native';
import WebView from 'react-native-webview';

export default function Privacy({navigation}) {
//const {name}=useContext(AppContext)




  return (
    <View
    style={{height:'100%'}}

  >

<View style={{ backgroundColor: "#252836",marginTop:40,height:50,alignItems:'center',justifyContent:'center'}}>
        <Text
          style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" ,}}
        >
   Privacy Policy
        </Text>
        </View>
        <WebView source={{ uri: 'https://yourdigiwill.com/privacy-policy' }} styles={{height:'100%',width:'100%'}} />




  </View>
  )
}
const styles = StyleSheet.create({


  header:{
    height:100,
    flexDirection:'row',alignItems:'center',justifyContent:'space-between'

  }
  
  })