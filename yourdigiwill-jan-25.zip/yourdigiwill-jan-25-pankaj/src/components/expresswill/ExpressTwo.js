import { StyleSheet, Text, View, Button, Image, TouchableOpacity, Dimensions, TextInput, ScrollView ,ImageBackground} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useRef, useEffect, useContext } from 'react'
import LinearGradient from 'react-native-linear-gradient';
import AntDesign from 'react-native-vector-icons/AntDesign';
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import ToggleSwitch from 'toggle-switch-react-native'
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppContext } from '../../../user/AppContext';
import { COLORS } from '../colors';
import bg from './../../../assets/bg.png'
import save from './../../../assets/save.png'
import back from './../../../assets/back.png'

import Entypo from 'react-native-vector-icons/Entypo'
import { LinearGradientText } from 'react-native-linear-gradient-text';

import { postWithAuthCall, putWithAuthCall, simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';

import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from 'react-native-popup-menu';
import NextStepsButton from '../NextStepsButton';
import StepnIndicatorcmp from './StepnIndicatorcmp';

export default function ExpressTwo({ navigation, route }) {
  const { name, token } = useContext(AppContext)
  const [state, setState] = useState([])
  const {id}=route.params
  useEffect(() => {
    getAllDistribution();
  }, [])

  const MenuFunction = (asset_name, asset_id) => {

    navigation.navigate('DistributionTwo', { asset_name: asset_name, asset_id: asset_id })


  }
  const handleSubmit=()=>{
    navigation.navigate('WitnessAndGuardians',{ id: id })
  }
  const handleSaveDraft = () => {
    postWithAuthCall(ApiConfig.DRAFT_DISTRIBUTION, {
      token: token, express_will_id: id,
      draft: "distribution"
    }).then((response) => {
      if (response.status) navigation.navigate('Home')

    })
  }
  const getAllDistribution = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_DISTRIBUTION, { token: token })
      .then((data) => {

        if (data) {
          console.log(data)
          setState(data.json)
          
        }
      })
      .catch((error) => {
        console.log("api response", error);

      });

  }





  return (



    
     <ImageBackground source={bg} style={{
                flex: 1,
            }}><SafeAreaView style={{
              flex: 1,
          }}>
      
      <View style={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        padding:15
                    }}>
                        <TouchableOpacity style={{
                            borderStyle: 'solid',
                            borderColor: '#0CFEBC',
                            backgroundColor: "rgba(5, 160, 129, 0.20)",
                            borderWidth: 1,
                            borderRadius: 25,
                            padding: 10
                        }}
                            onPress={() => {
                                navigation.navigate('ExpressOne',{id:id})
                            }}
                        >
                            <Image source={back} style={{
                                width: 20,
                                height: 20,
                            }} />
                        </TouchableOpacity>
                        <TouchableOpacity style={{
                            display: 'flex',
                            flexDirection: 'row',
                            height: '100%',
                            textAlign: 'center',
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}
                            onPress={handleSaveDraft}
                        >
                            <Image source={save} style={{
                                width: 25,
                                height: 25,
                            }} />
                            <Text style={{
                                color: COLORS.white,
                                fontSize: 18,
                                marginLeft: 7,
                            }}>Save as Draft</Text>
                        </TouchableOpacity>
                    </View>
      <View style={{ marginTop: 20, marginLeft: 15 }}>
        <LinearGradientText
          colors={['#0CFEBC', '#D0FF94', '#F9BA00', '#A6FEDB']}
          text="Express Will"
          textStyle={{ fontSize: 32, fontWeight: 'bold' }}
        />

        <StepnIndicatorcmp current={1}/>

      </View>

      {/* distribution body */}
      <View>
        <View style={{ borderBottomColor: "#05A081", borderBottomWidth: 2, marginRight: 15, marginLeft: 15, marginBottom: 10, padding: 10 }}><Text style={{ textAlign: 'center', color: 'white' }}>Please confirm your asset and distribution % with nominees</Text></View>
        <ScrollView>
          {
            state && state.length != 0 ? state.map((single) => {

              return (
                <>
                  <View style={{ backgroundColor: '#D9D9D9', borderColor:"#05A081",borderWidth:2 ,marginLeft: 15, marginRight: 15, borderRadius: 10, marginBottom: 15 }}>
                    <Text style={{ color: '#05A081', fontSize: 22, margin: 15,textDecorationStyle:'solid',textDecorationColor:'#05A081',textDecorationLine:'underline' }}>{single.category.category_name}</Text>
                    {
                      single.distribution.map((single_child1) => {

                        return (
                          <View key={single_child1.id} style={{ backgroundColor: single_child1.total_distribution == "100" ? "" : COLORS.light_red}}>
                            {single_child1.total_distribution != "100" ?
                              <Text style={{ color: "red", fontSize: 16, margin: 20 }}>{single_child1.remaining_distribution} % undefined</Text> : ""}
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginLeft: 15, marginRight: 15 }}>
                              <Text style={{ color: 'black', fontWeight:'bold',maxWidth:70,marginBottom:15 }}>{single_child1.asset_name}</Text>
                              <View >


                                {
                                  single_child1.nominees ?
                                    single_child1.nominees.map((single_child2) => {
                                      return (
                                        <View style={{ flexDirection: 'column' }}>
                                          <Text style={{ color: 'black', marginBottom: 25 ,maxWidth:100}}>{single_child2.nominee_name}</Text>
                                        </View>
                                      )
                                    }) :
                                    ""
                                }</View>
                              <View>
                                {
                                  single_child1.nominees ?
                                    single_child1.nominees.map((single_child2) => {
                                      return (
                                        <View style={{ flexDirection: 'column' }}>
                                          <Text style={{ color: 'black', marginBottom: 25 ,fontWeight:'bold'}}>{single_child2.distribution_percentage} %</Text>
                                        </View>
                                      )
                                    }) :""
                                }

                              </View>
                              <View>
                                {
                                  single_child1.nominees ?
                                    single_child1.nominees.map((single_child2) => {
                                      return (
                                        <View style={{ marginBottom: 25 }}>
                                          <Menu>
                                            <MenuTrigger >
                                              <Entypo name="dots-three-vertical" size={22} color="black" />
                                            </MenuTrigger>
                                            <MenuOptions>
                                              <MenuOption onSelect={() => MenuFunction(single_child1.asset_name, single_child1.asset_id)} text='Modify Distribution %' />
                                            </MenuOptions>
                                          </Menu>
                                        </View>
                                      )
                                    }) :  ""
                                }
                              </View>
                            </View>
                            {
                              single_child1.total_distribution == "100" ? "" :
                                (
                                  <View style={{ alignItems: 'center' }}>
                                    <TouchableOpacity
                                      onPress={() => navigation.navigate('DistributionTwo', { asset_name: single_child1.asset_name, asset_id: single_child1.asset_id })}
                                      style={{
                                        width: 90,
                                        height: 35,
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        backgroundColor: '#0CFEBC',
                                        borderRadius: 25,
                                        marginTop: 10,
                                        marginBottom: 20
                                      }}
                                    >
                                      <Text style={{ fontSize: 16, color: 'black' }}>Select</Text>
                                    </TouchableOpacity>
                                  </View>
                                )
                            }
                          </View>
                        )
                      })

                    }
                    <View>
                    </View>
                  </View>
                </>
              )
            }) :
              <View style={{ alignItems: 'center', justifyContent: 'center', alignItems: 'center', justifyContent: 'center', marginTop: 150 }}>
                <TouchableOpacity
                  onPress={() => navigation.navigate('Home')}
                  style={{
                    width: 100,
                    height: 100,
                    borderRadius: 50,
                    color: '#FFFFFF',
                    marginRight: 21,
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginTop: 10,
                    backgroundColor: '#252836'

                  }}
                >
                  <Image style={{ width: 100, height: 100 }} source={require('../../../assets/sharenow.png')} />

                </TouchableOpacity>
                <Text style={{ fontSize: 21, color: '#FFFFFF', marginTop: 5, paddingBottom: 10 }}>

                  Start Adding Assets Now!
                </Text>


              </View>
          }

        </ScrollView>

      </View>

      <NextStepsButton handleButtonPress={handleSubmit} active={true} />
      </SafeAreaView>
      </ImageBackground>
   


  )
}
const styles = StyleSheet.create({

  buttonTextStyle: {
    color: '#FFFFFF',
    textAlign: 'left',
    marginLeft: 0,
    fontSize: 16,
  },


})