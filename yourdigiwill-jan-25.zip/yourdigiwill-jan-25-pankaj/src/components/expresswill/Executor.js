import React, { useState, useEffect } from 'react'
import { View, Text, KeyboardAvoidingView, StyleSheet, ImageBackground, TouchableOpacity, Image, TextInput, ScrollView } from 'react-native'
import bg from "../../../assets/bg.png"
import back from "../../../assets/back.png"
import save from "../../../assets/save.png"
import GradientText from '../GradientText'
import LinearGradient from 'react-native-linear-gradient'
import Spinner from 'react-native-loading-spinner-overlay/lib'
import NextStepsButton from '../NextStepsButton'
import { COLORS } from '../colors'
import { getWithAuthCall, postWithAuthCall } from '../../../api/ApiServices'
import ApiConfig from '../../../api/ApiConfig'
import { showMessage } from 'react-native-flash-message'
import StepnIndicatorcmp from './StepnIndicatorcmp'
import {Formik} from 'formik'
import * as yup from "yup"
import { SafeAreaView } from 'react-native-safe-area-context'

const validationSchema = yup.object().shape({
    executorOneInputData: yup.object().shape({
        full_name: yup.string().required("Full name is required"),
        address: yup.string().required("Address is required"),
        city: yup.string().required("City is required"),
        state: yup.string().required("State is required"),
        mobile_no: yup.string().required("Mobile no is required").length(10, "Mobile no must be 10 digits"),
        email: yup.string().required("Email is required").email("Email is not valid"),
    }),
    executorTwoInputData: yup.object().shape({
        full_name: yup.string().required("Full name is required"),
        address: yup.string().required("Address is required"),
        city: yup.string().required("City is required"),
        state: yup.string().required("State is required"),
        mobile_no: yup.string().required("Mobile no is required").length(10, "Mobile no must be 10 digits"),
        email: yup.string().required("Email is required").email("Email is not valid"),
    })
})

const Executor = ({ navigation, route }) => {
    const { id } = route.params;
    const [loading, setLoading] = useState(false)

    const executorDataFormat = {
        full_name: '',
        address: '',
        city: '',
        state: '',
        mobile_no: '',
        email: '',
    }
    const [prefetchDataNeeded, setPrefetchDataNeeded] = useState(true)
    const [executorDraftData, setExecutorDraftData] = useState(null)

    useEffect(() => {
        if (prefetchDataNeeded) {
            setLoading(true)
            getWithAuthCall(ApiConfig.ADD_EXECUTOR + `?express_will_id=${id}`).then(response => {
                if (response.status) {
                    setLoading(false)
                    delete response.status
                    delete response.executor1.express_will
                    delete response.executor1.id
                    delete response.executor1.status
                    delete response.executor1.user
                    delete response.executor2.express_will
                    delete response.executor2.id
                    delete response.executor2.status
                    delete response.executor2.user
                    console.log(response)
                    setExecutorDraftData(response)
                }
                setLoading(false)
                setPrefetchDataNeeded(false)
            })
        }
    }, [prefetchDataNeeded])

    const handleSaveExecutorAsDraft = ({ executorOneData, executorTwoData }) => {
        setLoading(true)
        const reqBody = {
            "draft": "executor",
            "status": "draft",
            "executor_data": [
                {
                    "express_will_id": id,
                    ...executorOneData

                }, {
                    "express_will_id": id,
                    ...executorTwoData
                }

            ]
        }
        console.log(reqBody)

        postWithAuthCall(ApiConfig.ADD_DRAFT_EXECUTOR, reqBody).then((data) => {
            console.log(data);
            setLoading(false)
            const messageType = data.status ? "success" : "danger"
            showMessage({
                message: data.message,
                type: messageType
            })
            if(data.status)navigation.navigate("Home")
        })

    }

    const handleSaveExecutor = ({ executorOneData, executorTwoData }) => {
        setLoading(true)
        const reqBody = {
            "executor_data": [
                {
                    "express_will_id": id,
                    "status": "executor",
                    ...executorOneData
                },
                {
                    "express_will_id": id,
                    "status": "temproray-executor",
                    ...executorTwoData
                }
            ]
        }

        console.log(reqBody)
        postWithAuthCall(ApiConfig.ADD_EXECUTOR, reqBody).then((data) => {
            console.log(data);
            setLoading(false)
            const messageType = data.status ? "success" : "danger"
            showMessage({
                message: data.message,
                type: messageType
            })
            navigation.navigate("SpecialDirectives", { id: id })
        }).catch(err => console.log("eorr " + err))

    }

    return (

        <Formik
            validationSchema={validationSchema}
            enableReinitialize={true}
            initialValues={{
                executorOneInputData: {
                    full_name: executorDraftData?.executor1?.full_name,
                    address: executorDraftData?.executor1?.address,
                    city: executorDraftData?.executor1?.city,
                    state: executorDraftData?.executor1?.state,
                    mobile_no: executorDraftData?.executor1?.mobile_no,
                    email: executorDraftData?.executor1?.email,
                },
                executorTwoInputData: {
                    full_name: executorDraftData?.executor2?.full_name,
                    address: executorDraftData?.executor2?.address,
                    city: executorDraftData?.executor2?.city,
                    state: executorDraftData?.executor2?.state,
                    mobile_no: executorDraftData?.executor2?.mobile_no,
                    email: executorDraftData?.executor2?.email,
                },
            }}

            onSubmit={values => {
                console.log(values)
            }}

        >
            {({ handleChange, handleBlur, handleSubmit, values, errors, isValid, touched }) =>
                <KeyboardAvoidingView behavior='padding' style={styles.container}>
                    <ImageBackground source={bg} style={{
                        flex: 1,
                    }}><SafeAreaView style={{flex:1}}>
                        <Spinner visible={loading} color={COLORS.light_green} />
                        <NextStepsButton
                            handleButtonPress={() => {
                                handleSaveExecutor({ executorOneData: values.executorOneInputData, executorTwoData: values.executorTwoInputData })
                            }}
                            active={(isValid && values.executorOneInputData.full_name !== "")} />
                        <View style={{ flex: 1, padding: 15 }}>
                            <View style={{
                                display: 'flex',
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}>
                                <TouchableOpacity style={{
                                    borderStyle: 'solid',
                                    borderColor: '#0CFEBC',
                                    backgroundColor: "rgba(5, 160, 129, 0.20)",
                                    borderWidth: 1,
                                    borderRadius: 25,
                                    padding: 10
                                }}
                                    onPress={() => {
                                        navigation.navigate('WitnessAndGuardians',{id:id})
                                    }}
                                >
                                    <Image source={back} style={{
                                        width: 20,
                                        height: 20,
                                    }} />
                                </TouchableOpacity>
                                <TouchableOpacity style={{
                                    display: 'flex',
                                    flexDirection: 'row',
                                    height: '100%',
                                    textAlign: 'center',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                                    onPress={() => {
                                        handleSaveExecutorAsDraft({ executorOneData: values.executorOneInputData, executorTwoData: values.executorTwoInputData })
                                    }}
                                >
                                    <Image source={save} style={{
                                        width: 25,
                                        height: 25,
                                    }} />
                                    <Text style={{
                                        color: '#fff',
                                        fontSize: 18,
                                        marginLeft: 7,
                                    }}>Save as Draft</Text>
                                </TouchableOpacity>
                            </View>
                            
                            <View style={{
                                display: 'flex',
                                flexDirection: 'row',
                                marginTop: 20,
                                alignItems: 'center',
                            }}>
                                <GradientText style={{
                                    fontSize: 30,
                                    fontWeight: 'bold',
                                }}>
                                    Self Express Will
                                </GradientText>
                                <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#FFBF35', '#F73B71']} style={{
                                    paddingVertical: 5,
                                    paddingHorizontal: 10,
                                    borderRadius: 20,
                                    marginLeft: 10,
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center',

                                }} >
                                    <Text style={{
                                        color: '#fff',

                                    }}>MYSELF</Text>
                                </LinearGradient>
                            </View>
                            <StepnIndicatorcmp current={3}/>
                            <ScrollView>
                                <Text style={{
                                    color: COLORS.light_yello,
                                    fontSize: 18,
                                }}>Primary Executor</Text>
                                <View style={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                }}>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={{
                                            ...styles.inputLabelStyle,
                                            color: (errors.executorOneInputData?.full_name && touched.executorOneInputData?.full_name)? COLORS.pinkish_red:COLORS.light_green
                                        }}>
                                            Full Name(legal)
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorOneInputData?.full_name && touched.executorOneInputData?.full_name)? COLORS.pinkish_red:COLORS.light_green,color:'white'
                                            }}
                                            placeholder='Enter full name'
                                            onChangeText={handleChange('executorOneInputData.full_name')}
                                            onBlur={handleBlur('executorOneInputData.full_name')}
                                            value={values.executorOneInputData.full_name} />
                                            {
                                                (errors.executorOneInputData?.full_name && touched.executorOneInputData?.full_name) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorOneInputData?.full_name}</Text>
                                            }
                                    </View>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={{
                                            ...styles.inputLabelStyle,
                                            color: (errors.executorOneInputData?.mobile_no && touched.executorOneInputData?.mobile_no) ? COLORS.pinkish_red : COLORS.light_green
                                        }}>
                                            Executor mobile no
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorOneInputData?.mobile_no && touched.executorOneInputData?.mobile_no) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                            }}
                                            keyboardType='numeric'
                                            placeholder='+91 Enter mobile no'
                                            onChangeText={handleChange('executorOneInputData.mobile_no')}
                                            onBlur={handleBlur('executorOneInputData.mobile_no')}
                                            value={values.executorOneInputData.mobile_no} />
                                            {
                                                (errors.executorOneInputData?.mobile_no && touched.executorOneInputData?.mobile_no) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorOneInputData?.mobile_no}</Text>
                                            }
                                    </View>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={{
                                            ...styles.inputLabelStyle,
                                            color: (errors.executorOneInputData?.address && touched.executorOneInputData?.address) ? COLORS.pinkish_red : COLORS.light_green
                                        }}>
                                            Address line 1
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorOneInputData?.address && touched.executorOneInputData?.address) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                            }}
                                            placeholder='Enter address'
                                            onChangeText={handleChange('executorOneInputData.address')}
                                            onBlur={handleBlur('executorOneInputData.address')}
                                            value={values.executorOneInputData.address} />
                                            {
                                                (errors.executorOneInputData?.address && touched.executorOneInputData?.address) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorOneInputData?.address}</Text>
                                            }
                                    </View>
                                    <View style={{
                                        display: 'flex',
                                        flexDirection: 'row',
                                        justifyContent: 'space-between',
                                        width: '100%',
                                    }}>
                                        <View style={{ width: '48%', ...styles.textInputContainer }}>
                                            <Text style={{
                                                ...styles.inputLabelStyle,
                                                color: (errors.executorOneInputData?.city && touched.executorOneInputData?.city) ? COLORS.pinkish_red : COLORS.light_green
                                            }}>
                                                City
                                            </Text>
                                            <TextInput
                                                style={{
                                                    ...styles.textInputStyle,
                                                    borderColor: (errors.executorOneInputData?.city && touched.executorOneInputData?.city) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                                }}
                                                placeholder='Enter city'
                                                onChangeText={handleChange('executorOneInputData.city')}
                                                onBlur={handleBlur('executorOneInputData.city')}
                                                value={values.executorOneInputData.city} />
                                                {
                                                    (errors.executorOneInputData?.city && touched.executorOneInputData?.city) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorOneInputData?.city}</Text>
                                                }
                                        </View>
                                        <View style={{ width: '48%', ...styles.textInputContainer }}>
                                            <Text style={{
                                                ...styles.inputLabelStyle,
                                                color: (errors.executorOneInputData?.state && touched.executorOneInputData?.state) ? COLORS.pinkish_red : COLORS.light_green
                                            }}>
                                                State
                                            </Text>
                                            <TextInput
                                                style={{
                                                    ...styles.textInputStyle,
                                                    borderColor: (errors.executorOneInputData?.state && touched.executorOneInputData?.state) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                                }}
                                                placeholder='Enter state'
                                                onChangeText={handleChange('executorOneInputData.state')}
                                                onBlur={handleBlur('executorOneInputData.state')}
                                                value={values.executorOneInputData.state} />
                                                {
                                                    (errors.executorOneInputData?.state && touched.executorOneInputData?.state) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorOneInputData?.state}</Text>
                                                }
                                        </View>
                                    </View>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={{
                                            ...styles.inputLabelStyle,
                                            color: (errors.executorOneInputData?.email && touched.executorOneInputData?.email) ? COLORS.pinkish_red : COLORS.light_green
                                        }}>
                                            Email
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorOneInputData?.email && touched.executorOneInputData?.email) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                            }}
                                            placeholder='Enter email'
                                            autoCapitalize='none'
                                            onChangeText={handleChange('executorOneInputData.email')}
                                            onBlur={handleBlur('executorOneInputData.email')}
                                            value={values.executorOneInputData.email} />
                                            {
                                                (errors.executorOneInputData?.email && touched.executorOneInputData?.email) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorOneInputData?.email}</Text>
                                            }
                                    </View>
                                </View>
                                <Text style={{
                                    color: COLORS.light_yello,
                                    fontSize: 18,
                                    marginTop: 40,
                                }}>Secondary Executor</Text>
                                <View style={{
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                }}>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={{
                                            ...styles.inputLabelStyle,
                                            color: (errors.executorTwoInputData?.full_name && touched.executorTwoInputData?.full_name) ? COLORS.pinkish_red : COLORS.light_green
                                        }}>
                                            Full Name(legal)
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorTwoInputData?.full_name && touched.executorTwoInputData?.full_name) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                            }}
                                            onChangeText={handleChange('executorTwoInputData.full_name')}
                                            onBlur={handleBlur('executorTwoInputData.full_name')}
                                            placeholder='Enter full name'
                                            value={values.executorTwoInputData.full_name} />
                                        {
                                            (errors.executorTwoInputData?.full_name && touched.executorTwoInputData?.full_name) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorTwoInputData?.full_name}</Text>
                                        }
                                    </View>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={styles.inputLabelStyle}>
                                            Executor mobile no
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorTwoInputData?.mobile_no && touched.executorTwoInputData?.mobile_no) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                            }}

                                            placeholder='+91 Enter mobile no'
                                            keyboardType='numeric'
                                            onChangeText={handleChange('executorTwoInputData.mobile_no')}
                                            onBlur={handleBlur('executorTwoInputData.mobile_no')}
                                            value={values.executorTwoInputData.mobile_no} />
                                        {
                                            (errors.executorTwoInputData?.mobile_no && touched.executorTwoInputData?.mobile_no) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorTwoInputData?.mobile_no}</Text>
                                        }
                                    </View>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={{
                                            ...styles.inputLabelStyle,
                                            color: (errors.executorTwoInputData?.address && touched.executorTwoInputData?.address) ? COLORS.pinkish_red : COLORS.light_green
                                        }}>
                                            Address line 1
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorTwoInputData?.address && touched.executorTwoInputData?.address) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                            }}
                                            placeholder='Enter address'
                                            onChangeText={handleChange('executorTwoInputData.address')}
                                            onBlur={handleBlur('executorTwoInputData.address')}
                                            value={values.executorTwoInputData.address} />
                                        {
                                            (errors.executorTwoInputData?.address && touched.executorTwoInputData?.address) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorTwoInputData?.address}</Text>
                                        }
                                    </View>
                                    <View style={{
                                        display: 'flex',
                                        flexDirection: 'row',
                                        justifyContent: 'space-between',
                                        width: '100%',
                                    }}>
                                        <View style={{ width: '48%', ...styles.textInputContainer }}>
                                            <Text style={styles.inputLabelStyle}>
                                                City
                                            </Text>
                                            <TextInput
                                                style={{
                                                    ...styles.textInputStyle,
                                                    borderColor: (errors.executorTwoInputData?.city && touched.executorTwoInputData?.city) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                                }}
                                                placeholder='Enter city'
                                                onChangeText={handleChange('executorTwoInputData.city')}
                                                onBlur={handleBlur('executorTwoInputData.city')}
                                                value={values.executorTwoInputData.city} />
                                            {
                                                (errors.executorTwoInputData?.city && touched.executorTwoInputData?.city) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorTwoInputData?.city}</Text>
                                            }
                                        </View>
                                        <View style={{ width: '48%', ...styles.textInputContainer }}>
                                            <Text style={styles.inputLabelStyle}>
                                                State
                                            </Text>
                                            <TextInput
                                                style={{
                                                    ...styles.textInputStyle,
                                                    borderColor: (errors.executorTwoInputData?.state && touched.executorTwoInputData?.state) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                                }}
                                                placeholder='Enter state'
                                                onChangeText={handleChange('executorTwoInputData.state')}
                                                onBlur={handleBlur('executorTwoInputData.state')}
                                                value={values.executorTwoInputData.state} />
                                            {
                                                (errors.executorTwoInputData?.state && touched.executorTwoInputData?.state) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorTwoInputData?.state}</Text>
                                            }
                                        </View>
                                    </View>
                                    <View style={{ width: '100%', ...styles.textInputContainer }}>
                                        <Text style={{
                                            ...styles.inputLabelStyle,
                                            color: (errors.executorTwoInputData?.email && touched.executorTwoInputData?.email) ? COLORS.pinkish_red : COLORS.light_green
                                        }}>
                                            Email
                                        </Text>
                                        <TextInput
                                            style={{
                                                ...styles.textInputStyle,
                                                borderColor: (errors.executorTwoInputData?.email && touched.executorTwoInputData?.email) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                                            }}
                                            placeholder='Enter email'
                                            autoCapitalize='none'
                                            onChangeText={handleChange('executorTwoInputData.email')}
                                            onBlur={handleBlur('executorTwoInputData.email')}
                                            value={values.executorTwoInputData.email} />
                                        {
                                            (errors.executorTwoInputData?.email && touched.executorTwoInputData?.email) && <Text style={{ color: COLORS.pinkish_red }}>{errors.executorTwoInputData?.email}</Text>
                                        }
                                    </View>
                                </View>
                            </ScrollView>

                        </View>
                        </SafeAreaView>
                    </ImageBackground>
                </KeyboardAvoidingView>}
        </Formik>
    )
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    text: {
        color: '#fff',
        fontSize: 30,
        fontWeight: 'bold',
    },

    inputLabelStyle: {
        color: COLORS.light_green,
        fontSize: 18,
        marginTop: 10,
    },
    textInputContainer: {
        display: 'flex',
        flexDirection: 'column',
        marginTop: 10,
    },
    textInputStyle: {
        borderStyle: 'solid',
        borderColor: '#0CFEBC',
        borderBottomWidth: 1,
        padding: 0,
    }
});
export default Executor