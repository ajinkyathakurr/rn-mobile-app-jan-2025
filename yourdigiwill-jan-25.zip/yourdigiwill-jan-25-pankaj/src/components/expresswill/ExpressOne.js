import { StyleSheet, Text, View, Button, Image, ImageBackground, TouchableOpacity, Dimensions, TextInput, ScrollView, KeyboardAvoidingView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useState, useRef, useEffect, useContext } from 'react'

import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppContext } from '../../../user/AppContext';
import { COLORS } from '../colors';

import { LinearGradientText } from 'react-native-linear-gradient-text';
import DatePicker from 'react-native-date-picker';
import { PostCallWithErrorResponse, putWithAuthCall, simpleGetCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import SelectDropdown from 'react-native-select-dropdown'
import { showMessage, hideMessage } from "react-native-flash-message";
import NextStepsButton from '../NextStepsButton';
import bg from './../../../assets/bg.png'
import save from './../../../assets/save.png'
import back from './../../../assets/back.png'
import StepnIndicatorcmp from './StepnIndicatorcmp';
import { Colors } from 'react-native/Libraries/NewAppScreen';
const nationality = ['Indian', 'American']


export default function ExpressOne({ navigation, route }) {
  const { name, token } = useContext(AppContext)
  const [data, setData] = useState({ legal_name: "", gender: "", religion: "", city: "", state: "", dob: "", occupation: "", nationality: "", optional_address: "", pan_id: "", mobile_no: "", email: "", address_name: "" })
  const [open, setOpen] = useState(false)
  const { id } = route.params;
  const getData = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_PROFILE, { token: token })
      .then((data) => {
        if (data) {
          console.log(data.json.data)
          setData({ ...data.json.data, address_name: data.json.data.user_address.name })
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  }
  const handleSubmit = () => {
    putWithAuthCall(
      ApiConfig.GET_PROFILE,
      {
        token: token,
        dob: data.dob,
        full_name: data.full_name,
        gender: data.gender,
        religion: data.religion,
        occupation: data.occupation,
        nationality: data.nationality,
        pan_id: data.pan_id,
        optional_address: data.optional_address,
        city: data.user_address.city,
        state: data.user_address.state,
        mobile_no: data.mobile_no,
        email: data.email,
        user_address:{
          name:data.address_name
        }
      }
    ).then((data) => {

      if (data.status) {
        navigation.navigate('ExpressTwo', { id: id })
      }
    })
      .catch((error) => {
        console.log("api response", error);
      });

  }
  const handleSaveDraft = () => {
    putWithAuthCall(
      ApiConfig.GET_PROFILE,
      {
        token: token,
        express_will_id: id,
        draft: "legal_doc",
        dob: data.dob,
        full_name: data.full_name,
        gender: data.gender,
        religion: data.religion,
        occupation: data.occupation,
        nationality: data.nationality,
        pan_id: data.pan_id,
        optional_address: data.optional_address,
        city: data.city,
        state: data.state,
        mobile_no: data.mobile_no,
        email: data.email,
        "user_address":{
          "name":data.address_name
        }
      }
    ).then((data) => {

      if (data.status) {
        navigation.navigate('Home')


      }
    })
      .catch((error) => {
        console.log("api response", error);
      });



  }



  useEffect(() => {


    getData()


  }, [])


  const handleLogout = () => {


    AsyncStorage.clear();
    setTimeout(() => {
      navigation.navigate('LoginSignup')

    }, 1000);
  }


  return (

    <KeyboardAvoidingView behavior='padding' style={{flex:1}}>
    <ImageBackground source={bg} style={{
      flex: 1,
    }}>
      <SafeAreaView style={{flex:1}}>
        
     
       
        <View style={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'space-between',
          padding: 15
        }}>
          <TouchableOpacity style={{
            borderStyle: 'solid',
            borderColor: '#0CFEBC',
            backgroundColor: "rgba(5, 160, 129, 0.20)",
            borderWidth: 1,
            borderRadius: 25,
            padding: 10
          }}
            onPress={() => {
              navigation.navigate("Home")
            }}
          >
            <Image source={back} style={{
              width: 20,
              height: 20,
            }} />
          </TouchableOpacity>
          <TouchableOpacity style={{
            display: 'flex',
            flexDirection: 'row',
            height: '100%',
            textAlign: 'center',
            alignItems: 'center',
            justifyContent: 'center',
          }}
            onPress={handleSaveDraft}
          >
            <Image source={save} style={{
              width: 25,
              height: 25,
            }} />
            <Text style={{
              color: COLORS.white,
              fontSize: 18,
              marginLeft: 7,
            }}>Save as Draft</Text>
          </TouchableOpacity>
        </View>


        



          <View style={{ marginLeft: 15 }}>

            <LinearGradientText
              colors={['#0CFEBC', '#D0FF94', '#F9BA00', '#A6FEDB']}
              text="Self Express Will"

              textStyle={{ fontSize: 32, fontWeight: 'bold' }}
            />

            <StepnIndicatorcmp current={0} />

          </View>
          <ScrollView style={{ marginBottom: 20 }}>
         
          <View style={{ marginLeft: 15, marginRight: 15, marginTop: 20 }}>
            <Text style={{ color: COLORS.light_green_new }}>
              Full Name(legal)
            </Text>
            <TextInput
              value={data.legal_name}
              onChangeText={(text) => setData({ ...data, legal_name: text })}
              placeholderTextColor={COLORS.light_green_new}
              style={{ borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2,marginTop:5, color: 'white' ,paddingBottom:10}}

            >

            </TextInput>
          </View>
          <View style={styles.halfInputContainer}>

            <View style={styles.halfInputStyle}>
              <Text style={{ color: COLORS.light_green_new }}>
                gender
              </Text>
              <SelectDropdown
                data={['Male', 'Female', 'Others']}
                buttonStyle={{ backgroundColor: 'transparent', width: 150, borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2 }}
                onSelect={(selectedItem, index) => {
                  setData({ ...data, gender: selectedItem })
                }}
                defaultValue={data.gender ? data.gender : null}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Select--"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={styles.buttonTextStyle}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
            </View>
            <View style={styles.halfInputStyle}>
              <Text style={{ color: COLORS.light_green_new }}>
                Religion    </Text>
              <SelectDropdown
                data={['Hindu', 'Muslim', 'Sikh', 'Christians', 'Jains', 'Others']}
                buttonStyle={{ backgroundColor: 'transparent', width: 150, borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2 }}
                onSelect={(selectedItem, index) => {
                  setData({ ...data, religion: selectedItem })
                }}
                defaultValue={data.religion ? data.religion : null}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Select--"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={styles.buttonTextStyle}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
            </View>


          </View>

          <View style={styles.halfInputContainer}>

            <View style={styles.halfInputStyle}>
              <Text style={{ color: COLORS.light_green_new,width:100 }}>
                Date of Birth  </Text>
              <DatePicker
                modal
                mode='date'
                open={open}
                format="YYYY-MM-DD"
                date={data.dob ? new Date(data.dob) : new Date('2000-1-1')}
                onConfirm={(date) => {
                  setOpen(false)
                  var year = date.getFullYear();
                  var month = (date.getMonth() + 1).toString().padStart(2, '0'); // Adding 1 since months are 0-based
                  var day = date.getDate().toString().padStart(2, '0');
                  setData({ ...data, dob: `${year}-${month}-${day}` })
                }}
                onCancel={() => {
                  setOpen(false)
                }}
              />
              <TouchableOpacity style={{
          borderBottomWidth: 2,
          borderBottomColor: COLORS.light_green,
          width: 100,
          paddingBottom:15,
          paddingTop:20
        }}
        onPress={() => setOpen(true)} >
                <Text style={{color:COLORS.white}}>{data.dob} </Text>
              </TouchableOpacity>
            </View>
            <View style={styles.halfInputStyle}>
              <Text style={{ color: COLORS.light_green_new, width: 150 }}>
                Occupation    </Text>
              <SelectDropdown
                data={['salaried', 'self-employed', 'un-employed', 'Others']}
                buttonStyle={{ backgroundColor: 'transparent', width: 150, borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2 }}
                onSelect={(selectedItem, index) => {
                  setData({ ...data, occupation: selectedItem })
                }}
                defaultValue={data.occupation ? data.occupation : null}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Select--"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={styles.buttonTextStyle}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
            </View>


          </View>
          <View style={styles.halfInputContainer}>
            <View style={styles.halfInputStyle}>
              <Text style={{ color: COLORS.light_green_new, width: 150 }}>
                Nationality
              </Text>
              <SelectDropdown
                data={nationality}
                buttonStyle={{ backgroundColor: 'transparent', borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2, width: 150 }}
                onSelect={(selectedItem, index) => {
                  console.log(selectedItem, index)
                  setData({ ...data, nationality: selectedItem })
                }}
                defaultValue={data.nationality ? data.nationality : null}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Nationality"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={styles.buttonTextStyle}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
            </View>
            <View style={{...styles.halfInputStyle}}>
              <Text style={{ color: COLORS.light_green_new ,marginBottom:20}}>
                PAN Card    </Text>
              <TextInput
                editable={false}
                value={data.pan_id}
                onChangeText={(text) => setData({ ...data, pan_id: text })}
                placeholderTextColor={COLORS.light_green_new}
                style={{...styles.inputTextStyle,height:30,paddingBottom:20}}

              >
              </TextInput>
              
            </View>



          </View>
          <View style={{ marginLeft: 15, marginRight: 15, marginTop: 20 }}>
            <Text style={{ color: COLORS.light_green_new,marginBottom:5 }}>
              Address
            </Text>
            <TextInput
              value={data.address_name}
              editable={true}
              onChangeText={(text) => setData({ ...data, address_name: text })}
              placeholderTextColor={COLORS.light_green_new}
              style={{...styles.inputTextStyle,height:30,paddingBottom:0,width:"100%"}}

            >

            </TextInput>
          </View>
          <View style={styles.halfInputContainer}>
            <View style={styles.halfInputStyle}>
              <Text style={{ color: COLORS.light_green_new }}>
                City
              </Text>
              <TextInput
                value={(data.user_address)?data.user_address.city:""}
                editable={false}
                placeholderTextColor={COLORS.light_green_new}
                style={styles.inputTextStyle}

              >

              </TextInput>
            </View>
            <View style={styles.halfInputStyle}>
              <Text style={{ color: COLORS.light_green_new }}>
                State
              </Text>
              <TextInput
                value={(data.user_address)?data.user_address.state:""}
                editable={false}
               
                placeholderTextColor={COLORS.light_green_new}
                style={styles.inputTextStyle}

              >

              </TextInput>
            </View>
          </View>
          <View style={{ marginLeft: 15, marginRight: 15, marginTop: 20 }}>
            <Text style={{ color: COLORS.light_green_new }}>
              Optional Address
            </Text>
            <TextInput
              value={data.optional_address}
              
              onChangeText={(text) => setData({ ...data, optional_address: text })}
              placeholderTextColor={COLORS.light_green_new}
              style={{ borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2, color: 'white' }}

            >

            </TextInput>
          </View>
          <View style={{ marginLeft: 15, marginRight: 15, marginTop: 20 }}>
            <Text style={{ color: COLORS.light_green_new }}>
              Phone number(legal)
            </Text>
            <TextInput
              value={data.mobile_no}
              onChangeText={(text) => setData({ ...data, legal_name: text })}
              placeholderTextColor={COLORS.light_green_new}
              style={{ borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2, color: 'white' }}
              editable={false}
            >

            </TextInput>
          </View>

          <View style={{ marginLeft: 15, marginRight: 15, marginTop: 20 }}>
            <Text style={{ color: COLORS.light_green_new }}>
              Email(legal)
            </Text>
            <TextInput
              value={data.email}
              editable={false}
              onChangeText={(text) => setData({ ...data, legal_name: text })}
              placeholderTextColor={COLORS.light_green_new}
              style={{ borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2, color: 'white' }}

            >

            </TextInput>

          </View>

         
        </ScrollView>
        <NextStepsButton handleButtonPress={handleSubmit} active={true} />
        </SafeAreaView>
      
      
     
      </ImageBackground>
      </KeyboardAvoidingView>

  )
}
const styles = StyleSheet.create({

  buttonTextStyle: {
    color: '#FFFFFF',
    textAlign: 'left',
    marginLeft: 0,
    fontSize: 16,
  },
  halfInputStyle: {
    width: '20%',
    marginRight: 150
  },
  halfInputContainer:
  {
    marginLeft: 15,
    marginRight: 15,
    marginTop: 20,
    flexDirection: 'row',
    width: '80%'
  },
  inputTextStyle:
  {
    borderBottomColor: COLORS.light_green_new,
    borderBottomWidth: 2,
    color: 'white',
    width: 150
  }


})