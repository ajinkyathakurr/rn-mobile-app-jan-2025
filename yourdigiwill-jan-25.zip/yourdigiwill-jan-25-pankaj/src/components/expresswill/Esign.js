import { View, Text, StyleSheet, TouchableHighlight, ImageBackground, KeyboardAvoidingView } from 'react-native'
import React from 'react'

import bg from "../../../assets/bg.png"
import { TouchableOpacity } from 'react-native-gesture-handler';
import { COLORS } from '../colors';
import {postWithAuthCall} from '../../../api/ApiServices'
import ApiConfig from '../../../api/ApiConfig';
import AntDesign from "react-native-vector-icons/AntDesign";
import PDFView from "react-native-view-pdf";
import { useState,useEffect } from 'react';
import { showMessage } from 'react-native-flash-message';


export default function Esign({ route,navigation }) {
  const { id } = route.params;
  const [pdfuri ,seTpdfuri]=useState(null)
  useEffect(() => {
    //may be used for future use... if url for draft is cached
    if (route.params.url) {
      seTpdfuri(route.params.url);
    } else {
      postWithAuthCall(ApiConfig.EXPRESS_WILL_PDF, {
        express_will_id: id,        
      }).then((data) => {
        seTpdfuri(data.express_will.express_will_doc_draft);
        console.log(pdfuri);
      });
    }
  }, []);
  const InitiateEsign=()=>{
    postWithAuthCall(ApiConfig.INIT_ESIGN,{"express_will_id":route.params.id}).then((res)=>{
      if(res.status){
        showMessage({message:"E-Sign Process Started. Check you e-mail for further procedure",type:'success'})
        navigation.navigate('Home')
      }
    }).catch(()=>{
      showMessage({message:"Error occured , please retry",type:'danger'})
      navigation.navigate('Home')
    })
  }
  const resources = {
    url: pdfuri,
  };
  const resourceType = "url";
  return (
    <ImageBackground style={{ flex: 1,paddingTop:20,paddingBottom:20,justifyContent:'space-around',alignItems:'center' }} source={bg}>
    <AntDesign name='checkcircle'color={COLORS.light_yello} size={40}/>
    <Text style={{color:COLORS.white,fontSize:15}}>If E-sign process fails all three parties have to E-sign again</Text>
    {pdfuri && (
            <View
              style={{
                height: "70%",
                width: "95%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: 15,
                overflow: "hidden",
              }}
            >
              <PDFView
                fadeInDuration={250.0}
                style={{ height: "100%", width: "100%" }}
                resource={resources[resourceType]}
                resourceType={resourceType}
                onLoad={() => console.log(`PDF rendered from ${resourceType}`)}
                onError={(error) => console.log("Cannot render PDF", error)}
              />
            </View>
          )}
          <TouchableOpacity onPress={InitiateEsign} style={{borderRadius:50,width:150,height:50,display:'flex',flexDirection:'row',justifyContent:'space-around',padding:10,alignItems:'center',backgroundColor:COLORS.light_yello}}>
            <Text style={{fontSize:20,color:COLORS.black,fontWeight:'bold'}}>E-Sign</Text>
            <AntDesign name='cloudupload' color={COLORS.black} size={35}/>
          </TouchableOpacity>
    </ImageBackground>





  )

}

const styles = StyleSheet.create({
  
});