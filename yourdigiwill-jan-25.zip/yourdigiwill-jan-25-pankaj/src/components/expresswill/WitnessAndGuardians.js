import React, { useEffect, useState } from 'react'
import { View, Text, StyleSheet, ImageBackground, StatusBar, Image, TextInput, ScrollView, TouchableOpacity, KeyboardAvoidingView } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import { Dropdown } from 'react-native-element-dropdown'
import Spinner from 'react-native-loading-spinner-overlay/lib'
import AsyncStorage from '@react-native-async-storage/async-storage'
import bg from "./../../../assets/bg.png"
import back from './../../../assets/back1.png'
import save from './../../../assets/save.png'
import arrow_forward from './../../../assets/arrow_forward.png'
import { getWithAuthCall, postWithAuthCall } from '../../../api/ApiServices'
import ApiConfig from '../../../api/ApiConfig'
import { showMessage } from 'react-native-flash-message'
import { Formik } from 'formik'
import * as yup from 'yup'
import NextStepsButton from '../NextStepsButton'
import GradientText from '../GradientText'
import { COLORS } from '../colors'
import StepnIndicatorcmp from './StepnIndicatorcmp'
import { SafeAreaView } from 'react-native-safe-area-context'
import SelectDropdown from 'react-native-select-dropdown'
const validationSchema = yup.object().shape({
  witnessOneInputData: yup.object().shape({
    full_name: yup.string().required('Full name is required'),
    gender: yup.string().required('Gender is required'),
    religion: yup.string().required('Religion is required'),
    adhar_card: yup.string().required('Aadhar no.is required'),
    age: yup.string().required('Age is required').matches(/^[0-9]+$/, "Must be only digits"),
    addressLineOne: yup.string().required('Address line 1 is required'),
    addressLineTwo: yup.string().required('Address line 2 is required'),
    city: yup.string().required('City is required'),
    state: yup.string().required('State is required'),
    email: yup.string().required('Email is required').email('Email is invalid'),
    mobile_no: yup.string().required('Mobile no. is required').max(13, 'Invalid mobile no.')
  }),
  witnessTwoInputData: yup.object().shape({
    full_name: yup.string().required('Full name is required'),
    gender: yup.string().required('Gender is required'),
    religion: yup.string().required('Religion is required'),
    adhar_card: yup.string().required('Aadhar no.is required').matches(/^[0-9]+$/, "Must be only digits"),
    age: yup.string().required('Age is required').matches(/^[0-9]+$/, "Must be only digits"),
    addressLineOne: yup.string().required('Address line 1 is required'),
    addressLineTwo: yup.string().required('Address line 2 is required'),
    city: yup.string().required('City is required'),
    state: yup.string().required('State is required'),
    email: yup.string().required('Email is required').email('Email is invalid'),
    mobile_no: yup.string().required('Mobile no. is required').max(13, 'Invalid mobile no.')
  })
})

const WitnessAndGuardians = ({ navigation, route }) => {

  const [loading, setLoading] = useState(false)
  const [prefetchDataNeeded, setPrefetchDataNeeded] = useState(true);
  const [draftWitnessData, setDraftWitnessData] = useState(null)
  const { id } = route.params;

  useEffect(() => {
    if (route.params && prefetchDataNeeded) {
      setLoading(true)
      getWithAuthCall(ApiConfig.ADD_WITNESS + "?express_will_id=" + id).then((data) => {
        console.log(data)
        setLoading(false)
        if (data.status) {
          delete data.status
          delete data.key
          delete data.witness1.id
          delete data.witness1.esign_completed
          delete data.witness1.user
          delete data.witness1.express_will
          delete data.witness2.id
          delete data.witness2.esign_completed
          delete data.witness2.user
          delete data.witness2.express_will
          setWitnessOneRelation(findRelationByLabel(data.witness1.relation))
          setWitnessTwoRelation(findRelationByLabel(data.witness2.relation))
          setDraftWitnessData({
            witness1: data.witness1,
            witness2: data.witness2
          })
          setPrefetchDataNeeded(false)
        }
      }).catch(()=>{
        showMessage({message:"Error occured while fetching data",type:"danger"})
        setLoading(false);
        navigation.navigate("ExpressTwo",{id:id})
      })
    }
  }, [prefetchDataNeeded])

  const relations = [

    { label: "Father", value: 1 },
    { label: "Mother", value: 2 },
    { label: "Son", value: 3 },
    { label: "Daughter", value: 4 },
    { label: "Husband", value: 5 },
    { label: "Wife", value: 6 },
    { label: "Brother", value: 7 },
    { label: "Sister", value: 8 },
    { label: "Grandfather", value: 9 },
    { label: "Grandmother", value: 10 },
    { label: "Grandson", value: 11 },
    { label: "Granddaughter", value: 12 },
    { label: "Uncle", value: 13 },
    { label: "Aunt", value: 14 },
    { label: "Nephew", value: 15 },
    { label: "Niece", value: 16 },
    { label: "Cousin", value: 17 },
    { label: "Friend", value: 18 },
    { label: "Other", value: 19 },
  ];
  const [witnessOneRelation, setWitnessOneRelation] = useState(null);
  const [witnessTwoRelation, setWitnessTwoRelation] = useState(null);
  const [wit1gender,SetWit1gender]=useState("Male")
  const [wit2gender,SetWit2gender]=useState("Male")
  const [wit2rel,SetWit2rel]=useState("Hindu")
  const [wit1rel,SetWit1rel]=useState("Hindu")

  function findRelationByLabel(label) {
    for (let i = 0; i < relations.length; i++) {
      if (relations[i].label === label) {
        return { _index: i, label: relations[i].label, value: relations[i].value };
      }
    }

    return null; // return null if no matching label is found
  }

  const handleSaveWitnessAsDraft = ({ witnessOneData, witnessTwoData }) => {
    setLoading(true)
    const requestBody = {
      draft: "witness",
      witness_data: [{
        ...witnessOneData,
        relation: witnessOneRelation.label,
        gender:wit1gender,
        religion:wit1rel,
        address: witnessOneData.addressLineOne + "," + witnessOneData.addressLineTwo,
        express_will_id: id
      },
      {
        ...witnessTwoData,
        gender:wit2gender,
        religion:wit2rel,
        relation: witnessTwoRelation.label,
        address: witnessTwoData.addressLineOne + "," + witnessTwoData.addressLineTwo,
        express_will_id: id
      }]
    }
    delete requestBody.witness_data[0].addressLineOne
    delete requestBody.witness_data[0].addressLineTwo
    delete requestBody.witness_data[1].addressLineOne
    delete requestBody.witness_data[1].addressLineTwo

    console.log(requestBody)
    postWithAuthCall(ApiConfig.ADD_WITNESS_DRAFT, requestBody).then((data) => {
      console.log(data)
      setLoading(false)
      if (data.status) {
        showMessage({
          message: data.message,
          type: "success"
        })
      }
    })

  }

  const handleSaveWitness = ({ witnessOneData, witnessTwoData }) => {
    if(!witnessOneRelation || !witnessTwoRelation){
      showMessage({
        message: "Please select relation",
        type: "danger"
      })
      return
    }
    setLoading(true)
    console.log(witnessOneData)
    const requestBody = {
      witness_data: [{
        ...witnessOneData,
        gender:wit1gender,
        religion:wit1rel,
        relation: witnessOneRelation.label,
        address: witnessOneData.addressLineOne + "," + witnessOneData.addressLineTwo,
        express_will_id: id
      }, {
        ...witnessTwoData,
        gender:wit2gender,
        religion:wit2rel,
        relation: witnessTwoRelation.label,
        address: witnessTwoData.addressLineOne + "," + witnessTwoData.addressLineTwo,
        express_will_id: id
      }]
    }
    delete requestBody.witness_data[0].addressLineOne
    delete requestBody.witness_data[0].addressLineTwo
    delete requestBody.witness_data[1].addressLineOne
    delete requestBody.witness_data[1].addressLineTwo
    console.log(requestBody)

    postWithAuthCall(ApiConfig.ADD_WITNESS, requestBody).then((data) => {
      console.log(data)
      setLoading(false)
      const messageType = data.status ? "success" : "danger"
      showMessage({
        message: data.message,
        type: messageType
      })
      if (data.status) {
        navigation.navigate('Executor', { id: id })
      }
    })
  }

  return (
    <Formik
      enableReinitialize={true}
      validateOnMount={true}
      initialValues={{
        witnessOneInputData: {
          full_name: draftWitnessData?.witness1?.full_name,
          gender: draftWitnessData?.witness1?.gender,
          religion: draftWitnessData?.witness1?.religion,
          adhar_card: draftWitnessData?.witness1?.adhar_card,
          age: draftWitnessData?.witness1?.age,
          addressLineOne: draftWitnessData?.witness1?.address?.split(',')[0],
          addressLineTwo: draftWitnessData?.witness1?.address?.split(',')[1],
          city: draftWitnessData?.witness1?.city,
          state: draftWitnessData?.witness1?.state,
          email: draftWitnessData?.witness1?.email,
          mobile_no: draftWitnessData?.witness1?.mobile_no
        },
        witnessTwoInputData: {
          full_name: draftWitnessData?.witness2?.full_name,
          gender: draftWitnessData?.witness2?.gender,
          religion: draftWitnessData?.witness2?.religion,
          adhar_card: draftWitnessData?.witness2?.adhar_card,
          age: draftWitnessData?.witness2?.age,
          addressLineOne: draftWitnessData?.witness2?.address?.split(',')[0],
          addressLineTwo: draftWitnessData?.witness2?.address?.split(',')[1],
          city: draftWitnessData?.witness2?.city,
          state: draftWitnessData?.witness2?.state,
          email: draftWitnessData?.witness2?.email,
          mobile_no: draftWitnessData?.witness2?.mobile_no
        }
      }}

      onSubmit={(values) => {
        console.log(values)
        console.log(witnessOneRelation)
        console.log(witnessTwoRelation)
      }}

      validationSchema={validationSchema}
    >
      {({ values, handleChange, handleBlur, handleSubmit, errors, isValid, touched }) =>
        <KeyboardAvoidingView behavior='padding' style={styles.container}>
          <ImageBackground source={bg} style={{
            flex: 1,
          }}>
            <SafeAreaView style={{flex:1}}>
            <Spinner visible={loading} color={COLORS.light_green} />
            {/* Next steps button */}
            <NextStepsButton handleButtonPress={() => {
              handleSaveWitness({
                witnessOneData: values.witnessOneInputData,
                witnessTwoData: values.witnessTwoInputData
              })
            }} active={isValid} />

            <View style={{ flex: 1, padding: 15 }}>
              {/* Header */}
              <View style={{
                display: 'flex',
                flexDirection: 'row',
                justifyContent: 'space-between',
              }}>
                <TouchableOpacity style={{
                  borderStyle: 'solid',
                  borderColor: '#0CFEBC',
                  backgroundColor: "rgba(5, 160, 129, 0.20)",
                  borderWidth: 1,
                  borderRadius: 25,
                  padding: 10
                }}
                  onPress={() => {
                    navigation.navigate('ExpressTwo',{id:id})
                  }}
                >
                  <Image source={back} style={{
                    width: 20,
                    height: 20,
                  }} />
                </TouchableOpacity>
                <TouchableOpacity style={{
                  display: 'flex',
                  flexDirection: 'row',
                  height: '100%',
                  textAlign: 'center',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}

                  onPress={() => {
                    handleSaveWitnessAsDraft({
                      witnessOneData: values.witnessOneInputData,
                      witnessTwoData: values.witnessTwoInputData
                    })
                  }}
                >
                  <Image source={save} style={{
                    width: 25,
                    height: 25,
                  }} />
                  <Text style={{
                    color: '#fff',
                    fontSize: 18,
                    marginLeft: 7,
                  }}>Save as Draft</Text>
                </TouchableOpacity>
              </View>
              <View style={{
                display: 'flex',
                flexDirection: 'row',
                marginTop: 20,
                alignItems: 'center',
              }}>
                <GradientText style={{
                  fontSize: 30,
                  fontWeight: 'bold',
                }}>
                  Self Express Will
                </GradientText>
                <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#FFBF35', '#F73B71']} style={{
                  paddingVertical: 5,
                  paddingHorizontal: 10,
                  borderRadius: 20,
                  marginLeft: 10,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  height:30,
                  marginTop:5

                }} >
                  <Text style={{
                    color: '#fff',

                  }}>MYSELF</Text>
                </LinearGradient>


              </View>
              <StepnIndicatorcmp current={2}/>
              <ScrollView>
                <View style={{
                  marginTop: 20,
                }}>
                  {/* Witness-1 form start*/}
                  <Text style={{
                    color: '#FFB721',
                    fontSize: 20,
                  }}>Witness-1</Text>
                  <View>
                    <Text style={{ ...styles.inputLabelStyle, color: (errors.witnessOneInputData?.full_name && touched.witnessOneInputData?.full_name) ? COLORS.pinkish_red : COLORS.light_green }}>Full name (legal) </Text>
                    <TextInput style={{ ...styles.textInputStyle, borderColor: (errors.witnessOneInputData?.full_name && touched.witnessOneInputData?.full_name) ? COLORS.pinkish_red : COLORS.light_green,color:'white' }}
                      onChangeText={handleChange('witnessOneInputData.full_name')}
                      onBlur={handleBlur('witnessOneInputData.full_name')}
                      value={values.witnessOneInputData.full_name}
                    />
                    {
                      errors.witnessOneInputData?.full_name && touched.witnessOneInputData?.full_name && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.full_name}</Text>
                    }
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '40%' }}>
                      <Text style={{ ...styles.inputLabelStyle, color: (errors.witnessOneInputData?.gender && touched.witnessOneInputData?.gender) ? COLORS.pinkish_red : COLORS.light_green }}>Gender </Text>
                     
                      <SelectDropdown
                data={['Male', 'Female', 'Others']}
                buttonStyle={{ backgroundColor: 'transparent', width: 150, borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2 }}
                onSelect={(selectedItem, index) => {
                  SetWit1gender(selectedItem)
                }}
                defaultValue={draftWitnessData?.witness1?.gender}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Select--"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={{color: '#FFFFFF',
                textAlign: 'left',
                marginLeft: 0,
                fontSize: 16,}}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
                      {
                        errors.witnessOneInputData?.gender && touched.witnessOneInputData?.gender && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData.gender}</Text>
                      }
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={{ ...styles.inputLabelStyle, color: (errors.witnessOneInputData?.religion && errors.witnessOneInputData?.religion) ? COLORS.pinkish_red : COLORS.light_green }}>Religion </Text>
                    
                      <SelectDropdown
                data={['Hindu', 'Muslim', 'Sikh', 'Christians', 'Jains', 'Others']}
                buttonStyle={{ backgroundColor: 'transparent', width: 150, borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2 }}
                onSelect={(selectedItem, index) => {
                  SetWit1rel(selectedItem)
                }}
                defaultValue={values?.witnessOneInputData?.religion}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Select--"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={{
                  color: '#FFFFFF',
                  textAlign: 'left',
                  marginLeft: 0,
                  fontSize: 16,
                }}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
                      {
                        errors.witnessOneInputData?.religion && touched.witnessOneInputData?.religion && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.religion}</Text>
                      }
                    </View>
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '45%' }}>
                      <Text style={styles.inputLabelStyle}>Nationality </Text>
                      <TextInput style={{...styles.textInputStyle,color:'white'}}
                        placeholder='Indian'
                        value='Indian'
                        editable={false}
                      />
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessOneInputData?.adhar_card && touched.witnessOneInputData?.adhar_card) ? COLORS.pinkish_red : COLORS.light_green
                      }}>Aadhar no. </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessOneInputData?.adhar_card && touched.witnessOneInputData?.adhar_card) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        value={values.witnessOneInputData.adhar_card}
                        onChangeText={handleChange('witnessOneInputData.adhar_card')}
                        onBlur={handleBlur('witnessOneInputData.adhar_card')}
                        keyboardType='numeric'
                      />
                      {
                        errors.witnessOneInputData?.adhar_card && touched.witnessOneInputData?.adhar_card && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.adhar_card}</Text>
                      }
                    </View>
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessOneInputData?.age && touched.witnessOneInputData?.age) ? COLORS.pinkish_red : COLORS.light_green
                      }}>Age </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessOneInputData?.age && touched.witnessOneInputData?.age) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        value={values.witnessOneInputData.age}
                        onChangeText={handleChange('witnessOneInputData.age')}
                        onBlur={handleBlur('witnessOneInputData.age')}
                        keyboardType='numeric'
                      />
                      {
                        errors.witnessOneInputData?.age && touched.witnessOneInputData?.age && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.age}</Text>
                      }
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={styles.inputLabelStyle}>Relation </Text>
                      <Dropdown
                        style={{
                          paddingTop: 0,
                          height: 50,
                          borderColor: '#0CFEBC',
                          borderBottomWidth: 1,
                        }}
                        placeholderStyle={{
                          fontSize: 16,
                          color: '#fff',
                        }}

                        itemTextStyle={{
                          fontSize: 16,
                          color: 'black',
                        }}
                        containerStyle={{
                          color: '#000',
                         
                         
                        }}
                        selectedTextStyle={{
                          color: '#fff',
                          fontSize: 16,
                        }}
                      
                        data={relations}
                        
                        value={witnessOneRelation}
                        maxHeight={300}
                        labelField="label"
                        valueField="value"
                        searchPlaceholder='Search'
                        onChange={(value) => {
                          setWitnessOneRelation(value)
                        }}
                      />
                    </View>
                  </View>
                  <View>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessOneInputData?.mobile_no && touched.witnessOneInputData?.mobile_no) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Witness Mobile no. </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessOneInputData?.mobile_no && touched.witnessOneInputData?.mobile_no) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      value={values.witnessOneInputData.mobile_no}
                      onChangeText={handleChange('witnessOneInputData.mobile_no')}
                      onBlur={handleBlur('witnessOneInputData.mobile_no')}
                      keyboardType='numeric'
                    />
                    {
                      errors.witnessOneInputData?.mobile_no && touched.witnessOneInputData?.mobile_no && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.mobile_no}</Text>
                    }
                  </View>
                  <View style={{ marginTop: 10 }}>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessOneInputData?.addressLineOne && touched.witnessOneInputData?.addressLineOne) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Address line 1 </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessOneInputData?.addressLineOne && touched.witnessOneInputData?.addressLineOne) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      value={values.witnessOneInputData.addressLineOne}
                      onChangeText={handleChange('witnessOneInputData.addressLineOne')}
                      onBlur={handleBlur('witnessOneInputData.addressLineOne')}
                    />
                    {
                      errors.witnessOneInputData?.addressLineOne && touched.witnessOneInputData?.addressLineOne && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.addressLineOne}</Text>
                    }
                  </View>
                  <View style={{ marginTop: 10 }}>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessOneInputData?.addressLineTwo && touched.witnessOneInputData?.addressLineTwo) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Address line 2 </Text>
                    <TextInput
                      style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessOneInputData?.addressLineTwo && touched.witnessOneInputData?.addressLineTwo) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                      value={values.witnessOneInputData.addressLineTwo}
                      onChangeText={handleChange('witnessOneInputData.addressLineTwo')}
                      onBlur={handleBlur('witnessOneInputData.addressLineTwo')}
                    />
                    {
                      errors.witnessOneInputData?.addressLineTwo && touched.witnessOneInputData?.addressLineTwo && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.addressLineTwo}</Text>
                    }
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessOneInputData?.city && touched.witnessOneInputData?.city) ? COLORS.pinkish_red : COLORS.light_green
                      }}>City </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessOneInputData?.city && touched.witnessOneInputData?.city) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        value={values.witnessOneInputData.city}
                        onChangeText={handleChange('witnessOneInputData.city')}
                        onBlur={handleBlur('witnessOneInputData.city')}
                      />
                      {
                        errors.witnessOneInputData?.city && touched.witnessOneInputData?.city && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.city}</Text>
                      }
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessOneInputData?.state && touched.witnessOneInputData?.state) ? COLORS.pinkish_red : COLORS.light_green
                      }}>State </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessOneInputData?.state && touched.witnessOneInputData?.state) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        value={values.witnessOneInputData.state}
                        onChangeText={handleChange('witnessOneInputData.state')}
                        onBlur={handleBlur('witnessOneInputData.state')}
                      />
                      {
                        errors.witnessOneInputData?.state && touched.witnessOneInputData?.state && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.state}</Text>
                      }
                    </View>
                  </View>
                  <View style={{
                    marginTop: 10,
                  }}>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessOneInputData?.email && touched.witnessOneInputData?.email) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Email </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessOneInputData?.email && touched.witnessOneInputData?.email) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      value={values.witnessOneInputData.email}
                      onChangeText={handleChange('witnessOneInputData.email')}
                      onBlur={handleBlur('witnessOneInputData.email')}
                    />
                    {
                      errors.witnessOneInputData?.email && touched.witnessOneInputData?.email && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessOneInputData?.email}</Text>
                    }
                  </View>
                </View>
                <View style={{
                  marginTop: 40,
                }}>
                  {/* Witness-2 */}
                  <Text style={{
                    color: '#FFB721',
                    fontSize: 20,
                  }}>Witness-2</Text>
                  <View>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessTwoInputData?.full_name && touched.witnessTwoInputData?.full_name) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Full name (legal) </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessTwoInputData?.full_name && touched.witnessTwoInputData?.full_name) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      value={values.witnessTwoInputData.full_name}
                      onChangeText={handleChange('witnessTwoInputData.full_name')}
                      onBlur={handleBlur('witnessTwoInputData.full_name')}
                    />
                    {
                      errors.witnessTwoInputData?.full_name && touched.witnessTwoInputData?.full_name && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.full_name}</Text>
                    }
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessTwoInputData?.gender && touched.witnessTwoInputData?.gender) ? COLORS.pinkish_red : COLORS.light_green
                      }}>Gender </Text>
                    <SelectDropdown
                data={['Male', 'Female', 'Others']}
                buttonStyle={{ backgroundColor: 'transparent', width: 150, borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2 }}
                onSelect={(selectedItem, index) => {
                  SetWit2gender(selectedItem)
                }}
                defaultValue={draftWitnessData?.witness2?.gender}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Select--"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={{color: '#FFFFFF',
                textAlign: 'left',
                marginLeft: 0,
                fontSize: 16,}}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
                      {
                        errors.witnessTwoInputData?.gender && touched.witnessTwoInputData?.gender && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.gender}</Text>
                      }
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessTwoInputData?.religion && touched.witnessTwoInputData?.religion) ? COLORS.pinkish_red : COLORS.light_green
                      }}>Religion </Text>
                     <SelectDropdown
                data={['Hindu', 'Muslim', 'Sikh', 'Christians', 'Jains', 'Others']}
                buttonStyle={{ backgroundColor: 'transparent', width: 150, borderBottomColor: COLORS.light_green_new, borderBottomWidth: 2 }}
                onSelect={(selectedItem, index) => {
                  SetWit2rel(selectedItem)
                }}
                defaultValue={values?.witnessTwoInputData?.religion}
                rowStyle={{ backgroundColor: 'black' }}
                defaultButtonText="Select--"
                dropdownIconPosition="left"
                rowTextStyle={{ color: '#FFFFFF' }}
                buttonTextStyle={{
                  color: '#FFFFFF',
                  textAlign: 'left',
                  marginLeft: 0,
                  fontSize: 16,
                }}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item
                }}
              />
                      {
                        errors.witnessTwoInputData?.religion && touched.witnessTwoInputData?.religion && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.religion}</Text>
                      }
                    </View>
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '45%' }}>
                      <Text style={styles.inputLabelStyle}>
                        Nationality </Text>
                      <TextInput style={{...styles.textInputStyle,color:'white'}}
                        placeholder='Indian'
                        value='Indian'
                        editable={false}
                      />
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessTwoInputData?.adhar_card && touched.witnessTwoInputData?.adhar_card) ? COLORS.pinkish_red : COLORS.light_green
                      }}>Aadhar no. </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessTwoInputData?.adhar_card && touched.witnessTwoInputData?.adhar_card) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        keyboardType='numeric'
                        value={values.witnessTwoInputData.adhar_card}
                        onChangeText={handleChange('witnessTwoInputData.adhar_card')}
                        onBlur={handleBlur('witnessTwoInputData.adhar_card')}
                      />
                      {
                        errors.witnessTwoInputData?.adhar_card && touched.witnessTwoInputData?.adhar_card && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.adhar_card}</Text>
                      }
                    </View>
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessTwoInputData?.age && touched.witnessTwoInputData?.age) ? COLORS.pinkish_red : COLORS.light_green
                      }}>Age </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessTwoInputData?.age && touched.witnessTwoInputData?.age) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        value={values.witnessTwoInputData.age}
                        onChangeText={handleChange('witnessTwoInputData.age')}
                        onBlur={handleBlur('witnessTwoInputData.age')}
                        keyboardType='numeric'
                      />
                      {
                        errors.witnessTwoInputData?.age && touched.witnessTwoInputData?.age && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.age}</Text>
                      }
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={styles.inputLabelStyle}>Relation </Text>
                      <Dropdown
                        style={{
                          paddingTop: 0,
                          height: 50,
                          borderColor: '#0CFEBC',
                          borderBottomWidth: 1,
                        }}
                        placeholderStyle={{
                          fontSize: 16,
                          color: '#fff',
                        }}

                        itemTextStyle={{
                          fontSize: 16,
                          color: 'black',
                        }}
                        
                        selectedTextStyle={{
                          color: '#fff',
                          fontSize: 16,
                        }}
                       
                        data={relations}
                        
                        value={witnessTwoRelation}
                        maxHeight={300}
                        labelField="label"
                        valueField="value"
                        searchPlaceholder='Search'
                        onChange={(value) => {
                          setWitnessTwoRelation(value)
                        }}
                      />
                    </View>
                  </View>
                  <View>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessTwoInputData?.mobile_no && touched.witnessTwoInputData?.mobile_no) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Witness Mobile no. </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessTwoInputData?.mobile_no && touched.witnessTwoInputData?.mobile_no) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      keyboardType='numeric'
                      value={values.witnessTwoInputData.mobile_no}
                      onChangeText={handleChange('witnessTwoInputData.mobile_no')}
                      onBlur={handleBlur('witnessTwoInputData.mobile_no')}
                    />
                    {
                      errors.witnessTwoInputData?.mobile_no && touched.witnessTwoInputData?.mobile_no && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.mobile_no}</Text>
                    }
                  </View>
                  <View style={{ marginTop: 10 }}>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessTwoInputData?.addressLineOne && touched.witnessTwoInputData?.addressLineOne) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Address line 1 </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessTwoInputData?.addressLineOne && touched.witnessTwoInputData?.addressLineOne) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      value={values.witnessTwoInputData.addressLineOne}
                      onChangeText={handleChange('witnessTwoInputData.addressLineOne')}
                      onBlur={handleBlur('witnessTwoInputData.addressLineOne')}
                    />
                    {
                      errors.witnessTwoInputData?.addressLineOne && touched.witnessTwoInputData?.addressLineOne && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.addressLineOne}</Text>
                    }
                  </View>
                  <View style={{ marginTop: 10 }}>
                    <Text style={{
                      ...styles.inputLabelStyle,
                      color: (errors.witnessTwoInputData?.addressLineTwo && touched.witnessTwoInputData?.addressLineTwo) ? COLORS.pinkish_red : COLORS.light_green
                    }}>Address line 2 </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessTwoInputData?.addressLineTwo && touched.witnessTwoInputData?.addressLineTwo) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      value={values.witnessTwoInputData.addressLineTwo}
                      onChangeText={handleChange('witnessTwoInputData.addressLineTwo')}
                      onBlur={handleBlur('witnessTwoInputData.addressLineTwo')}
                    />
                    {
                      errors.witnessTwoInputData?.addressLineTwo && touched.witnessTwoInputData?.addressLineTwo && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.addressLineTwo}</Text>
                    }
                  </View>
                  <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginTop: 10,
                  }}>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessTwoInputData?.city && touched.witnessTwoInputData?.city) ? COLORS.pinkish_red : COLORS.light_green
                      }}>City </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessTwoInputData?.city && touched.witnessTwoInputData?.city) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        value={values.witnessTwoInputData.city}
                        onChangeText={handleChange('witnessTwoInputData.city')}
                        onBlur={handleBlur('witnessTwoInputData.city')}
                      />

                      {
                        errors.witnessTwoInputData?.city && touched.witnessTwoInputData?.city && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.city}</Text>
                      }
                    </View>
                    <View style={{ width: '40%' }}>
                      <Text style={{
                        ...styles.inputLabelStyle,
                        color: (errors.witnessTwoInputData?.state && touched.witnessTwoInputData?.state) ? COLORS.pinkish_red : COLORS.light_green
                      }}>State </Text>
                      <TextInput style={{
                        ...styles.textInputStyle,
                        borderColor: (errors.witnessTwoInputData?.state && touched.witnessTwoInputData?.state) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                      }}
                        value={values.witnessTwoInputData.state}
                        onChangeText={handleChange('witnessTwoInputData.state')}
                        onBlur={handleBlur('witnessTwoInputData.state')}
                      />
                      {
                        errors.witnessTwoInputData?.state && touched.witnessTwoInputData?.state && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.state}</Text>
                      }
                    </View>
                  </View>
                  <View style={{
                    marginTop: 10,
                  }}>
                    <Text style={
                      {
                        ...styles.inputLabelStyle,
                        color: (errors.witnessTwoInputData?.email && touched.witnessTwoInputData?.email) ? COLORS.pinkish_red : COLORS.light_green
                      }
                    }>Email </Text>
                    <TextInput style={{
                      ...styles.textInputStyle,
                      borderColor: (errors.witnessTwoInputData?.email && touched.witnessTwoInputData?.email) ? COLORS.pinkish_red : COLORS.light_green,color:'white'
                    }}
                      value={values.witnessTwoInputData.email}
                      onChangeText={handleChange('witnessTwoInputData.email')}
                      onBlur={handleBlur('witnessTwoInputData.email')}
                    />
                    {
                      errors.witnessTwoInputData?.email && touched.witnessTwoInputData?.email && <Text style={{ color: COLORS.pinkish_red }}>{errors.witnessTwoInputData?.email}</Text>
                    }
                  </View>
                </View>
              </ScrollView>
            </View>
            </SafeAreaView>
          </ImageBackground>
        </KeyboardAvoidingView>}
    </Formik>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  text: {
    color: '#fff',
    fontSize: 30,
    fontWeight: 'bold',
  },

  inputLabelStyle: {
    color: COLORS.light_green,
    fontSize: 18,
    marginTop: 10,
  },

  textInputStyle: {
    borderStyle: 'solid',
    borderColor: '#0CFEBC',
    borderBottomWidth: 1,
    padding: 0,
  }
});

export default WitnessAndGuardians