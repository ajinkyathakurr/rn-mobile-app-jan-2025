import React, { useEffect, useState } from 'react'
import { View, Text, ImageBackground, Image, TextInput, TouchableOpacity, StyleSheet } from 'react-native'
import NextStepsButton from './../../components/NextStepsButton'
import LinearGradient from 'react-native-linear-gradient'
import Spinner from 'react-native-loading-spinner-overlay/lib'
    import bg from './../../../assets/bg.png'
import save from './../../../assets/save.png'
import back from './../../../assets/back.png'
import { getWithAuthCall, postWithAuthCall } from '../../../api/ApiServices'
import arrow_forward from './../../../assets/arrow_forward.png'
import ApiConfig from '../../../api/ApiConfig'
import { showMessage } from 'react-native-flash-message'
import GradientText from '../GradientText'
import { COLORS } from '../colors'
import { SafeAreaView } from 'react-native-safe-area-context'

const SpecialDirectives = ({ navigation, route }) => {
    const [speechText, setSpeechText] = useState('')
    const [prefetchDataNeeded, setPrefetchDataNeeded] = useState(true)
    const [loading, setLoading] = useState(false)

    useEffect(() => {
        if (route.params && prefetchDataNeeded) {
            setLoading(true)
            getWithAuthCall(ApiConfig.ADD_SPEECH+"?express_will_id="+route.params.id).then(response => {
                console.log(response)
                setLoading(false)
                if (response.status) {
                    setSpeechText(response.speech_data.express_speech)
                }
                setPrefetchDataNeeded(false)
            }).catch(error => {
                console.log("Error:" + error)
            })
        }
    }, [prefetchDataNeeded])


    const handleSpeechSaveDraft = () => {
        setLoading(true)
        console.log("Speech Text:" + speechText)
        const requestBody = {
            express_speech: speechText,
            express_will_id: route.params.id,
            draft: "speech"
        }
        postWithAuthCall(ApiConfig.ADD_SPEECH_DRAFT, requestBody).then(response => {
            console.log(response)
            setLoading(false)
            const messageType = response.status ? "success" : "danger"
            showMessage({
                message: response.message,
                type: messageType,
            });
        }).catch(error => {
            console.log("Error:" + error)
        })
    }

    const handleSaveSpeech = () => {
        setLoading(true)
        const requestBody = {
            express_speech: speechText,
            express_will_id: route.params.id,
        }
        postWithAuthCall(ApiConfig.ADD_SPEECH, requestBody).then(response => {
            console.log(response)
            setLoading(false)
            const messageType = response.status ? "success" : "danger"
            showMessage({
                message: response.message,
                type: messageType,
            });
            navigation.navigate('ExpressWillPreview',{id:route.params.id})
        }).catch(error => {
            console.log("Error:" + error)
        })
    }
    return (
       
            <ImageBackground source={bg} style={{
                flex: 1,
            }}>
                 <SafeAreaView style={{
            flex: 1,
        }}>
                <Spinner visible={loading} color={COLORS.light_green}/>
                {/*Next Steps button*/}
                <NextStepsButton handleButtonPress={handleSaveSpeech} active={true}/>

                <View style={{
                    flex: 1,
                    padding: 15,
                }}>
                    {/* Header */}
                    <View style={{
                        display: 'flex',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                    }}>
                        <TouchableOpacity style={{
                            borderStyle: 'solid',
                            borderColor: '#0CFEBC',
                            backgroundColor: "rgba(5, 160, 129, 0.20)",
                            borderWidth: 1,
                            borderRadius: 25,
                            padding: 10
                        }}
                            onPress={() => {
                                navigation.navigate('Executor',{id:route.params.id})
                            }}
                        >
                            <Image source={back} style={{
                                width: 20,
                                height: 20,
                            }} />
                        </TouchableOpacity>
                        <TouchableOpacity style={{
                            display: 'flex',
                            flexDirection: 'row',
                            height: '100%',
                            textAlign: 'center',
                            alignItems: 'center',
                            justifyContent: 'center',
                        }}
                            onPress={()=>handleSpeechSaveDraft()}
                        >
                            <Image source={save} style={{
                                width: 25,
                                height: 25,
                            }} />
                            <Text style={{
                                color: COLORS.white,
                                fontSize: 18,
                                marginLeft: 7,
                            }}>Save as Draft</Text>
                        </TouchableOpacity>
                    </View>
                    <View style={{
                        marginTop: 20,
                        display: 'flex',
                        flexDirection: 'row',
                    }}>
                        <GradientText style={{
                            fontSize: 30,
                            fontWeight: 'bold',
                        }}>
                            Self Express Will
                        </GradientText>
                        <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#FFBF35', '#F73B71']} style={styles.linearGradientStyleMyselfBadge} >
                            <Text style={{
                                color: COLORS.white,

                            }}>MYSELF</Text>
                        </LinearGradient>

                    </View>
                    <TextInput
                        multiline={true}
                        numberOfLines={20}
                        style={styles.speechTextInput}
                        placeholder="Type here"
                        autoFocus={true}
                        onChangeText={(text) => setSpeechText(text)}
                        value={speechText}

                    ></TextInput>
                    <Text style={{
                        textAlign: 'center',
                        marginTop: 20,
                        color:'white'
                    }}>
                        Special message or note will be added in your legal will, you can preview in next step.
                    </Text>
                </View>
                </SafeAreaView>
            </ImageBackground>
        
    )
}


const styles = StyleSheet.create({
    linearGradientStyleMyselfBadge: {
        paddingVertical: 5,
        paddingHorizontal: 10,
        borderRadius: 20,
        marginLeft: 10,
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height:30,
        marginTop:5
    },

    speechTextInput: {
        borderRadius: 10,
        marginTop: 20,
        padding: 10,
        textAlignVertical: 'top',
        backgroundColor: "#05A0817C",
        color: '#fff',
        paddingHorizontal: 15,
        paddingVertical: 15,
        fontSize: 16,
    }
})

export default SpecialDirectives