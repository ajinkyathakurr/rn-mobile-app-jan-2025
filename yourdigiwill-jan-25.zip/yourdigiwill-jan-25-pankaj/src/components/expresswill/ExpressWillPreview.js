import {
  StyleSheet,
  Text,
  View,
  ImageBackground,
  PermissionsAndroid,
  Image,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
} from "react-native";
import React from "react";
import Entypo from "react-native-vector-icons/Entypo";
import LinearGradient from "react-native-linear-gradient";
import { LinearGradientText } from "react-native-linear-gradient-text";
import { COLORS } from "../colors";
import { useEffect, useContext, useState } from "react";
import ApiConfig from "../../../api/ApiConfig";
import {
  simpleGetCallWithErrorResponse,
  postWithAuthCall,
} from "../../../api/ApiServices";
import GradientText from "../GradientText";
import bg from "./../../../assets/bg.png";
import save from "./../../../assets/save.png";
import back from "./../../../assets/back.png";
import { AppContext } from "../../../user/AppContext";
import PDFView from "react-native-view-pdf";
import { showMessage } from "react-native-flash-message";
import Spinner from 'react-native-loading-spinner-overlay/lib'
export default function ExpressWillPreview({ navigation, route }) {
  const { token } = useContext(AppContext);
  const [pdfuri, seTpdfuri] = useState(null);
  const { id } = route.params;
  useEffect(() => {
    //may be used for future use... if url for draft is cached
    if (route.params.url) {
      seTpdfuri(route.params.url);
    } else {
      postWithAuthCall(ApiConfig.EXPRESS_WILL_PDF, {
        express_will_id: id,
        token: token,
      }).then((data) => {
        seTpdfuri(data.express_will.express_will_doc_draft);
        console.log(pdfuri);
      }).catch((err)=>{
        console.log(err)
        showMessage({"message":"Error occured while previewing pdf",type:"danger"})
        seTpdfuri("No url")
        navigation.goBack()

      })
    }
  }, []);
  const handlePayment = () => {
    console.log(route.params.id)
    postWithAuthCall(ApiConfig.START_PAYMENT, {
      express_will_id: route.params.id,
    }).then((res) => {
      console.log(res)
      if (res.status) {
        navigation.navigate("Payment", { id: route.params.id, data: res });
      }
      if(!res.status)
      {
        if(res.messgae=='Already Paid for this ExpressWill')
        {
          navigation.navigate('Esign',{id:route.params.id,url:pdfuri})
        }
        else {
          showMessage({
            message: "Error while creating your order",
            type: "danger",
          });
        }
      }
      
    }).catch((err)=>{
      console.log(err)
      showMessage({
        message: "Error while creating your order please retry again",
        type: "danger",
      });
      navigation.navigate('SpecialDirectives',{id:route.params.id})
    })
    
  };
  const resources = {
    url: pdfuri,
  };
  const resourceType = "url";
  return (
    
      <ImageBackground
        source={bg}
        style={{
          flex: 1,
        }}
      ><SafeAreaView style={{flex:1}}>
        <View
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            padding: 15,
          }}
        >
          <TouchableOpacity
            style={{
              borderStyle: "solid",
              borderColor: "#0CFEBC",
              backgroundColor: "rgba(5, 160, 129, 0.20)",
              borderWidth: 1,
              borderRadius: 25,
              padding: 10,
            }}
            onPress={() => {
              navigation.navigate("SpecialDirectives", { id: id });
            }}
          >
            <Image
              source={back}
              style={{
                width: 20,
                height: 20,
              }}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              display: "flex",
              flexDirection: "row",
              height: "100%",
              textAlign: "center",
              alignItems: "center",
              justifyContent: "center",
            }}
            onPress={() => {
              navigation.navigate("Home");
            }}
          >
            <Image
              source={save}
              style={{
                width: 25,
                height: 25,
              }}
            />
            <Text
              style={{
                color: COLORS.white,
                fontSize: 18,
                marginLeft: 7,
              }}
            >
              Save as Draft
            </Text>
          </TouchableOpacity>
        </View>
        <View style={{ marginLeft: 15, display: "flex", flexDirection: "row" }}>
          <GradientText
            style={{
              fontSize: 30,
              fontWeight: "bold",
            }}
          >
            Self Express Will
          </GradientText>
          <LinearGradient
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            colors={["#FFBF35", "#F73B71"]}
            style={{
              paddingVertical: 5,
              paddingHorizontal: 10,
              borderRadius: 20,
              marginLeft: 10,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: 30,
              marginTop: 5,
            }}
          >
            <Text
              style={{
                color: "#fff",
              }}
            >
              MYSELF
            </Text>
          </LinearGradient>
        </View>
        <Text style={{ color: "white", marginLeft: 15 }}>Sample Preview</Text>
        <View
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            width: "100%",
          }}
        >
          {(pdfuri) ? (
            <View
              style={{
                height: "85%",
                width: "95%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: 15,
                overflow: "hidden",
              }}
            >
              <PDFView
                fadeInDuration={250.0}
                style={{ height: "100%", width: "100%" }}
                resource={resources[resourceType]}
                resourceType={resourceType}
                onLoad={() => console.log(`PDF rendered from ${resourceType}`)}
                onError={(error) => console.log("Cannot render PDF", error)}
              />
            </View>
          ):<Spinner visible={!pdfuri} color={COLORS.light_green}/>}
        </View>

        <TouchableOpacity
          onPress={handlePayment}
          style={{
            right: 0,
            bottom: 10,
            position: "absolute",
            marginBottom: 20,
            marginRight: 20,
          }}
        >
          <LinearGradient
            colors={["#0CFEBC", "#05A081"]}
            style={{
              borderRadius: 47,
              borderWidth: 2,
              borderColor: COLORS.light_green_new,
              flexDirection: "row",
              alignItems: "center",
            }}
          >
            <Text
              style={{
                fontSize: 17,
                marginTop: 15,
                marginBottom: 15,
                marginRight: 10,
                marginLeft: 10,
                color: "white",
              }}
            >
              Pay Now
            </Text>
            <Entypo
              name="arrow-with-circle-right"
              size={22}
              color={"white"}
              style={{ marginRight: 15 }}
            ></Entypo>
          </LinearGradient>
        </TouchableOpacity>
     
    </SafeAreaView>
    </ImageBackground>
  );
}
