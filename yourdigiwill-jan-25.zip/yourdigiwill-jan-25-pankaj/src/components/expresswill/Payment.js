import { View, Text, StyleSheet, TouchableHighlight, ImageBackground, KeyboardAvoidingView } from 'react-native'
import React from 'react'
import RazorpayCheckout from 'react-native-razorpay';
import { TextInput, TouchableOpacity } from 'react-native-gesture-handler';
import { postWithAuthCall, PostCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import bg from './../../../assets/bg.png'
import NextStepsButton from './../../components/NextStepsButton'
import { useState } from 'react';
import { COLORS } from '../colors';
import { showMessage } from 'react-native-flash-message';
import { useEffect } from 'react';
import icon from "../../../assets/dwicon.png"
import { SafeAreaView } from 'react-native-safe-area-context';
export default function Payment({navigation, route }) {
  const orderDetails=route.params.data;
  const handleCouponSubmit = () => {

    PostCallWithErrorResponse(ApiConfig.START_PAYMENT,
      { express_will_id: route.params.id, coupon_code: promo }
    )
      .then((result) => {
        console.log(result)
        if (result.json) {
          if (result.json.message == "Invalid Coupon") {
            showMessage({
              message: "Invalid Cupon Code",
              type: "danger",
            });
          }
          else if (result.json.coupon_discount_value != 0) {
            showMessage({
              message: "promo code applied successfully",
              type: "success",
            });
          }


        }
      })
      .catch((error) => {
        console.log("api response", error);

      });

  }


  const handlePayment = async () => {
    
    postWithAuthCall(ApiConfig.START_PAYMENT, {
      express_will_id: route.params.id,
    }).then((res)=>{
      var options = {
        description: orderDetails.plan_name,
        image: icon,
        currency: 'INR',
        key: 'rzp_live_vMJUowugyM5w9E',
        amount: res.price_after_promotion * 100,
        name: 'DigiWill',
        order_id: res.payment.id, //Replace this with an order_id created using Orders API.
        prefill: {
          email: '',
          contact: '',
          name: ''
        },
        theme: { color: '#53a20e' }
      }
      RazorpayCheckout.open(options).then(async (data) => {
        // handle success
        console.log(data)
        const res = await postWithAuthCall(ApiConfig.PAYMENT_SUCCESS_EXPRESSWILL, { 
          "razorpay_order_id":data.razorpay_order_id,
          "razorpay_payment_id":data.razorpay_payment_id,
          "razorpay_signature":data.razorpay_signature
         })
        console.log(res)
        showMessage({message:res.message,type:"success"});
        navigation.navigate("Esign",{id:route.params.id})
      }).catch((error) => {
        console.log(error)
        alert(`Error: Payment might have been canceled`);
        navigation.navigate("ExpressWillPreview",{id:route.params.id})      
      });
    })
    
  }
  const [promo, seTpromo] = useState('')

  useEffect(() => {    
  }, [])
  return (


    <ImageBackground style={{ flex: 1 }} source={bg}>
      <SafeAreaView style={{flex:1}}>
      {(orderDetails.status===false)?<View><Text style={{color:"#FFFFFF"}}>Already paid for this Express Will</Text></View>:
      <View style={styles.mainContainer}>
        <View><Text style={styles.textStyle}>Express Will                           ₹ {orderDetails.plan_price}</Text></View>
        <View><Text style={styles.textStyle}>Referral Bonus                       ₹ {orderDetails.referral_bonus}</Text></View>
        <View><Text style={styles.textStyle}>Promotion Applied                 ₹ {orderDetails.discount}</Text></View>
        <View><Text style={styles.textStyle}>Cupon Discount                      ₹ {orderDetails.coupon_discount}</Text></View>
        <View><Text style={styles.textStyle}>Total                                         ₹ {orderDetails.price_after_promotion}</Text></View>
        <View style={{ height: 80, borderRadius: 10, borderColor: "#05A081", borderStyle: 'dashed', borderWidth: 3, display: 'flex', flexDirection: 'row', backgroundColor: "#05A08133", alignItems: 'center' }}>
          <TextInput style={styles.textInput}
            placeholder="Enter Promo Code"
            placeholderTextColor="#05A081"
            value={promo}
            onChangeText={seTpromo}
          />
          <TouchableOpacity
            onPress={() => handleCouponSubmit()}
            style={{
              alignItems: 'center',
              justifyContent: 'center',

              marginTop: 10,
              marginBottom: 20
            }}

          >
            <Text style={{ fontSize: 20, color: COLORS.light_green_new, marginLeft: 20, marginRight: 20, marginTop: 10, fontWeight: 'bold' }}>Apply

            </Text>
          </TouchableOpacity>
        </View>
        <View style={{ width: 300, borderWidth: 1, borderColor: "#05A081", marginTop: 30 }}></View>
        <View><Text style={{ ...styles.textStyle, marginTop: 20 }}>GST                                         ₹ {orderDetails.order.gst_amount}</Text></View>
        <View style={{ width: 300, borderWidth: 1, borderColor: "#05A081", marginTop: 20 }}></View>
        <View><Text style={{ ...styles.textStyle, marginTop: 20, fontWeight: '800', color: "#05A081" }}>Payable Amount                   ₹ {orderDetails.order.order_amount}</Text></View>
      </View>}
      <Text style={{ flex: 1, color: "#ffffff", alignSelf: "center", textAlign: 'center', lineHeight: 30 }}>By placing your order you agree to DigiWill's Privacy Policy Usage Service Terms & Conditions</Text>
      
      <NextStepsButton handleButtonPress={handlePayment} text={"Pay Now"} active={true} />
      </SafeAreaView>
    </ImageBackground>





  )

}

const styles = StyleSheet.create({
  textStyle: {
    color: "#ffffff",
    fontSize: 20,
    margin: 5
  },
  mainContainer: {
    width: "90%",

    padding: 20,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    borderWidth: 2,
    borderColor: "#ffffff",
    margin: 20,
    borderRadius: 15,
    backgroundColor: "#252836"

  },

  textInput: {
    width: 200,


    fontSize: 16,
    color: '#ffffff',
    height: 40,
    marginTop: 10,

    height: 70,
    paddingLeft: 10,
    fontSize: 20,



  },
});