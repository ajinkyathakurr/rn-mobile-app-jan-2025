import React,{useState} from 'react'
import { View, Text, TouchableOpacity, ImageBackground, Image, SafeAreaView } from 'react-native'
import bg from "./../../../assets/bg.png"
import back from './../../../assets/back1.png'
import ExpressWillTile from '../ExpressWillTile'
import Spinner from 'react-native-loading-spinner-overlay/lib';
import GradientText from '../GradientText'
import { COLORS } from '../colors'
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';
import {
    Menu,
    MenuOptions,
    MenuOption,
    MenuTrigger,
} from 'react-native-popup-menu';

const ListingScreen = ({ navigation, route }) => {
    const [loading, setLoading] = useState(false)
    return (
        <ImageBackground source={bg} style={{
            flex: 1,
        }}>
        <SafeAreaView style={{flex:1}}>
       
            <Spinner visible={loading} color={COLORS.light_green}/>
            <View style={{
                flex: 1,
                padding: 20,
            }}>
                <View style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                }}>
                    <TouchableOpacity style={{
                        borderStyle: 'solid',
                        borderColor: '#0CFEBC',
                        backgroundColor: "rgba(5, 160, 129, 0.20)",
                        borderWidth: 1,
                        borderRadius: 25,
                        padding: 10
                    }}
                        onPress={() => {
                            navigation.goBack()
                        }}
                    >
                        <Image source={back} style={{
                            width: 20,
                            height: 20,
                        }} />
                    </TouchableOpacity>
                    <Menu >
                        <MenuTrigger>
                            <MaterialIcons
                                name="more-vert"
                                size={30}
                                color={COLORS.light_green}
                                style={{
                                    marginLeft: 10
                                }}
                            />
                        </MenuTrigger>
                        <MenuOptions style={{
                            padding: 10,
                        }}>
                            <MenuOption onSelect={() => alert(`Save`)}>
                                <Text style={{ color: COLORS.dark_grey ,fontSize:15}}>Others will</Text>
                            </MenuOption>
                        </MenuOptions>
                    </Menu>
                </View>
                <View style={{
                    marginTop: 20
                }}>
                        <GradientText style={{
                            fontSize: 35,
                            fontWeight: 'bold',
                        }}>For Myself</GradientText>
                        {
                            route.params.data.map((item, index) => {
                                return (
                                    <ExpressWillTile key={index} data={item} setLoading={setLoading}/>
                                )
                            })
                        }
                </View>
            </View>
            </SafeAreaView>
        </ImageBackground>

    )
}

export default ListingScreen