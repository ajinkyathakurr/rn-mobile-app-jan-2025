import {
  StyleSheet,
  Text,
  TextInput,
  View,
  Button,
  Image,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import Header from "./Header";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../api/ApiServices";
import ApiConfig from "../../api/ApiConfig";
import { AppContext } from "../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import AntDesign from "react-native-vector-icons/AntDesign";
import CheckBox from "react-native-check-box";
import LinearGradient from "react-native-linear-gradient";
import { COLORS } from "./colors";
import Entypo from "react-native-vector-icons/Entypo";
import Modal from "react-native-modal";
import SelectDropdown from "react-native-select-dropdown";
import DatePicker from "react-native-date-picker";
import { showMessage, hideMessage } from "react-native-flash-message";

import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from "react-native-popup-menu";

import { sin } from "react-native/Libraries/Animated/Easing";
import { Color } from "../../GlobalStyles";

const frequencies = ["once", "monthly", "quarterly", "halfyearly", "yearly"];

export default function MyReminders({ navigation }) {
  const [will, setReminderAssets] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [selectedassets, setselectedAssets] = useState([]);
  const [isModalVisible, setModalVisible] = useState(false);
  const [isOn, setisOn] = useState(false);
  const [historydate, setHistorydate] = useState(new Date());
  const [data, setData] = useState({
    id: "",
    date: "",
    reminder_type: "",
    message: "",
    origin: "",

    //  date:date &&  date.date ?new Date(date.date):null
    // date:date  && date ? new Date(date):null
  });

  function compareDate(str1) {
    // str1 format should be dd/mm/yyyy. Separator can be anything e.g. / or -. It wont effect
    var dt1 = parseInt(str1.substring(9, 11));
    var mon1 = parseInt(str1.substring(5, 7));
    var yr1 = parseInt(str1.substring(0, 4));
    var date1 = new Date(yr1, mon1 - 1, dt1);
    return date1;
  }
  const { token } = useContext(AppContext);
  // const MenuFunction = (id)=>{}
  // const [isOn,setisOn]=useState(false)
  const toggleModal = () => {
    setModalVisible(!isModalVisible);
  };

  const hideModal = () => {
    setModalVisible(false);
    setisOn(false);
    showMessage({
      message: "Reminder Cancelled successfully",
      type: "default",
    });
  };

  const showModal = () => {
    setModalVisible(false);
    setLoading(true);
    const formbody = new FormData();

    formbody.append("reminder_id", data.id);

    formbody.append("reminder_type", data.reminder_type);
    formbody.append("reminder_message", data.message);
    formbody.append("date", data.date);
    //  formbody.append('date',data.date.getFullYear()+ "-"+(data.date.getMonth()+1)+"-"+data.date.getDate())
    console.log(formbody);
    if (data.origin == "delete") {
      console.log("its delete");
      method = "delete";
    } else {
      method = "put";
    }
    fetch(ApiConfig.Update_ALL_REMINDERS, {
      method: method,
      headers: {
        Authorization: `Token ${token}`,
      },
      body: formbody,
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (json) {
        console.log(json);
        setLoading(false);
        showMessage({
          message: json.message,

          type: "success",
        });
        console.log(json.message);
        navigation.navigate("Home");
      })
      .catch(function (error) {
        setTimeout(() => {
          setLoading(false);
          showMessage({
            message: "Reminder Updated SuccessFully",
            type: "success",
          });
          navigation.navigate("Home");
        }, 1000);

        console.log(
          "There has been a problem with your fetch operation: " + error.message
        );

        throw error;
      });
  };
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  }, []);

  const setReminder = (id, reminder_type, message, date) => {
    console.log(id);

    var date = compareDate(date);
    console.log("dateeeeee", date);
    setModalVisible(true);
    setData({
      ...data,
      id: id,
      reminder_type: reminder_type,
      message: message,
      date: date,
      origin: "put",
    });
    //setisOn(true)
  };
  const deletereminder = (id) => {
    console.log("iddddddddddddddd", id);
    console.log("hii");
    setData({ ...data, id: id, origin: "delete" });
  };

  const GET_ALL_REMINDERS = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_REMINDERS, {
      token: token,
    })
      .then((data) => {
        if (data) {
          console.log(data.json.Reminders_Data);
          setReminderAssets(data.json.Reminders_Data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  useEffect(() => {
    GET_ALL_REMINDERS();
  }, []);

  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
          marginRight: 5,
          marginLeft: 10,
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Settings")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>

        <Text style={{ fontSize: 22, color:COLORS.light_green }}>My Reminders</Text>
        <View></View>
      </View>

      <ScrollView>
        {will && will.length != 0 ? (
          will.map((single) => {
            return (
              <View>
                <Text
                  style={{
                    fontSize: 22,
                    color: "#FFFFFF",
                    marginTop: 20,
                    marginRight: 10,
                    marginLeft: 20,
                  }}
                >
                  {single.will.category.category_name}
                </Text>

                <View
                  style={{
                    backgroundColor: COLORS.light_grey,
                    // height: 70,
                    width: Dimensions.get("screen").width - 32,

                    marginLeft: 16,
                    marginRight: 16,
                    marginTop: 10,
                    borderRadius: 10,
                    borderWidth: 1,
                    borderColor: COLORS.light_green,
                  }}
                >
                  <View
                    style={{
                      marginLeft: 16,
                      marginRight: 16,
                      marginTop: 15,
                      borderRadius: 10,

                      alignItems: "center",
                      justifyContent: "space-between",
                      flex: 1,
                      flexDirection: "row",
                    }}
                  >
                    <Text
                      style={{
                       
                        fontSize: 17,
                        color: "#00FFA3",
                        paddingRight: 30,
                        marginRight: 100,
                      }}
                    >
                      {single.will.title}
                    </Text>
                    <View>
                      <Menu>
                        <MenuTrigger>
                          <Entypo name="dots-three-vertical" size={22} />
                        </MenuTrigger>

                        <MenuOptions
                          style={{
                            backgroundColor: COLORS.black,
                            borderRadius: 1,
                            borderWidth: 1.5,
                          }}
                        >
                          <MenuOption
                            onSelect={() =>
                              setReminder(
                                single.id,
                                single.reminder_type,
                                single.message,
                                single.date
                              )
                            }
                            color="#989898"
                          >
                            {console.log(single.date)}
                            <Text
                              style={{
                                color: "white",
                                fontSize: 16,
                                marginLeft: 7,
                              }}
                            >
                              Edit
                            </Text>
                          </MenuOption>
                          <MenuOption
                            onSelect={() => deletereminder(single.id)}
                            color="#989898"
                          >
                            {console.log(single.date)}
                            <Text
                              style={{
                                color: "white",
                                fontSize: 16,
                                marginLeft: 7,
                              }}
                            >
                              Delete
                            </Text>
                          </MenuOption>
                        </MenuOptions>
                      </Menu>
                    </View>
                  </View>
                  <View
                    style={{
                      flex: 1,
                      height: 1,
                      backgroundColor: "white",
                      marginLeft: 5,
                      marginRight: 5,
                      marginTop: 10,
                    }}
                  />

                  <View
                    style={{
                      flexDirection: "column",
                      marginBottom: 5,
                      marginLeft: 5,
                      marginTop: 5,
                    }}
                  >
                    {single.date ? (
                      <Text style={{ color: "#8A8D9F" }}>{single.date}</Text>
                    ) : (
                      ""
                    )}
                    {single.reminder_type ? (
                      <Text style={{ color: "#8A8D9F" }}>
                        {single.reminder_type}
                      </Text>
                    ) : (
                      ""
                    )}
                    {single.message ? (
                      <Text style={{ color: "#8A8D9F" }}>{single.message}</Text>
                    ) : (
                      ""
                    )}
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <Spinner color={COLORS.light_green} visible={loading} />
        )}

        {will && will.length == 0 ? (
          <View
            style={{
              alignItems: "center",
              justifyContent: "center",
              alignItems: "center",
              justifyContent: "center",
              marginTop: 150,
            }}
          >
            <TouchableOpacity
              onPress={() => navigation.navigate("Home")}
              style={{
                height: 200,
                width: 200,
                color: "#FFFFFF",
                marginRight: 10,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 10,
              }}
            >
              <Image
                style={{ height: 250, width: 250, alignItems: "center" }}
                source={{ uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/image.png" }}
              />
            </TouchableOpacity>
            <Text
              style={{
                fontSize: 21,
                color: "#FFFFFF",
                marginTop: 5,
                paddingBottom: 60,
              }}
            >
              No Reminders Found
            </Text>

            <View>
              <Text
                style={{
                  fontSize: 12,
                  color: "#0CFEBC",
                  marginTop: 5,
                  paddingBottom: 10,
                  fontWeight: "500",
                }}
              >
                Start Adding your Assets or Liabilities and set your Reminders
              </Text>
            </View>

            <TouchableOpacity
              onPress={() => navigation.navigate("Home")}
              style={{
                width: 320,
                height: 45,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: "#FFBB00",
                borderRadius: 25,
                marginTop: 10,
              }}
            >
              <Text
                style={{ fontSize: 16, color: "black", fontWeight: "bold" }}
              >
                Start Now
              </Text>
            </TouchableOpacity>
          </View>
        ) : (
          ""
        )}
      </ScrollView>

      <Modal
        onRequestClose={() => {
          setModalVisible(false);
        }}
        transparent={true}
        isVisible={isModalVisible}
        style={{ justifyContent: "center" }}
        deviceHeight={600}
      >
        <ScrollView
          style={{
            flex: 1,
            backgroundColor: COLORS.light_grey,
            borderRadius: 10,
            marginTop: 100,
            marginBottom: 150,
            
          }}
        >
          <View style={{ alignItems: "center" }}>
            <Text
              style={{
                color: COLORS.light_green,
                marginTop: 20,
                fontSize: 22,
              }}
            >
              When to Remind ?
            </Text>
          </View>
          <SelectDropdown
            data={frequencies}
            buttonStyle={styles.frequencyDownstyle}
            onSelect={(selectedItem, index) => {
              setData({ ...this, reminder_type: selectedItem });
            }}
            rowStyle={{ backgroundColor: "black" }}
            defaultButtonText="Select Frequency"
            dropdownIconPosition="left"
            defaultValue={data.reminder_type}
            rowTextStyle={{ color: "#FFFFFF" }}
            buttonTextStyle={styles.frequencybuttonTextStyle}
            buttonTextAfterSelection={(selectedItem, index) => {
              // text represented after item is sError: undefined is not a function

              // if data array is an array of objects then return selectedItem.property to render after item is selected
              return selectedItem;
            }}
            rowTextForSelection={(item, index) => {
              // text represented for each item in dropdown
              // if data array is an array of objects then return item.property to represent item in dropdown
              return item;
            }}
          />

          <DatePicker
            modal
            mode="date"
            open={open}
            date={data.date}
            onConfirm={(date) => {
              setOpen(false);
              setData({ ...data, date: date });
            }}
            onCancel={() => {
              setOpen(false);
            }}
          />
          <TouchableOpacity
            style={styles.frequencyinput}
            onPress={() => setOpen(true)}
          >
            <Text
              style={{
                fontSize: 16,
                color: COLORS.light_green,
                marginTop: 10,
                paddingBottom: 10,
              }}
            >  {(data.date)?(data.date.getFullYear() +
              "-" +
              (data.date.getMonth() + 1) +
              "-" +
              data.date.getDate()):""}
            </Text>
          </TouchableOpacity>

          <TextInput
            style={{
              backgroundColor: "black",
              width: 295,
              height: 100,
              marginBottom: 10,
              marginTop: 10,
              borderRadius: 10,
              paddingLeft: 10,
              fontSize: 16,
              marginLeft: 10,
              color: COLORS.light_green,
            }}
            value={data.message}
            placeholder="Note here (if any)"
            keyboardType="text"
            onChangeText={(text) => setData({ ...data, message: text })}
            placeholderTextColor={COLORS.light_green}
          />

          <View style={{ flexDirection: "row" }}>
            <TouchableOpacity
              onPress={() => hideModal()}
              style={{
                width: 100,
                height: 40,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: COLORS.light_yello,
                borderRadius: 25,
                bottom: 0,
                marginLeft: 32,
                marginRight: 32,
                marginTop: 40,
              }}
            >
              <Text style={{ fontSize: 16, color: "black" }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => showModal()}
              style={{
                width: 100,
                height: 40,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: "#0CFEBC",
                borderRadius: 25,
                bottom: 0,
                marginLeft: 16,
                marginRight: 16,
                marginTop: 40,
              }}
            >
              <Text style={{ fontSize: 16, color: "black" }}>Save</Text>
            </TouchableOpacity>
          </View>

          {/* <Button title="Hide modal" onPress={toggleModal} /> */}
        </ScrollView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  rndImage: {
    width: 50.75,
    height: 50.75,
  },

  frequencyDownstyle: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    marginLeft: 10,
  },
  frequencybuttonTextStyle: {
    color: COLORS.light_green,
    padding: 12,
    textAlign: "left",
    marginLeft: 0,
    fontSize: 16,
  },
  frequencyinput: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    marginLeft: 10,
  },
});
