import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Dimensions,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaViewBase,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { useState, useRef, useEffect, useContext } from "react";
import Entypo from "react-native-vector-icons/Entypo";
import AntDesign from "react-native-vector-icons/AntDesign";
import RBSheet from "react-native-raw-bottom-sheet";
import {
  PostCallWithErrorResponse,
  simpleGetCallWithErrorResponse,
} from "../../api/ApiServices";
import ApiConfig from "../../api/ApiConfig";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { AppContext } from "../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay";
import { useIsFocused } from "@react-navigation/native";
import RazorpayCheckout from "react-native-razorpay";
import LinearGradient from "react-native-linear-gradient";
import { showMessage, hideMessage } from "react-native-flash-message";
import { COLORS } from "./colors";

export default function Header({ text, navigation, route }) {
  const { token } = useContext(AppContext);
  const bottomsheet = useRef();
  const [MyClientID, setMyClientID] = useState("");
  const isFocused = useIsFocused();

  useEffect(() => {
    AsyncStorage.getItem("token").then((myClientID) => {
      setMyClientID(myClientID);
    });
  }, []);

  const [data, setData] = useState({
    name: "",
    relationship: "",
    age: "",
    email: "",
    phone: "",
    address: "",
    gender: "",
  });

  const [nominees, setNominees] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    getAllAssets();
  }, [isFocused]);
  const getAllAssets = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_NOMINEES, { token: token })
      .then((data) => {
        if (data) {
          console.log(data);
          setNominees(data.json.data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const handleSubmit = () => {
    if (data.name == "") {
      bottomsheet.current.close();
      showMessage({
        message: "Please enter name",
        type: "danger",
      });
      return;
    }
    if (data.relationship == "") {
      bottomsheet.current.close();
      showMessage({
        message: "Please enter relationship",
        type: "danger",
      });
      return;
    }
    if (data.age == "") {
      bottomsheet.current.close();
      showMessage({
        message: "Please enter age",
        type: "danger",
      });
      return;
    }
    if (data.email == "" || !data.email.includes("@")) {
      bottomsheet.current.close();
      showMessage({
        message: "Please enter the valid email id",
        type: "danger",
      });
      return;
    }
    if (data.phone.length < 10) {
      bottomsheet.current.close();

      showMessage({
        message: "Please enter atleast 10 digit number",
        type: "danger",
      });
      return;
    }
    if (data.address == "") {
      bottomsheet.current.close();
      showMessage({
        message: "Please enter address",
        type: "danger",
      });
      return;
    }
    PostCallWithErrorResponse(ApiConfig.DIGIWILL_ADD_NOMINEE, {
      ...data,
      mobile_no: data.phone,
      token: token,
    })
      .then((result) => {
        console.log(result);
        if (result.json.result) {
          setData({
            name: "",
            relationship: "",
            age: "",
            email: "",
            phone: "",
            address: "",
            gender: "",
          });
          getAllAssets();
          bottomsheet.current.close();
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  return (
    
      <SafeAreaView style={{flex:1,backgroundColor:COLORS.grey}}>
        {loading ? (
          <Spinner color={COLORS.light_green} visible={loading} />
        ) : (
          <View style={{flex:1}}>
            <View
              style={{
                backgroundColor:COLORS.light_grey_body,
                height: 50,
                alignItems: "center",
                justifyContent: "space-between",
                flexDirection: "row",
              }}
            >
              <TouchableOpacity
                onPress={() => navigation.navigate("Home")}
              >
                <AntDesign
                  name="left"
                  size={30}
                  color="#FFFFFF"
                  style={{ marginRight: 2 }}
                ></AntDesign>
              </TouchableOpacity>
              <Text style={{ fontSize: 22, color: "#FFFFFF" }}>{text}</Text>
              <View></View>
            </View>
            <ScrollView style={styles.body}>
              {nominees && nominees.length != 0 ? (
                nominees.map((single) => {
                  return (
                    <TouchableOpacity
                      key={single.id}
                      onPress={() =>
                        navigation.navigate("NomineeDetails", {
                          name: single.name,
                          email: single.email,
                          mobile_no: single.mobile_no,
                          age: single.age,
                          relationship: single.relationship,
                          address: single.address,
                          gender: single.gender,
                          incomplete_data: single.incomplete_data,
                          kyc_completed: single.kyc_completed,
                          image: single.image,
                          id: single.id,
                        })
                      }
                      style={{
                        width: Dimensions.get("screen").width - 30,
                        backgroundColor: COLORS.light_grey_body,
                        height: 70,
                        marginLeft: 16,
                        marginRight: 16,
                        marginTop: 10,
                        borderRadius: 10,
                        alignItems: "center",
                        justifyContent: "space-between",
                        flex: 1,
                        flexDirection: "row",
                        padding: 5,
                      }}
                    >
                      <View
                        style={{ flexDirection: "row", alignItems: "center" }}
                      >
                        <View
                          style={{
                            width: 40,
                            height: 40,
                            borderColor: COLORS.light_green,
                            borderWidth: 1,
                            borderRadius: 50,
                            alignItems: "center",
                            marginLeft: 10,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 22,
                              color: "#FFFFFF",
                              marginTop:5
                            }}
                          >
                            {single.name[0]}
                          </Text>
                        </View>
                        <Text
                          style={{
                            fontSize: 17,
                            color: "#FFFFFF",
                            marginLeft: 10,
                          }}
                        >
                          {single.name}
                        </Text>
                      </View>
                      {single.kyc_completed ? (
                        <View
                          style={{
                            flexDirection: "row",
                            alignItems: "center",
                            marginRight: 5,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 15,
                              color: COLORS.light_green,
                              margin: 3,
                              marginLeft: 5,
                              marginRight: 5,
                            }}
                          >
                            Verified
                          </Text>
                          <AntDesign
                            name="checkcircle"
                            color={COLORS.light_green}
                            size={15}
                          ></AntDesign>
                        </View>
                      ) : !single.kyc_completed ? (
                        <View
                          style={{
                            borderRadius: 20,
                            borderWidth: 1,
                            borderColor: "#FFBB00",
                            marginRight: 10,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 15,
                              color: "#FFBB00",
                              margin: 3,
                              marginLeft: 5,
                              marginRight: 5,
                            }}
                          >
                            Unverified
                          </Text>
                        </View>
                      ) : (
                        <View
                          style={{
                            borderRadius: 20,
                            borderWidth: 1,
                            borderColor: "red",
                            marginRight: 10,
                            backgroundColor: "rgba(247, 59, 59, 0.4)",
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 15,
                              color: "#FFFFFF",
                              margin: 3,
                              marginLeft: 5,
                              marginRight: 5,
                            }}
                          >
                            Incomplete
                          </Text>
                        </View>
                      )}
                    </TouchableOpacity>
                  );
                })
              ) : (
                <View
                  style={{
                    alignItems: "center",
                    justifyContent: "center",
                    marginTop: 100,
                  }}
                >
                  <TouchableOpacity
                    onPress={() => navigation.navigate("AddNominee")}
                    style={{
                      width: 91,
                      height: 91,
                      borderRadius: 50,
                      color: "#FFFFFF",
                      marginRight: 21,
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: 10,
                      backgroundColor: "#252836",
                    }}
                  >
                    <Image
                      style={styles.rndImage}
                      source={require("../../assets/sharenow.png")}
                    />
                  </TouchableOpacity>
                  <Text
                    style={{
                      fontSize: 21,
                      color: "#FFFFFF",
                      marginTop: 5,
                      paddingBottom: 10,
                    }}
                  >
                    Add Nominee Now!
                  </Text>
                </View>
              )}
            </ScrollView>

            <TouchableOpacity
              onPress={() => navigation.navigate("AddNominee")}
              style={{
                alignItems: "center",
                justifyContent: "center",
                width: 60,                
                height: 60,
                position:'absolute',
                bottom:50,
                right:40,
                color: "#FFFFFF",
                borderRadius: 50,
                backgroundColor: "#FFBF35",
              }}
            >
              <FontAwesome name="plus" size={24} color="black" />
            </TouchableOpacity>

            <View>
              <RBSheet
                ref={bottomsheet}
                height={400}
                openDuration={250}
                customStyles={{
                  container: {
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: "#252836",
                    borderRadius: 15,
                    height: "auto",
                  },
                }}
              >
                <ScrollView showsVerticalScrollIndicator={false}>
                  <TextInput
                    style={styles.input}
                    placeholder="Full Name"
                    value={data.name}
                    onChangeText={(text) => setData({ ...data, name: text })}
                    placeholderTextColor="#FFFFFF"
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Relationship"
                    value={data.relationship}
                    onChangeText={(text) =>
                      setData({ ...data, relationship: text })
                    }
                    placeholderTextColor="#FFFFFF"
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Age"
                    value={data.age}
                    onChangeText={(text) => setData({ ...data, age: text })}
                    placeholderTextColor="#FFFFFF"
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Email"
                    value={data.email}
                    onChangeText={(text) => setData({ ...data, email: text })}
                    placeholderTextColor="#FFFFFF"
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Mobile"
                    value={data.phone}
                    onChangeText={(text) => setData({ ...data, phone: text })}
                    placeholderTextColor="#FFFFFF"
                  />
                  <TextInput
                    style={styles.input}
                    placeholder="Address"
                    value={data.address}
                    onChangeText={(text) => setData({ ...data, address: text })}
                    placeholderTextColor="#FFFFFF"
                  />
                  <TouchableOpacity
                    onPress={() => handleSubmit()}
                    style={{
                      width: 295,
                      height: 50,
                      alignItems: "center",
                      justifyContent: "center",
                      backgroundColor: "#FFBF35",
                      borderRadius: 25,
                      marginTop: 10,
                      marginBottom: 20,
                    }}
                  >
                    <Text style={{ fontSize: 16, color: "#FFFFFF" }}>
                      Add Nominee
                    </Text>
                  </TouchableOpacity>
                </ScrollView>
              </RBSheet>
            </View>
          </View>
        )}
      </SafeAreaView>
    
  );
}
const styles = StyleSheet.create({
  header: {
    backgroundColor: "#252836",
    alignItems: "center",
    height: 70,
    marginTop: 20,
  },
  input: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  checkbox: {
    marginRight: 10,
    color: "#0CFEBC",
    borderColor: "#0CFEBC",
  },
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
