import {
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Button,
  Image,
  TouchableOpacity,
  TouchableHighlight,
  Dimensions,
  ActivityIndicator,
  KeyboardAvoidingView,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import SelectDropdown from "react-native-select-dropdown";
import { COLORS } from "../colors";
import Enctypo from "react-native-vector-icons/Entypo";
import { showMessage, hideMessage } from "react-native-flash-message";
import RBSheet from "react-native-raw-bottom-sheet";
const relations = [
  "Friend",
  "Father",  
  "Brother",  
  "Brother-in-Law",
  "Father-in-Law",   
  "Husband",
  "Son",
  "Sister",
  "Mother-in-Law",
  "Sister-in-Law",
  "Daughter",  
  "Wife",
  "Mother",
];
import ImagePicker from "react-native-image-crop-picker";
import ApiConfig from "../../../api/ApiConfig";
import { AppContext } from "../../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { PostCallWithErrorResponse, postWithAuthCall } from "../../../api/ApiServices";
import OtpTimer from "otp-timer";

export default function AddNominee({ navigation }) {
  const bottomsheet = useRef();
  const { token } = useContext(AppContext);
  const [filepath, setfilePath] = useState("");
  const [loading, setLoading] = useState(false);
  const [clientId, setclientid] = useState("");
  const [verifying, setverifying] = useState(false);
  const [panverifying, setpanverifying] = useState(false);
  const [aadharverifying, setaadharverifying] = useState(false);
  const [Successor, seTsuccessor] = useState(true);
  const handleImagePick = () => {
    ImagePicker.openPicker({
      width: 300,
      height: 400,
      compressImageQuality: 0.5,

      cropping: true,
    }).then((image) => {
      setfilePath(image.path);
      console.log(image);
    });
  };
  //Surepasss Fuctions Start

  const sendOtp = () => {
    if (data.aadhar_no.length != 12) {
      showMessage({
        message: "Please enter valid aadhar number",
        type: "danger",
      });
      return;
    }
    setverifying(true);

    console.log({ aadhar_number: data.aadhar_no, token: token });
    PostCallWithErrorResponse(ApiConfig.GENERATE_AADHAR_OTP, {
      aadhar_number: data.aadhar_no,
      token: token,
    })
      .then((result) => {
        console.log(result);
        if (result.json.status) {
          showMessage({
            message: result.json.message,
            type: "success",
          });
          setclientid(result.json.client_id);
        } else {
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
        setverifying(false);
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const VerifyPan = () => {
    setpanverifying(true);
    PostCallWithErrorResponse(ApiConfig.VERIFY_PAN, {
      pan_id: data.pan_no,
      name: data.name,
      mobile_no: "+91" + data.mobile_no,
      origin: "nominee",
      token: token,
    })
      .then((result) => {
        setpanverifying(false);
        console.log(result);
        if (result.json.status) {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "success",
          });
        } else {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const SubmitAdharOtp = () => {
    setaadharverifying(true);

    console.log({ aadhar_number: data.aadhar_no, token: token });
    PostCallWithErrorResponse(ApiConfig.SUBMIT_AADHAR_OTP, {
      otp: data.otp,
      client_id: clientId,
      name: data.name,
      email: data.email,
      mobile_no: "+91" + data.mobile_no,
      origin: "nominee",
      token: token,
    })
      .then((result) => {
        console.log(result);
        setaadharverifying(false);
        if (result.json.status) {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "success",
          });
        } else {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const handleAddNominee = async () => {
    setLoading(true);
    const formbody = new FormData();
    if (filepath) {
      formbody.append("image", {
        uri: filepath,
        name: "photo.jpeg",
        filename: "imageName.png",
        type: "image/jpeg",
      });
    }

    formbody.append("name", data.name);
    formbody.append("email", data.email);
    formbody.append("mobile_no", "+91" + data.mobile_no);
    formbody.append("relationship", data.relationship);
    formbody.append("address", data.address);
    formbody.append("age", data.age);
    (relations.indexOf(data.relationship)>6)?formbody.append("gender", "male") : formbody.append("gender", "female");
    (Successor)?formbody.append("status","primary"):formbody.append("status","secondary")
    console.log(formbody)
    fetch(ApiConfig.DIGIWILL_ADD_NOMINEE, {
      method: "post",
      headers: {
        Authorization: `Token ${token}`,
      },
      body: formbody,
    })
      .then(function (response) {
        setLoading(false);
        navigation.navigate("Nominee");
        return response.json();
        
      })
      .then(function (json) {
        setLoading(false);
        navigation.navigate("Nominee");
      })
      .catch(function (error) {
        console.log(
          "There has been a problem with your fetch operation: " + error.message
        );

        setLoading(false);

        navigation.navigate("Nominee");
        throw error;
      }).catch(()=>{
        showMessage({message:"There was an error adding the nominee , please enter valid details",type:"danger"})
      })
  };

  const [data, setData] = useState({
    name: "",
    email: "",
    mobile_no: "",
    age: 0,
    gender: "",
    address: "",
    relationship: "",
    aadhar_no: "",
    pan_no: "",
    otp: "",
    status:"",
  });
  const [doc, setDoc] = useState("Aadhaar Card");

  const handleDocChange = (selectedItem) => {
    setDoc(selectedItem);
  };

  const handleKycValidation = () => {
    if (data.name == "") {
      showMessage({
        message: "Please enter the Name",
        type: "danger",
      });
      return;
    }
    if (data.relationship == "") {
      showMessage({
        message: "Please enter the Relationship",
        type: "danger",
      });
      return;
    }
    if (data.email == "" && !data.email.includes("@")) {
      showMessage({
        message: "Please enter the valid Email",
        type: "danger",
      });
      return;
    }
    if (data.mobile_no == "" && data.mobile_no.length < 10) {
      showMessage({
        message: "Please enter the valid Mobile no",
        type: "danger",
      });
      return;
    }
    if (data.age == "") {
      showMessage({
        message: "Please enter the Age",
        type: "danger",
      });
      return;
    }

    if (data.address == "") {
      showMessage({
        message: "Please enter the Address",
        type: "danger",
      });
      return;
    }

    bottomsheet.current.open();
  };

  return (
    <KeyboardAvoidingView style={{flex:1}} behavior="padding">
    <SafeAreaView
      style={{
        backgroundColor: "#252836",
        height: "100%",
        alignItems: "center",
      }}
    >
      {loading ? <Spinner visible={loading} /> : <></>}
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Nominee")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontSize: 22, color: "#FFFFFF" }}>Add Nominee</Text>
        <View></View>
      </View>
      <SafeAreaView style={{ flex: 1 }}>
        <ScrollView
          style={styles.container}
          showsVerticalScrollIndicator={false}
        >
          <TouchableOpacity
            onPress={() => handleImagePick()}
            style={{
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row",
            }}
          >
            <Image
              source={{
                uri:
                  filepath != ""
                    ? filepath
                    : "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/avatar.png",
              }}
              style={{ borderRadius: 50, width: 83, height: 83 }}
            ></Image>

            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Group+26967.png",
              }}
              style={{
                marginTop: 44,
                marginLeft: -17,
                color: COLORS.light_green,
                height: 25,
                width: 25,
              }}
            ></Image>
          </TouchableOpacity>
          <TextInput
            style={styles.input2}
            value={data.name}
            placeholder="Name"
            onChangeText={(text) => setData({ ...data, name: text })}
            placeholderTextColor="#FFFFFF"
          />
          <Text style={{ color: COLORS.light_yello, fontSize: 13 }}>
            As per Adhar / PAN
          </Text>
          <SelectDropdown
            data={relations}
            buttonStyle={styles.dropDownstyle}
            onSelect={(selectedItem, index) => {
              setData({ ...data, relationship: selectedItem });
              console.log(selectedItem, index);
            }}
            rowStyle={{ backgroundColor: "black" }}
            defaultButtonText="Select Relationship"
            dropdownIconPosition="left"
            rowTextStyle={{ color: "#FFFFFF" }}
            buttonTextStyle={styles.buttonTextStyle}
            buttonTextAfterSelection={(selectedItem, index) => {
              return selectedItem;
            }}
            rowTextForSelection={(item, index) => {
              return item;
            }}
          />

          <TextInput
            style={styles.input}
            value={data.email}
            placeholder="Email"
            onChangeText={(text) => setData({ ...data, email: text })}
            placeholderTextColor="#FFFFFF"
            keyboardType="email-address"
          />
          <TextInput
            style={styles.input}
            value={data.age}
            placeholder="Age"
            onChangeText={(text) => setData({ ...data, age: text })}
            placeholderTextColor="#FFFFFF"
            keyboardType="numeric"
          />
          <TextInput
            style={styles.input}
            value={data.mobile_no}
            placeholder="Mobile No"
            onChangeText={(text) => setData({ ...data, mobile_no: text })}
            placeholderTextColor="#FFFFFF"
            keyboardType="phone-pad"
          />
          <TextInput
            style={styles.input}
            value={data.address}
            placeholder="Address"
            onChangeText={(text) => setData({ ...data, address: text })}
            placeholderTextColor="#FFFFFF"
          />
          <View style={{ padding: 10 }}>
            <Text style={{ color: "#FFF", fontSize: 20 }}>Successor</Text>
            <View
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "space-between",
                marginTop: 15,
              }}
            >
              <TouchableOpacity
                onPress={()=>seTsuccessor(()=>!Successor)}
                style={{
                  borderColor: COLORS.light_green_new,
                  borderWidth: 2,
                  borderStyle: "solid",
                  width: "40%",
                  height: 45,
                  borderRadius: 50,
                  justifyContent: "center",
                  backgroundColor:(Successor)?COLORS.light_green:COLORS.black
                }}
              >
                <Text
                  style={{ color:(Successor)?COLORS.black:"#FFF", textAlign: "center", fontSize: 18 }}
                >
                  Primary
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
              onPress={()=>seTsuccessor(()=>!Successor)}
                style={{
                  borderColor: COLORS.light_green_new,
                  borderWidth: 2,
                  borderStyle: "solid",
                  width: "40%",
                  height: 45,
                  borderRadius: 50,
                  justifyContent: "center",
                  backgroundColor:(!Successor)?COLORS.light_green:COLORS.black
                }}
              >
                <Text
                  style={{ color:(!Successor)?COLORS.black:"#FFF", textAlign: "center", fontSize: 18 }}
                >
                  Secondary
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity
            onPress={() => {
              handleKycValidation();
            }}
            style={{
              marginBottom: 20,
              backgroundColor: "black",
              justifyContent: "center",
              alignItems: "center",
              height: 70,
              flexDirection: "row",
              borderColor: COLORS.light_yello,
              borderWidth: 1,
              borderRadius: 10,
              marginTop: 15,
            }}
          >
            <View>
              <Image
                source={{ uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector+(14).png" }}
                style={{ height: 30, width: 27, margin: 10 }}
              ></Image>
            </View>
            <View>
              <Text style={{ color: "#FFFFFF" }}>KYC Required</Text>
              <Text style={{ color: "#FFFFFF" }}>
                Tap here to update KYC for this nominee
              </Text>
            </View>
          </TouchableOpacity>
            
          <TouchableOpacity
            onPress={() => handleAddNominee()}
            style={{
              width: 320,
              height: 45,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: COLORS.light_yello,
              borderRadius: 25,
              marginTop: 10,
            }}
          >
            <Text style={{ fontSize: 16, color: "black" }}>
              Add Nominee
              <AntDesign
                name="doubleright"
                size={13}
                marginLeft={3}
                color="black"
              />
            </Text>
          </TouchableOpacity>
          
        </ScrollView>

        <RBSheet
          ref={bottomsheet}
          height={400}
          openDuration={250}
          customStyles={{
            container: {
              justifyContent: "center",
              alignItems: "center",
              backgroundColor: "#252836",
              borderRadius: 15,
              height: "auto",
            },
          }}
        >
          <ScrollView showsVerticalScrollIndicator={false}>
            <View>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Image
                  source={{
                    uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector+(14).png",
                  }}
                  style={{ height: 30, width: 27, margin: 10 }}
                ></Image>
                <Text style={{ color: COLORS.light_yello, fontSize: 22 }}>
                  Nominee KYC
                </Text>
              </View>
              <Text
                style={{
                  color: COLORS.light_yello,
                  fontSize: 12,
                  marginLeft: 8,
                }}
              >
                Select Document
              </Text>

              <SelectDropdown
                data={["Aadhaar Card", "Pan Card"]}
                defaultValue={doc}
                buttonStyle={styles.dropDownstyle}
                onSelect={(selectedItem, index) => {
                  handleDocChange(selectedItem);
                }}
                rowStyle={{ backgroundColor: "black" }}
                defaultButtonText="Select Document"
                dropdownIconPosition="left"
                rowTextStyle={{ color: "#FFFFFF" }}
                buttonTextStyle={styles.buttonTextStyle}
                buttonTextAfterSelection={(selectedItem, index) => {
                  return selectedItem;
                }}
                rowTextForSelection={(item, index) => {
                  return item;
                }}
              />

              {doc == "Aadhaar Card" ? (
                <View>
                  <Text
                    style={{
                      color: COLORS.light_yello,
                      fontSize: 12,
                      marginLeft: 8,
                    }}
                  >
                    Nominee's Aadhaar Card
                  </Text>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <TextInput
                      style={styles.input3}
                      value={data.aadhar_no}
                      placeholder="Aadhar No"
                      onChangeText={(text) =>
                        setData({ ...data, aadhar_no: text })
                      }
                      placeholderTextColor="#FFFFFF"
                    />
                    <TouchableOpacity onPress={() => sendOtp()}>
                      {verifying ? (
                        <ActivityIndicator
                          size="large"
                          color={COLORS.light_yello}
                          style={{ color: COLORS.light_yello, marginLeft: 20 }}
                        />
                      ) : (
                        <Text
                          style={{ color: COLORS.light_yello, marginLeft: 20 }}
                        >
                          Send Otp
                        </Text>
                      )}
                    </TouchableOpacity>
                  </View>
                  <Text
                    style={{
                      color: COLORS.light_yello,
                      fontSize: 12,
                      marginLeft: 8,
                    }}
                  >
                    Enter OTP
                  </Text>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                      marginBottom: 20,
                    }}
                  >
                    <TextInput
                      style={{ ...styles.input3, height: 50 }}
                      value={data.otp}
                      placeholder="Enter OTP"
                      onChangeText={(text) => setData({ ...data, otp: text })}
                      placeholderTextColor="#FFFFFF"
                    />
                    {aadharverifying ? (
                      <ActivityIndicator
                        size="large"
                        color={COLORS.light_yello}
                        style={{ color: COLORS.light_yello, marginLeft: 20 }}
                      />
                    ) : (
                      <TouchableOpacity onPress={() => SubmitAdharOtp()}>
                        <Text
                          style={{ color: COLORS.light_yello, marginLeft: 20 }}
                        >
                          Verify Otp
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              ) : (
                <View>
                  <Text
                    style={{
                      color: COLORS.light_yello,
                      fontSize: 12,
                      marginLeft: 8,
                    }}
                  >
                    Nominee's PAN Card
                  </Text>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <TextInput
                      style={styles.input3}
                      value={data.pan_no}
                      placeholder="PAN Number"
                      onChangeText={(text) =>
                        setData({ ...data, pan_no: text })
                      }
                      placeholderTextColor="#FFFFFF"
                    />
                    {panverifying ? (
                      <ActivityIndicator
                        size="large"
                        color={COLORS.light_yello}
                        style={{ color: COLORS.light_yello, marginLeft: 20 }}
                      />
                    ) : (
                      <TouchableOpacity onPress={() => VerifyPan()}>
                        <Text
                          style={{ color: COLORS.light_green, marginLeft: 20 }}
                        >
                          Verify
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              )}
            </View>
          </ScrollView>
        </RBSheet>
      </SafeAreaView>
    </SafeAreaView>
    </KeyboardAvoidingView>
  );
}
const styles = StyleSheet.create({
  header: {
    height: 100,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  input: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  input3: {
    backgroundColor: "black",
    width: 240,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  input2: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 5,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  buttonTextStyle: {
    color: "#FFFFFF",
    marginLeft: 0,
    fontSize: 16,
    textAlign: "left",
  },
  dropDownstyle: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    textAlign: "left",
  },
});
