import {
  StyleSheet,
  Text,
  TextInput,
  View,
  Button,
  Image,
  TouchableOpacity,
  TouchableHighlight,
  Dimensions,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

import { useState, useRef, useEffect, useContext } from "react";
import LinearGradient from "react-native-linear-gradient";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import SelectDropdown from "react-native-select-dropdown";
import { COLORS } from "../colors";
import { ScrollView } from "react-native-gesture-handler";
import Enctypo from "react-native-vector-icons/Entypo";
import { showMessage, hideMessage } from "react-native-flash-message";
import RBSheet from "react-native-raw-bottom-sheet";
import {
  DeleteCallWithErrorResponse,
  PostCallWithErrorResponse,
} from "../../../api/ApiServices";
import ApiConfig from "../../../api/ApiConfig";
import { AppContext } from "../../../user/AppContext";
import ReactNativeBiometrics, { BiometryTypes } from "react-native-biometrics";
const rnBiometrics = new ReactNativeBiometrics();
const relations = [
  "Father",
  "Mother",
  "Brother",
  "Sister",
  "Wife",
  "Brother-in-Law",
  "Father-in-Law",
  "Sister-in-Law",
  "Mother-in-Law",
  "Brother",
  "Sister",
  "Husband",
  "Son",
  "Daughter",
  "Friend",
  "Wife",
];
export default function NomineeDetails({ navigation, route }) {
  const [doc, setDoc] = useState("Aadhaar Card");
  const [filepath, setfilePath] = useState("");
  const { token } = useContext(AppContext);
  const {
    name,
    email,
    mobile_no,
    image,
    age,
    gender,
    address,
    incomplete_data,
    kyc_completed,
    id,
    city,
    state,
    relationship,
  } = route.params;
  const bottomsheet = useRef();
  const [data, setData] = useState({ aadhar_no: "", pan_no: "" });
  const [verifying, setverifying] = useState(false);
  const [panverifying, setpanverifying] = useState(false);
  const [aadharverifying, setaadharverifying] = useState(false);

  const handleKycValidation = () => {
    console.log("bottom sheet open ");
    bottomsheet.current.open();
  };

  //Surepasss Fuctions Start

  const sendOtp = () => {
    if (data.aadhar_no.length != 12) {
      showMessage({
        message: "Please enter valid aadhar number",
        type: "danger",
      });
      return;
    }
    setverifying(true);

    console.log({ aadhar_number: data.aadhar_no, token: token });
    PostCallWithErrorResponse(ApiConfig.GENERATE_AADHAR_OTP, {
      aadhar_number: data.aadhar_no,
      token: token,
    })
      .then((result) => {
        console.log(result);
        setaadharverifying(false);
        if (result.json.status) {
          showMessage({
            message: result.json.message,
            type: "success",
          });
          setclientid(result.json.client_id);
        } else {
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
        setverifying(false);
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const handleNomineeDelete = () => {
    rnBiometrics
      .simplePrompt({ promptMessage: "Confirm fingerprint" })
      .then((resultObject) => {
        const { success } = resultObject;

        if (success) {
          console.log("successful biometrics provided");
          console.log("successful biometrics provided");
          DeleteCallWithErrorResponse(ApiConfig.DIGIWILL_ADD_NOMINEE, {
            id: id,
            token: token,
          })
            .then((result) => {
              console.log(result);
              if (result.json.result) {
                showMessage({
                  message: "nominee Removed Successfully",
                  type: "success",
                });
                navigation.navigation("Nominee");
              }
            })
            .catch((error) => {
              console.log("api response", error);
            });
        } else {
          console.log("user cancelled biometric prompt");
        }
      })
      .catch(() => {
        console.log("biometrics failed");
        navigation.navigate("Pinverify", { nominee: "nominee", id: id });
      });
  };

  const VerifyPan = () => {
    if (data.pan_no.length != 10) {
      showMessage({
        message: "Please enter the valid pan no",
        type: "danger",
      });
      bottomsheet.current.close();
      return;
    }

    setpanverifying(true);
    PostCallWithErrorResponse(ApiConfig.VERIFY_PAN, {
      pan_id: data.pan_no,
      name: name,
      mobile_no: mobile_no,
      origin: "nominee",
      token: token,
      id: id,
    })
      .then((result) => {
        console.log(result);
        setpanverifying(false);
        if (result.json.status) {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "success",
          });
        } else {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const SubmitAdharOtp = () => {
    setaadharverifying(true);

    console.log({ aadhar_number: data.aadhar_no, token: token });
    PostCallWithErrorResponse(ApiConfig.SUBMIT_AADHAR_OTP, {
      otp: data.otp,
      client_id: clientId,
      name: data.name,
      email: data.email,
      mobile_no: data.mobile_no,
      origin: "nominee",
      token: token,
    })
      .then((result) => {
        setaadharverifying(false);
        console.log(result);
        if (result.json.status) {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "success",
          });
        } else {
          bottomsheet.current.close();
          showMessage({
            message: result.json.message,
            type: "danger",
          });
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  const handleDocChange = (selectedItem) => {
    setDoc(selectedItem);
  };

  //Surepass funtion end

  console.log("age===", age);
  return (
    <SafeAreaView style={{
      backgroundColor: "#252836",
      height: "100%",
      alignItems: "center",
    }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <TouchableOpacity onPress={() => navigation.navigate("Nominee")}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontSize: 22, color: "#FFFFFF" }}>Nominee</Text>
        <TouchableOpacity
          onPress={() =>
            navigation.navigate("EditNominee", {
              name: name,
              email: email,
              mobile_no: mobile_no,
              age: age,
              relationship: relationship,
              address: address,
              gender: gender,
              image: image,
              id: id,
              city: city,
              state: state,
            })
          }
        >
          <FontAwesome
            name="edit"
            size={30}
            color={COLORS.light_green}
            style={{ marginLeft: 30}}
          ></FontAwesome>
        </TouchableOpacity>
      </View>

      <View
        style={{
         
          alignItems: "center",
        }}
      >
        <View>
          <Image
            source={{
              uri: filepath
                ? filepath
                : image != null
                ? image
                : "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/avatar.png",
            }}
            style={{ borderRadius: 50, width: 83, height: 83,marginLeft:20 }}
          ></Image>
          <Text style={{ color: "#FFFFFF", textAlign: "center" }}>{name}</Text>
        </View>
        {incomplete_data ? (
          <View
            style={{
              backgroundColor: "red",
              borderColor: "red",
              borderWidth: 1,
              borderRadius: 10,
              height: 40,
              alignItems: "center",
              justifyContent: "center",
              width: "80%",
              marginTop: 20,
            }}
          >
            <Text style={{ color: "#FFFFFF", margin: 10 }}>
              Nominee Profile Incomplete
            </Text>
          </View>
        ) : !kyc_completed ? (
          <View
            style={{
              backgroundColor: "#FFBB00",
              borderColor: "#FFBB00",
              borderWidth: 1,
              borderRadius: 10,
              height: 40,
              alignItems: "center",
              justifyContent: "center",
              width: "80%",
              marginTop: 20,
            }}
          >
            <Text style={{ color: "#FFFFFF", margin: 10 }}>
              Nominee Profile Unverified
            </Text>
          </View>
        ) : (
          <View
            style={{
              backgroundColor: COLORS.light_green,
              borderColor: COLORS.light_green,
              borderWidth: 1,
              borderRadius: 10,
              height: 40,
              alignItems: "center",
              justifyContent: "center",
              width: "80%",
              marginTop: 20,
            }}
          >
            <Text style={{ color: "black", margin: 10 }}>
              Nominee Profile Verified
            </Text>
          </View>
        )}

        {!kyc_completed ? (
          <TouchableOpacity
            onPress={() => {
              handleKycValidation();
            }}
            style={{
              marginBottom: 20,
              backgroundColor: "black",
              justifyContent: "center",
              alignItems: "center",
              height: 70,
              flexDirection: "row",
              borderColor: COLORS.light_yello,
              borderWidth: 1,
              borderRadius: 10,
              marginTop: 15,
            }}
          >
            <View>
              <Image
                source={{ uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector+(14).png" }}
                style={{ height: 30, width: 27, margin: 10 }}
              ></Image>
            </View>
            <View>
              <Text style={{ color: "#FFFFFF" }}>KYC Required</Text>
              <Text style={{ color: "#FFFFFF", marginRight: 10 }}>
                Tap here to update KYC for this nominee
              </Text>
            </View>
          </TouchableOpacity>
        ) : (
          ""
        )}

        <TouchableOpacity
          onPress={() => handleNomineeDelete()}
          style={{
            marginBottom: 20,
            backgroundColor: "black",
            justifyContent: "center",
            alignItems: "center",
            height: 70,
            flexDirection: "row",
            borderColor: COLORS.light_pink,
            borderWidth: 1,
            borderRadius: 10,
            marginTop: 15,
          }}
        >
          <View>
            <FontAwesome
              name="trash-o"
              style={{ margin: 10 }}
              size={30}
              color={"#FFFFFF"}
            ></FontAwesome>
          </View>
          <View>
            <Text style={{ color: "#FFFFFF" }}>Delete Nominee</Text>
            <Text style={{ color: "#FFFFFF", marginRight: 10 }}>
              Tap here to delete this nominee details
            </Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          style={{
            marginBottom: 20,
            backgroundColor: "black",
            justifyContent: "center",
            alignItems: "center",
            height: 70,
            flexDirection: "row",
            borderColor: COLORS.light_pink,
            borderWidth: 1,
            borderRadius: 10,
            marginTop: 5,
          }}
        >
          <View>
            <FontAwesome
              name="exclamation-triangle"
              style={{ margin: 10 }}
              size={30}
              color={"#FFFFFF"}
            ></FontAwesome>
          </View>
          <View>
            <Text style={{ color: "#FFFFFF" }}>Report death of nominee</Text>
            <Text style={{ color: "#FFFFFF", marginRight: 10 }}>
              This feature will be launched soon......
            </Text>
          </View>
        </TouchableOpacity>

        <RBSheet
          ref={bottomsheet}
          height={400}
          openDuration={250}
          customStyles={{
            container: {
              justifyContent: "center",
              alignItems: "center",
              backgroundColor: "#252836",
              borderRadius: 15,
              height: "auto",
            },
          }}
        >
          <ScrollView showsVerticalScrollIndicator={false}>
            <View>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Image
                  source={{
                    uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector+(14).png",
                  }}
                  style={{ height: 30, width: 27, margin: 10 }}
                ></Image>
                <Text style={{ color: COLORS.light_yello, fontSize: 22 }}>
                  Nominee KYC
                </Text>
              </View>
              <Text
                style={{
                  color: COLORS.light_yello,
                  fontSize: 12,
                  marginLeft: 8,
                }}
              >
                Select Document
              </Text>

              <SelectDropdown
                data={["Aadhaar Card", "Pan Card"]}
                defaultValue={doc}
                buttonStyle={styles.dropDownstyle}
                onSelect={(selectedItem, index) => {
                  handleDocChange(selectedItem);
                }}
                // dropdownStyle={{backgroundColor:'black'}}
                // dropdownOverlayColor='black'
                // dropdownBackgroundColor="black"
                rowStyle={{ backgroundColor: "black" }}
                defaultButtonText="Select Document"
                dropdownIconPosition="left"
                rowTextStyle={{ color: "#FFFFFF" }}
                buttonTextStyle={styles.buttonTextStyle}
                buttonTextAfterSelection={(selectedItem, index) => {
                  // text represented after item is selected
                  // if data array is an array of objects then return selectedItem.property to render after item is selected
                  return selectedItem;
                }}
                rowTextForSelection={(item, index) => {
                  // text represented for each item in dropdown
                  // if data array is an array of objects then return item.property to represent item in dropdown
                  return item;
                }}
              />

              {doc == "Aadhaar Card" ? (
                <View>
                  <Text
                    style={{
                      color: COLORS.light_yello,
                      fontSize: 12,
                      marginLeft: 8,
                    }}
                  >
                    Nominee's Aadhaar Card
                  </Text>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <TextInput
                      style={styles.input3}
                      value={data.aadhar_no}
                      placeholder="Aadhar No"
                      onChangeText={(text) =>
                        setData({ ...data, aadhar_no: text })
                      }
                      placeholderTextColor="#FFFFFF"
                    />
                    <TouchableOpacity onPress={() => sendOtp()}>
                      {verifying ? (
                        <ActivityIndicator
                          size="large"
                          color={COLORS.light_yello}
                          style={{ color: COLORS.light_yello, marginLeft: 20 }}
                        />
                      ) : (
                        <Text
                          style={{ color: COLORS.light_yello, marginLeft: 20 }}
                        >
                          Send Otp
                        </Text>
                      )}
                    </TouchableOpacity>
                  </View>
                  <Text
                    style={{
                      color: COLORS.light_yello,
                      fontSize: 12,
                      marginLeft: 8,
                    }}
                  >
                    Enter OTP
                  </Text>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                      marginBottom: 20,
                    }}
                  >
                    <TextInput
                      style={{ ...styles.input3, height: 50 }}
                      value={data.otp}
                      placeholder="Enter OTP"
                      onChangeText={(text) => setData({ ...data, otp: text })}
                      placeholderTextColor="#FFFFFF"
                    />

                    {aadharverifying ? (
                      <ActivityIndicator
                        size="large"
                        color={COLORS.light_yello}
                        style={{ color: COLORS.light_yello, marginLeft: 20 }}
                      />
                    ) : (
                      <TouchableOpacity onPress={() => SubmitAdharOtp()}>
                        <Text
                          style={{ color: COLORS.light_yello, marginLeft: 20 }}
                        >
                          Verify Otp
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              ) : (
                <View>
                  <Text
                    style={{
                      color: COLORS.light_yello,
                      fontSize: 12,
                      marginLeft: 8,
                    }}
                  >
                    Nominee's PAN Card
                  </Text>

                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <TextInput
                      style={styles.input3}
                      value={data.pan_no}
                      placeholder="PAN Number"
                      onChangeText={(text) =>
                        setData({ ...data, pan_no: text })
                      }
                      placeholderTextColor="#FFFFFF"
                    />
                    {panverifying ? (
                      <ActivityIndicator
                        size="large"
                        color={COLORS.light_yello}
                        style={{ color: COLORS.light_yello, marginLeft: 20 }}
                      />
                    ) : (
                      <TouchableOpacity onPress={() => VerifyPan()}>
                        <Text
                          style={{ color: COLORS.light_green, marginLeft: 20 }}
                        >
                          Verify Otp
                        </Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              )}
            </View>
          </ScrollView>
        </RBSheet>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  header: {
    height: 100,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },

  input: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  input3: {
    backgroundColor: "black",
    width: 240,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  input2: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 5,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  buttonTextStyle: {
    color: "#FFFFFF",
    marginLeft: 0,
    fontSize: 16,
    textAlign: "left",
  },
  dropDownstyle: {
    backgroundColor: "black",
    width: 320,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    textAlign: "left",
  },
});
