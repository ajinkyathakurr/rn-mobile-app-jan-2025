import {ScrollView, StyleSheet, Text,TextInput, View ,Button,Image,TouchableOpacity,TouchableHighlight,Dimensions} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import {useState,useRef,useEffect,useContext} from 'react'
import LinearGradient from 'react-native-linear-gradient';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import FontAwesome from 'react-native-vector-icons/FontAwesome'
import SelectDropdown from 'react-native-select-dropdown'
import { COLORS } from '../colors';
import Enctypo from 'react-native-vector-icons/Entypo'
import { showMessage, hideMessage } from "react-native-flash-message";
import RBSheet from "react-native-raw-bottom-sheet";
import Spinner from 'react-native-loading-spinner-overlay/lib';
import ImagePicker from 'react-native-image-crop-picker';
import { AppContext } from '../../../user/AppContext';
import ApiConfig from '../../../api/ApiConfig';

const relations = ["Father",'Mother',"Brother","Sister","Wife",'Brother-in-Law','Father-in-Law','Sister-in-Law','Mother-in-Law','Brother','Sister','Husband','Son','Daughter','Friend','Wife']
const states=[
  "Andhra Pradesh",
                  "Arunachal Pradesh",
                  "Assam",
                  "Bihar",
                  "Chhattisgarh",
                  "Goa",
                  "Gujarat",
                  "Haryana",
                  "Himachal Pradesh",
                  "Jammu and Kashmir",
                  "Jharkhand",
                  "Karnataka",
                  "Kerala",
                  "Madhya Pradesh",
                  "Maharashtra",
                  "Manipur",
                  "Meghalaya",
                  "Mizoram",
                  "Nagaland",
                  "Odisha",
                  "Punjab",
                  "Rajasthan",
                  "Sikkim",
                  "Tamil Nadu",
                  "Telangana",
                  "Tripura",
                  "Uttarakhand",
                  "Uttar Pradesh",
                  "West Bengal",
                  "Andaman and Nicobar Islands",
                  "Chandigarh",
                  "Dadra and Nagar Haveli",
                  "Daman and Diu",
                  "Delhi",
                  "Lakshadweep",
                  "Puducherry"
  ]

export default function EditNominee({navigation,route}) {
  const [loading,setLoading]=useState(false)
  const [filepath,setfilePath]=useState("");
  const {token}=useContext(AppContext)
  const bottomsheet = useRef();
  const { name,email,
    mobile_no,
   age,
    address,
    id,
    image,
    city,
    state,
    incomplete_data,
kyc_completed,

    relationship}=route.params;
    console.log("age edit---",typeof(age))
    
  const [data,setData]=useState({
    name: name,
     email: email,
     mobile_no: mobile_no,
     age2:age ? age.toString() :"",
   
     address: address,
     relationship: relationship,
     image:image,
     city:city,
     state:state
 })
 console.log(data)
 const [doc,setDoc]=useState("")

const handleDocChange = (selectedItem)=>
{
  setDoc(selectedItem)
}

const handleImagePick=()=>{
  ImagePicker.openPicker({
    width: 300,
    height: 400,
    compressImageQuality:0.5,

    cropping: true
  }).then(image => {
    setfilePath(image.path)
    console.log(image);
  });

}
const handleSubmit = async()=>{
  if(data.name=="" ){
    showMessage({
        message: "Please Provide Name",
        type: "danger",
      });
      return
  }
  if(data.relationship=="" ){
    showMessage({
        message: "Please Provide Relationship",
        type: "danger",
      });
      return
  }
  if(data.email=="" && !data.email.includes('@') ){
    showMessage({
        message: "Please Providevalid Email",
        type: "danger",
      });
      return
  }
  if(data.mobile_no==""  && data.mobile_no.length<10){
    showMessage({
        message: "Please Provide valid Mobile no",
        type: "danger",
      });
      return
  }
  if(data.age2=="" ){
    showMessage({
        message: "Please Provide Age",
        type: "danger",
      });
      return
  }
 
  if(data.address=="" ){
    showMessage({
        message: "Please Provide Address",
        type: "danger",
      });
      return
  } 
  if(data.city=="" ){
    showMessage({
        message: "Please Provide City",
        type: "danger",
      });
      return
  }
  if(data.state=="" ){
    showMessage({
        message: "Please Provide State",
        type: "danger",
      });
      return
  }
 setLoading(true)
  const formbody=new FormData()
    if(filepath){
      formbody.append('image', {uri: filepath,name: 'photo.jpeg',filename :'imageName.png',type: 'image/jpeg'});
 
    }
  
   formbody.append('name',data.name);
    formbody.append('email',data.email);
   formbody.append('mobile_no', data.mobile_no);
    formbody.append('relationship',data.relationship);
    formbody.append('address',data.address);
    formbody.append('age',data.age2);
    formbody.append('id',id)
    formbody.append('city',data.city);
    formbody.append('state',data.state);
 
   console.log(token)
   console.log(formbody)

   fetch(ApiConfig.DIGIWILL_ADD_NOMINEE,{ method: 'put',
   headers:{  
 
     Authorization: `Token ${token}`
 
     } , body :formbody})
   .then(function(response){
    setLoading(false)
    navigation.navigate('Nominee')
     return response.json();
   })
   .then(function(json){
    setLoading(false)
    navigation.navigate('Nominee')
     return {
 
     }
   })
   .catch(function(error) {
   console.log('There has been a problem with your fetch operation: ' + error.message);
    // ADD THIS THROW error
    setLoading(false)
 
    navigation.navigate('Nominee')
     throw error;
   });


}



 const handleKycValidation = ()=>{
  if(data.name=="" ){
    showMessage({
        message: "Please enter the Name",
        type: "danger",
      });
      return
  }
  if(data.relationship=="" ){
    showMessage({
        message: "Please enter the Relationship",
        type: "danger",
      });
      return
  }
  if(data.email=="" && !data.email.includes('@') ){
    showMessage({
        message: "Please enter the valid Email",
        type: "danger",
      });
      return
  }
  if(data.mobile_no==""  && data.mobile_no.length<10){
    showMessage({
        message: "Please enter the valid Mobile no",
        type: "danger",
      });
      return
  }
  if(data.age2=="" ){
    showMessage({
        message: "Please enter the Age",
        type: "danger",
      });
      return
  }
 
  if(data.address=="" ){
    showMessage({
        message: "Please enter the Address",
        type: "danger",
      });
      return
  } 
  if(data.city=="" ){
    showMessage({
        message: "Please Enter City",
        type: "danger",
      });
      return
  }

  bottomsheet.current.open()
 }


  return (
    <SafeAreaView
    style={{backgroundColor:'#252836',height:'100%',alignItems:'center'}}

  >
 { loading ?     <Spinner visible={loading}/>:<></>}
<View style={{ backgroundColor: "#252836",height:50,alignItems:'center', justifyContent:'space-between',
      flexDirection:'row',
      }}>
<View style={{justifyContent:'space-between',flexDirection:'row',marginLeft:10,marginRight:5}}> 
<TouchableOpacity onPress={() => navigation.navigate('Nominee')}>
<AntDesign name='left' size={30} color='#FFFFFF' style={{marginRight:2}}></AntDesign>
</TouchableOpacity>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
Update Nominee 
        </Text>
 <View></View>
        </View>
</View>

        <SafeAreaView style={{flex: 1}}>
      
      <ScrollView style={styles.container}  showsVerticalScrollIndicator={false}>
      <TouchableOpacity
            onPress={() => handleImagePick()}
            style={{
              justifyContent: "center",
              alignItems: "center",
              flexDirection: "row",
            }}
          >
           <Image
source={{
uri:filepath ? filepath:(image !=null? image:'https://digiwillbackenddata.s3.us-west-2.amazonaws.com/avatar.png'  )
}}
style={{borderRadius:50,width:83,height:83,}}

></Image>
            <Image
              source={{
                uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Group+26967.png",
              }}
              style={{
                marginTop: 44,
                marginLeft: -17,
                color: COLORS.light_green,
                height: 25,
                width: 25,
              }}
            ></Image>

            {/* <Enctypo name='camera' size={21} color={} ></Enctypo> */}
          </TouchableOpacity>



      <TextInput
            style={styles.input2}
            value={data.name}
            placeholder="Name"
            onChangeText = {(text)=>setData({...data,name:text})}
    
            placeholderTextColor="#FFFFFF" 
    
          />
          <Text style={{color:COLORS.light_yello,fontSize:13}} >As per Adhar / PAN</Text>
             <SelectDropdown
	data={relations}
  defaultValue={relationship}
  buttonStyle={styles.dropDownstyle}
	onSelect={(selectedItem, index) => {
    setData({...data,relationship:selectedItem})
		console.log(selectedItem, index)
	}}
  // dropdownStyle={{backgroundColor:'black'}}
  // dropdownOverlayColor='black'
  // dropdownBackgroundColor="black"
  rowStyle={{backgroundColor:'black'}}
  defaultButtonText="Select Relationship"
  dropdownIconPosition="left"
  rowTextStyle={{color:'#FFFFFF'}}
    buttonTextStyle={styles.buttonTextStyle}
	buttonTextAfterSelection={(selectedItem, index) => {
		// text represented after item is selected
		// if data array is an array of objects then return selectedItem.property to render after item is selected
		return selectedItem
	}}
	rowTextForSelection={(item, index) => {
		// text represented for each item in dropdown
		// if data array is an array of objects then return item.property to represent item in dropdown
		return item
	}}
/>

<TextInput
            style={styles.input}
            value={data.email}
            placeholder="Email"
            onChangeText = {(text)=>setData({...data,email:text})}
    
            placeholderTextColor="#FFFFFF" 
    
            keyboardType="email-address"
          />
<TextInput
            style={styles.input}
           value={data.age2}
            placeholder="Age"
            onChangeText = {(text)=>setData({...data,age2:text})}
    
            placeholderTextColor="#FFFFFF" 
    
           
          />
        <TextInput
            style={styles.input}
            value={data.mobile_no}
            placeholder="Mobile No"
            onChangeText = {(text)=>setData({...data,mobile_no:text})}
    
            placeholderTextColor="#FFFFFF" 
    
            keyboardType="phone-pad"
          />
  <TextInput
            style={styles.input}
            value={data.address}
            placeholder="Address"
            onChangeText = {(text)=>setData({...data,address:text})}
    
            placeholderTextColor="#FFFFFF" 
    
       
          />
           <TextInput
            style={styles.input}
            value={data.city}
            placeholder="City"
            onChangeText = {(text)=>setData({...data,city:text})}
    
            placeholderTextColor="#FFFFFF" 
    
       
          />
                       <SelectDropdown
	data={states}
  defaultValue={data.state}
  buttonStyle={styles.dropDownstyle}
	onSelect={(selectedItem, index) => {
    setData({...data,state:selectedItem})
		console.log(selectedItem, index)
	}}
  // dropdownStyle={{backgroundColor:'black'}}
  // dropdownOverlayColor='black'
  // dropdownBackgroundColor="black"
  rowStyle={{backgroundColor:'black'}}
  defaultButtonText="Select State"
  dropdownIconPosition="left"
  rowTextStyle={{color:'#FFFFFF'}}
    buttonTextStyle={styles.buttonTextStyle}
	buttonTextAfterSelection={(selectedItem, index) => {
		// text represented after item is selected
		// if data array is an array of objects then return selectedItem.property to render after item is selected
		return selectedItem
	}}
	rowTextForSelection={(item, index) => {
		// text represented for each item in dropdown
		// if data array is an array of objects then return item.property to represent item in dropdown
		return item
	}}
/>




<TouchableOpacity
        onPress={()=>handleSubmit()}
            style={{width:320,
              height:45,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#FFBB00',
            borderRadius:25,
            marginTop:10,
      
         }}
            
          >
            <Text  style={{fontSize:16,color:'black' ,fontWeight:'600'}}>Update

            <AntDesign name="doubleright" size={13} marginLeft={3} color="black" fontWeight='bold' />
            </Text>
          </TouchableOpacity>



      </ScrollView>




    </SafeAreaView>

  </SafeAreaView>
  )
}
const styles = StyleSheet.create({


  header:{
    height:100,
    flexDirection:'row',alignItems:'center',justifyContent:'space-between'

  },input:{
    backgroundColor:'black',
    width:320,
    height:50,
    marginBottom:10,
    marginTop:10,
    borderRadius:25,
    paddingLeft:10,
    fontSize:16,
    color:'white'

},
input3:{
  backgroundColor:'black',
  width:240,
  height:50,
  marginBottom:10,
  marginTop:10,
  borderRadius:25,
  paddingLeft:10,
  fontSize:16,
  color:'white'

},
input2:{
  backgroundColor:'black',
  width:320,
  height:50,
  marginBottom:5,
  marginTop:10,
  borderRadius:25,
  paddingLeft:10,
  fontSize:16,
  color:'white'

},
buttonTextStyle:{
  color:'#FFFFFF',
 marginLeft:0,
 fontSize:16,
textAlign:'left',



},
dropDownstyle:{
backgroundColor:'black',
width:320,
height:50,
marginBottom:10,
marginTop:10,
borderRadius:25,
paddingLeft:10,
fontSize:16,
color:'white',
textAlign:'left'

},


  
  
  })