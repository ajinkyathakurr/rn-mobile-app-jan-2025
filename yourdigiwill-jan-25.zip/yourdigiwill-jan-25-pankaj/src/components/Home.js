import { StyleSheet, Text, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Dashboard from './Dashboard';
import Linked from './Linked';
import Settings from './Settings';
import { useEffect,useContext,useState} from 'react'
import Ionicons  from 'react-native-vector-icons/Ionicons';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import  Feather  from 'react-native-vector-icons/Feather'; 
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppContext } from '../../user/AppContext';
import { SafeAreaView } from 'react-native-safe-area-context';

const Tab = createBottomTabNavigator();

export default function Home({navigation}) {
  

  return (
    
    <Tab.Navigator 
    
    tabBarOptions={{
        activeTintColor: '#0CFEBC',
        inactiveTintColor: 'lightgray',
        activeBackgroundColor: '#1F1D2B',
        inactiveBackgroundColor: '#1F1D2B',
            style: {
                  backgroundColor: '#CE4418',
                  paddingBottom: 1
            }
     }}>
        <Tab.Screen  name="Dashboard" component={Dashboard}
      
        options={{headerShown:false,
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home" color={color} size={size} />
          )}} />
        <Tab.Screen  name="Linked"
         options={{headerShown:false,
            
            tabBarIcon: ({ color, size }) => (
                <AntDesign name="minussquareo" size={size} color={color}/>
            ),
        
          }} 
          
        component={Linked} />
        <Tab.Screen 
         options={{headerShown:false,
            tabBarIcon: ({ color, size }) => (
                <Feather name="user" size={size} color={color} />
            )}}  name="Settings" component={Settings} hide={true} />
    </Tab.Navigator>
   

  )
}
