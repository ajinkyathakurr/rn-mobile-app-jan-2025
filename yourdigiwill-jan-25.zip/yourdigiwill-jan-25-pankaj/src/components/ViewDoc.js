import {
    
    Text,
    View,
  
    TouchableOpacity,
  
  } from "react-native";
  import Header from "./Header";
  import { SafeAreaView } from "react-native-safe-area-context";
 
  import AntDesign from "react-native-vector-icons/AntDesign";
  import { WebView } from "react-native-webview";
import { useEffect } from "react";
  
  export default function ViewDoc({ navigation ,route}) {
  
  
    
  
    return (
      <SafeAreaView style={{backgroundColor: "black", height: "100%" }}>
        <View
          style={{
            backgroundColor: "#252836",
            height: 50,
            alignItems: "center",
            justifyContent: "center",
            justifyContent: "space-between",
            flexDirection: "row",
            marginLeft: 0,
            marginRight: 0,
          }}
        >
          <TouchableOpacity onPress={() => navigation.navigate("MyAssetsAndLiablity")}>
            <AntDesign
              name="left"
              size={30}
              color="#FFFFFF"
              style={{ marginRight: 2 }}
            ></AntDesign>
          </TouchableOpacity>
          <Text style={{ fontSize: 22, color: "#FFFFFF" }}>
            Document
          </Text>
          <View></View>
        </View>
        <View style={{flex:1,backgroundColor:"#252836"}}>
        <WebView source={{uri:route.params.url}}/>
        </View>
        
  
       
      </SafeAreaView>
    );
  }
  
  
  