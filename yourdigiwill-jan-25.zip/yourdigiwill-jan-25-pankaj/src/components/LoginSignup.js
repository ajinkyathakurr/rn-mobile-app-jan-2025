import { StyleSheet, Text, View, Image, TouchableOpacity, Dimensions, TextInput, KeyboardAvoidingView } from 'react-native';
import { useState, useContext } from 'react'
import AntDesign from 'react-native-vector-icons/AntDesign';
import { COLORS } from './colors';
import { postWithAuthCallWithErrorResponse } from '../../api/ApiServices';
import ApiConfig from '../../api/ApiConfig';
import { showMessage } from "react-native-flash-message";
import CheckBox from 'react-native-check-box'
import Spinner from "react-native-loading-spinner-overlay";
import { AppContext } from '../../user/AppContext';



export default function LoginSignup({ navigation }) {

  const [data, setData] = useState({ email: "" })
  const [checked, setChecked] = useState(false)
  

  const handleSubmit = () => {
    // const keyboardVerticalOffset = Platform.OS === 'ios' ? 40 : 0
    if (!checked) {
      showMessage({
        message: "Please accept terms and privacy policy",
        type: "danger",
      });
      return
    }

    if (data.email == "" || data.email.length < 10) {
      if (data.email == "") {
        showMessage({
          message: "Please enter the valid Email",
          type: "danger",
        });
      }
      if (!data.email.includes("@")) {
        showMessage({
          message: "Please enter valid email",
          type: "danger",
        });
      }

      return
    }
    postWithAuthCallWithErrorResponse(ApiConfig.DIGIWILL_GENERATE_OTP,
      { email:  data.email, terms_conditions: true }
    )
      .then((result) => {
        if (result.json.message == 'User does not exist') {
          showMessage({
            message: result.json.message,
            type: "danger",
          });
          return

        }
        if (result.json.result) {
          console.log(result.json);
          
          navigation.navigate('OtpVerification', {
            email: data.email
          })
        }
      })
      .catch((error) => {
        console.log("api response", error);

      });
  }

  return (
    <View
      style={{ backgroundColor: 'black', height: '100%' }}

    >
     
          (

            <>
              <View style={{ alignItems: 'center' }}>



                <Image style={{ width: 126, height: 77, marginTop: 60 }} source={{ uri: 'https://demowills.s3.us-west-2.amazonaws.com/Change_password.png' }}></Image>
              </View>

              <View>
                <Text style={styles.mobileText}>Enter Your Email</Text>


              </View>
              <View>
                <KeyboardAvoidingView behavior='position'>

                  <TextInput
                    style={styles.input}
                    value={data.email}
                    placeholder="example@gmail.com"
                    onChangeText={(text) => setData({ ...data, email: text })}
                    placeholderTextColor={COLORS.light_grey}


                  />
                </KeyboardAvoidingView>
              </View>
              <KeyboardAvoidingView style={{marginTop:500}} behavior='position'>
              <CheckBox
                style={{ position: 'absolute', bottom: 90, marginLeft: 20}}
                onClick={() => {console.log("clicked" , checked);
                ;setChecked(!checked)}}
                isChecked={checked}
                leftText={"CheckBox"}
                checkBoxColor="gray" // ✅ Unchecked color
                checkedCheckBoxColor="green" // ✅ Checked tick color
              />
              <Text style={{ color: '#FFFFFF', position: 'absolute', bottom: 100, marginLeft: 50 }}>
                You agree to Digiwill
                <TouchableOpacity onPress={() => navigation.navigate('Terms')}>
                  <Text style={{ color: COLORS.light_green_new, fontSize: 16 }}> Terms and Conditions </Text>

                </TouchableOpacity>


              </Text>

              <TouchableOpacity onPress={() => navigation.navigate('Privacy')} style={{ color: COLORS.light_green_new, position: 'absolute', bottom: 100, marginLeft: 50 }}>
                <Text style={{ color: COLORS.light_green_new, position: 'absolute', fontSize: 16 }}>
                  Privacy Policy
                </Text></TouchableOpacity>
              <TouchableOpacity
                onPress={() => handleSubmit()}
                style={{
                  width: Dimensions.get('window').width - 32,
                  height: 50,
                  alignItems: 'center',
                  justifyContent: 'center',
                  backgroundColor: '#0CFEBC',
                  borderRadius: 25,
                  marginTop: 10,
                  marginBottom: 20,
                  position: 'absolute',
                  bottom: 0,
                  marginLeft: 16

                }}

              >
                <Text style={{ fontSize: 20, color: '#FFFFFF', fontWeight: 'bold' }}>Send Otp

                  <AntDesign name="doubleright" size={20} marginLeft={10} color="#FFFFFF" />
                </Text>
              </TouchableOpacity>
              </KeyboardAvoidingView>
            </>
          )

      





    </View>
  )
}
const styles = StyleSheet.create({


  header: {
    height: 100,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'

  },
  input: {
    backgroundColor: 'black',
    width: Dimensions.get('window').width - 32,
    height: 50,
    marginBottom: 10,
    marginTop: 20,
    borderRadius: 25,
    paddingLeft: 20,
    fontSize: 16,
    color: COLORS.light_green,
    borderColor: COLORS.light_green,
    borderWidth: 1,
    marginHorizontal: 10,

  },

  mobileText: { 
    color: COLORS.light_green, 
    marginTop: 30, 
    fontSize: 30, 
    fontWeight: 'bold', 
    maxWidth: 300, 
    marginLeft: 20 
  }

})