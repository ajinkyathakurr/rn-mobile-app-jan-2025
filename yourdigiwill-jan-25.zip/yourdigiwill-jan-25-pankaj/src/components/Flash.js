import React from 'react'
import { StyleSheet, Text, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform, Dimensions} from 'react-native';
import { useState ,useEffect,useContext} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LinearGradient from 'react-native-linear-gradient';
import { AppContext } from '../../user/AppContext';
import { useIsFocused } from '@react-navigation/native';
export default function Flash({navigation}) {

    const {pin}=useContext(AppContext)
 
    const isFocused = useIsFocused();
  
    useEffect(()=>{
  console.log(pin)
      if(pin) {
          navigation.navigate('Pinverify',{nominee:'signup',id:''})
                }
                else{
            
                      navigation.navigate('LoginSignup')
                    
                } 


    },[pin,isFocused])
    
  return (

  <Image
  source={{uri:'https://digiwillbackenddata.s3.us-west-2.amazonaws.com/splash.png'}}
  style={{height:'100%',width:'100%'}}  />



  )
}
