import { StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions,ScrollView} from 'react-native';
import Header from './Header';
import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import { simpleGetCallWithErrorResponse } from '../../api/ApiServices';
import ApiConfig from '../../api/ApiConfig';
import { AppContext } from '../../user/AppContext';
import Spinner from 'react-native-loading-spinner-overlay/lib';
import LinearGradient from 'react-native-linear-gradient';
import Iconians from 'react-native-vector-icons/Ionicons';
import { COLORS } from './colors';
import { Color } from '../../GlobalStyles';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
export default function Notification({navigation}) {
    const {token} =useContext(AppContext) 
    const [notifications,setNotifications]=useState([])
    const [loading,setLoading]=useState(true)
    const getAllNotifiations = ()=>{

        simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_NOTIFICATIONS,{token:token})
          .then((data) => {
          
            if (data) {
                console.log(data.json)
                if(data.json.status==false){
                  setLoading(false)
                  return 
                }
                if(data.json){
                  setNotifications(data.json)
                  setLoading(false)
                }

           
            }
          })
          .catch((error) => {
            console.log("api response", error);
      
          });
      
      }
      
      
      
      useEffect(()=>{
        getAllNotifiations();
      },[])




  return (
    <SafeAreaView
    style={{backgroundColor:'black',height:'100%'}}

  >

<View style={{ backgroundColor: "#252836",height:50,alignItems:'center',justifyContent:'space-between',flexDirection:'row',marginLeft:10,marginRight:5}}>
<TouchableOpacity onPress={() => navigation.navigate("Home")}>
<AntDesign name='left' size={30} color='#FFFFFF' style={{marginRight:2}}></AntDesign>
</TouchableOpacity>
        <Text
          style={{  fontSize: 22, color: "#FFFFFF" ,}}
        >
   Notifications
        </Text>
 <View></View>
        </View>
       
        {
     loading  ? 
     <Spinner
     color={COLORS.light_green} 
     visible={loading}
     ></Spinner>:   
     
  notifications &&  notifications.length==0  ? 
     <View style={{alignItems:'center',justifyContent:'center',flex:0.8}}>

     <TouchableOpacity
                onPress={() => navigation.navigate('Home')}        

                style={{
                  height:200,
                  width:200,
                    color:'#FFFFFF',
                  marginRight:10,
                  alignItems:'center',
                  justifyContent:'center',
                  marginTop:10,
                 
               
               }}
                >
          <Image style={{height:150,width:150,alignItems:'center'}} source={{uri:'https://digiwillbackenddata.s3.us-west-2.amazonaws.com/emojione-v1_bell.png'}}/>

              </TouchableOpacity>

       <Text style={{fontSize:20,color:"white"}}>No Notifications</Text>
       </View>:
     
     <ScrollView  >
     { notifications.map((single)=>{

        return(
       <>
       <Text style={{color:"#0CFEBC",fontSize:20}}>  {single.category}</Text>
       {
            single.data.map((singlechild)=>{

                return (
                    <View  style={styles.section}>
                    <View style={{width:10,backgroundColor:"red"}}>
                    
                    </View>
                                   <Text style={{color:"#FFFFFF",marginLeft:5}}>{singlechild.title}</Text>
                    
                                    </View>
                )
            })
       }
       </>

   

             
          
        )
     })}
       </ScrollView>
   
 }


</SafeAreaView>
  )
}

const styles = StyleSheet.create({

section:{
height:70,
backgroundColor:'#2D3845',
marginBottom:10,
marginTop:10,
borderRadius:10,
marginRight:10,
marginLeft:10,
alignItems:'center',
justifyContent:'center'


}


})