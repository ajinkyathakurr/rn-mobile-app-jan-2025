import { StyleSheet,ScrollView, TextInput, TouchableOpacity, Text, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
// import { AntDesign } from '@expo/vector-icons'; 
import Icon  from 'react-native-vector-icons/AntDesign';
import Spinner from "react-native-loading-spinner-overlay";
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS } from './colors';
import { OtpInput } from "react-native-otp-entry";
import { showMessage, hideMessage } from "react-native-flash-message";
import ApiConfig from '../../api/ApiConfig';
import { PostCallWithErrorResponse } from '../../api/ApiServices';
import {useContext} from 'react'
import { AppContext } from '../../user/AppContext';
import { Color } from '../../GlobalStyles';
import { Colors } from 'react-native/Libraries/NewAppScreen';
async function setPin(value) {
  await AsyncStorage.setItem('pin', value);
}

export default  function SetupMPIN({route,navigation}) {
    console.log(route)
    const { token,pin,setisLoading} = useContext(AppContext);
    const [loading,setLoading]=useState(false)
    const [data,setData]=useState({mpin:""})
    const [newdata,newsetData]=useState({mpin:""})




    useEffect(()=>{useContext

setTimeout(() => {
    setLoading(false)
}, 2000);

    },[])

    const handleSubmit = ()=>{
      
      setLoading(true)
      const formbody=new FormData() 

      formbody.append('old_pin',data.mpin);
     formbody.append('new_pin',newdata.mpin);
   
      console.log(formbody)
      fetch(ApiConfig.CHANGE_PIN,{ method:'post',
      headers:{  
    
        Authorization: `Token ${token}`
    
        } , body :formbody})
      .then(function(response){
    
        return response.json();
      })
      .then(function(json){
      if (!json.result){
        setLoading(false)
        showMessage({
          message: json.message,
          type: "success",

        });
        navigation.navigate('Home')
    
      }
      else{
        showMessage({
          message:"false response",
          type: "danger",
         

        });
        navigation.navigate('Settings')

      }
   
    
      })
      .catch(function(error) {
        setTimeout(() => {
          setLoading(false)
          showMessage({
            message:json.message,
            type: "danger",
          });
          navigation.navigate('Home')
        }, 1000);
        
      
      console.log('There has been a problem with your fetch operation: ' + error.message);

    
        throw error;
      });




       
      }

  return (
  
  
  <KeyboardAvoidingView style={{flex:1}}>
{
          (loading) ? 
          <Spinner color={COLORS.light_green} visible={loading} />

          :
          <SafeAreaView style={styles.container}>
          <ScrollView style={{flex:1}}>
    
          
           <View style={styles.header}>
    
           <Text  style={{fontSize:22,color:'#FFFFFF',paddingBottom:10,marginTop:10}}>
                  Setup  MPIN
               </Text>
            
           </View>
           <View style={styles.body}>
        <Text style={{fontSize:22,color:'#0CFEBC',marginTop:30}}> 
       Set New MPIN
        </Text>
        <Text style={{fontSize:14,color:"#8A8D9F",marginTop:20}}> 
       To Setup your PIN code ,Enter 4 digit code then Confirm it below
        </Text>
      
<View style={styles.input}>

      
<OTPInputView
    style={{width: '80%', height: 120}}
    pinCount={4}
    onCodeChanged	= {(text)=>setData({...data,mpin:text})}
    // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
    // onCodeChanged = {code => { this.setState({code})}}
    codeInputFieldStyle={{borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:50,height:55,fontSize:20}}
    codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}
    autoFocusOnLoad
    keyboardAppearance	='dark'
    onCodeFilled =  {(text)=>setData({...data,mpin:text})}
/>

</View>

<Text style={{fontSize:16,color:"#FFFFFF",marginTop:20,paddingBottom:10}}> 
       Confirm Code Again
        </Text>
<View style={styles.input}>


<OtpInput
                  numberOfDigits={4}
                  onTextChange= {(text)=>newsetData({...newdata,mpin:text})}
                  // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
                  // onCodeChanged = {code => { this.setState({code})}}

                  // codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}    autoFocusOnLoad
                  keyboardAppearance	='dark'
                  onFilled= {(text)=>newsetData({...newdata,mpin:text})}
                  theme={
                    {
                      pinCodeTextStyle:{color:"#0CFEBC"},
                      containerStyle:{width: '80%', height: 100,marginTop:10},
                      pinCodeContainerStyle: {borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:55,height:60,fontSize:20},
                      filledPinCodeContainerStyle: {borderBottomColor:'#0CFEBC',}
                    }
                  }
              />

</View>
     
          {/* <TextInput
            style={styles.input}
            value={data.phone}
            placeholder="Otp"
            keyboardType="numeric"
            onChangeText = {(text)=>setData({...data,phone:text})}
    
            placeholderTextColor="#8A8D9F" 
          />

     */}
  

    <TouchableOpacity
          onPress={()=>handleSubmit()}
            style={{width:295,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#0CFEBC',
            opacity:"20%",
            borderRadius:25,
            marginTop:20,
            marginBottom:20
         }}
            
          >
            <Text  style={{fontSize:20,color:'black'}}>Set Pin

            <Icon name="doubleright" size={20} marginLeft={3} color="black" />
            </Text>
          </TouchableOpacity>
         
           </View>
          
           
           </ScrollView>
    
       </SafeAreaView>

      } 


  
    
  </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
    container: {
     flex:1,
     backgroundColor:'black',
  
   
    },
    header:{
        flex:0.07,
        backgroundColor:'#252836',
      alignItems:'center',
      marginBottom:30

    },
    body:{
        flex:0.4,
        backgroundColor:"#252836",
        marginTop:20,
        borderRadius:10,
       marginRight:10,
       marginLeft:10,
       alignItems:'center',
       height:450
    },
    input:{
     flex:1,
     flexDirection:'row',
    



    }
    
})