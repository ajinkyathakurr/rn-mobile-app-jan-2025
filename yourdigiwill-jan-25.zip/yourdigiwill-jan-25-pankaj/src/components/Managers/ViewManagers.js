import React, { useEffect, useState } from "react";
import {
  KeyboardAvoidingView,
  View,
  Image,
  TouchableOpacity,
  Text,
  SafeAreaView,
  ScrollView,
} from "react-native";
import { COLORS } from "../colors";
import AntDesign from "react-native-vector-icons/AntDesign";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { DeleteCallWithErrorResponse, getWithAuthCall } from "../../../api/ApiServices.js";
import ApiConfig from "../../../api/ApiConfig";
import Entypo from "react-native-vector-icons/Entypo";
import {
  Menu,
  MenuOptions,
  MenuOption,
  MenuTrigger,
} from "react-native-popup-menu";
import Spinner from "react-native-loading-spinner-overlay/lib";
import { showMessage } from "react-native-flash-message";
const ViewManagers = ({ navigation }) => {
  const [Managers, SetManagers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true)
    getWithAuthCall(ApiConfig.GET_MANAGERS).then((res) => {
      setLoading(false)
      console.log(res.manager_data)
      if (res.status) SetManagers(res.manager_data);
    });
  }, []);

  const handleEdit=(data)=>{
    navigation.navigate("AddManager",{ManagerDetails:data});
  }
  const handleAssetDelete=(id)=>{
    setLoading(true)
     DeleteCallWithErrorResponse(ApiConfig.GET_MANAGERS,{id:id}).then((res)=>{
      
      if(res.json.status)
      {
        setLoading(false)
        showMessage({message:res.json.message,type:"success"})
        const newManager=Managers.filter((manager)=>manager.id != id)
        SetManagers(newManager)
      }
     })
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.dark_grey }}>
      <View
        style={{
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
        }}
      >
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontSize: 22, color: "#FFFFFF" }}>
          Succession Managers
        </Text>
        <View></View>
      </View>
      {loading ? <Spinner color={COLORS.light_green} visible={loading} />:<></>}
      {Managers.length === 0 ? (
        <View
          style={{
            alignItems: "center",
            justifyContent: "center",
            marginTop: 100,
          }}
        >
          <TouchableOpacity
            onPress={() => navigation.navigate("AddManager")}
            style={{
              width: 91,
              height: 91,
              borderRadius: 50,
              color: "#FFFFFF",
              marginRight: 21,
              alignItems: "center",
              justifyContent: "center",
              marginTop: 10,
              backgroundColor: "#252836",
            }}
          >
            <Image
              style={{ width: 70, height: 70 }}
              source={require("../../../assets/sharenow.png")}
            />
          </TouchableOpacity>
          <Text
            style={{
              fontSize: 21,
              color: "#FFFFFF",
              marginTop: 5,
              paddingBottom: 10,
            }}
          >
            Add Succession Managers
          </Text>
        </View>
      ) : (
        <ScrollView
          contentContainerStyle={{
            marginTop: 10,
            alignItems: "center",
          }}
        >
          {Managers.map((manager, i) => {
            return (
              <View
                key={manager.id}
                style={{
                  width: "85%",
                  height: 80,
                  backgroundColor: COLORS.light_grey,
                  marginVertical: 10,
                  justifyContent: "space-between",
                  alignItems: "center",
                  flexDirection: "row",
                  padding: 10,
                  borderRadius: 10,
                }}
              >
                <View
                  style={{
                    width: 50,
                    height: 50,
                    borderRadius: 50,
                    borderWidth: 2,
                    alignItems: "center",
                    borderColor: COLORS.light_green,
                  }}
                >{manager.image?
                <Image source={{uri:manager.image}} style={{height:46,width:46,borderRadius:50}}></Image>: 
                <Text
                style={{ color: COLORS.white, fontSize: 25, marginTop: 7 }}
              >
                {manager.name[0]}
              </Text>}
                 
                </View>
                <Text style={{ color: COLORS.white, fontSize: 20 }}>
                  {manager.name}
                </Text>
                <View>
                  <Menu>
                    <MenuTrigger>
                      <Entypo name="dots-three-vertical" color={COLORS.white} size={22} />
                    </MenuTrigger>

                    <MenuOptions>
                      <MenuOption
                        onSelect={() => handleEdit(manager)}
                        color="#989898"
                      >
                        <Text style={{ color: "black", fontSize: 12 }}>
                          Edit
                        </Text>
                      </MenuOption>
                      <MenuOption
                        onSelect={() => {
                          handleAssetDelete(manager.id);
                        }}
                      >
                        <Text>Delete</Text>
                      </MenuOption>
                    </MenuOptions>
                  </Menu>
                </View>
              </View>
            );
          })}
        </ScrollView>
      )}

      <TouchableOpacity
        onPress={() => navigation.navigate("AddManager")}
        style={{
          alignItems: "center",
          justifyContent: "center",
          width: 60,
          height: 60,
          position: "absolute",
          bottom: 50,
          right: 40,
          color: "#FFFFFF",
          borderRadius: 50,
          backgroundColor: "#FFBF35",
        }}
      >
        <FontAwesome name="plus" size={24} color="black" />
      </TouchableOpacity>
    </SafeAreaView>
  );
};
export default ViewManagers;
