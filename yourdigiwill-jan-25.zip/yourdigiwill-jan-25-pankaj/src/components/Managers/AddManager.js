import {
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    View,
    Button,
    Image,
    TouchableOpacity,
   
    KeyboardAvoidingView,
  } from "react-native";
  import { SafeAreaView } from "react-native-safe-area-context";
  
  import { useState, useRef, useEffect, useContext } from "react";

  import AntDesign from "react-native-vector-icons/AntDesign";

  import SelectDropdown from "react-native-select-dropdown";
  import { COLORS } from "../colors";

  import { showMessage, hideMessage } from "react-native-flash-message";

  const relations = [
    "My CA",
    "My Manager",
    "My Lawyer",
    "Others"
  ];
  const StatesofIndia = [
    "Andhra Pradesh",
    "Arunachal Pradesh",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Andaman and Nicobar Islands",
    "Chandigarh",
    "Dadra and Nagar Haveli and Daman and Diu",
    "Delhi",
    "Lakshadweep",
    "Puducherry",
    "Ladakh",
    "Jammu and Kashmir"
  ];
  
  
  
  import ImagePicker from "react-native-image-crop-picker";
  import ApiConfig from "../../../api/ApiConfig";
  import { AppContext } from "../../../user/AppContext";
  import Spinner from "react-native-loading-spinner-overlay/lib";
  
 
  
  export default function AddManager({ navigation ,route}) {
   
    const { token } = useContext(AppContext);
    const [filepath, setfilePath] = useState("");
    const [loading, setLoading] = useState(false);
    
    const handleImagePick = () => {
      ImagePicker.openPicker({
        width: 300,
        height: 400,
        compressImageQuality: 0.5,
  
        cropping: true,
      }).then((image) => {
        setfilePath(image.path);
        console.log(image);
      });
    };
   
    const handleAddManager = async () => {
      setLoading(true);
      const formbody = new FormData();
      if (filepath) {
        formbody.append("image", {
          uri: filepath,
          name: "photo.jpeg",
          filename: "imageName.png",
          type: "image/jpeg",
        });
      }
      const phoneno=(data.mobile_no.startsWith("+91")?data.mobile_no:"+91"+data.mobile_no)
      
  
      formbody.append("name", data.name);
      formbody.append("email", data.email);
      formbody.append("mobile_no", phoneno);
      formbody.append("relationship", data.relationship);
      formbody.append("address", data.address);
      formbody.append("state", data.state);
      const method=route.params?"put":"post";
      if(method=== "put") formbody.append("id", route.params.ManagerDetails.id);
      fetch(ApiConfig.ADD_MANAGER, {
        method: method,
        headers: {
          Authorization: `Token ${token}`,
        },
        body: formbody,
      })
        .then(function (response) {
          setLoading(false);
          navigation.goBack();
          return response.json();
          
        })
        .then(function (json) {
          setLoading(false);
          console.log(json)
          if(json.status)
          showMessage({message:json.message ||json.messgae,type:"success"});
          else{
            showMessage({message:"Error occured while adding the manager",type:"danger"});
          }
          navigation.navigate("Home");
        })
        .catch(function (error) {
          console.log(
            "There has been a problem with your fetch operation: " + error.message
          );
  
          setLoading(false);
  
          navigation.navigate("Nominee");
          throw error;
        }).catch(()=>{
          showMessage({message:"There was an error adding the nominee , please enter valid details",type:"danger"})
        })
    };
  
    const [data, setData] = useState({
      name: "",
      email: "",
      mobile_no: "",
      address: "",
      relationship: "",
      state:"",
      city:"",
    });
    
    useEffect(()=>{
     if(route.params){
     
      setData(route.params.ManagerDetails)
      if(route.params.ManagerDetails.image){
        setfilePath(route.params.ManagerDetails.image)
      }
     }
    },[])
   
  
    
  
    return (
      <KeyboardAvoidingView style={{flex:1}} behavior="padding">
      <SafeAreaView
        style={{
          backgroundColor: "#252836",
          height: "100%",
          alignItems: "center",
        }}
      >
        {loading ? <Spinner visible={loading} /> : <></>}
        <View
          style={{
            backgroundColor: "#252836",
            height: 50,
            alignItems: "center",
            justifyContent: "space-between",
            flexDirection: "row",
          }}
        >
          <TouchableOpacity onPress={() => navigation.navigate("ViewManagers")}>
            <AntDesign
              name="left"
              size={30}
              color="#FFFFFF"
              style={{ marginRight: 2 }}
            ></AntDesign>
          </TouchableOpacity>
          <Text style={{ fontSize: 22, color: "#FFFFFF" }}>Add Managers</Text>
          <View></View>
        </View>
        <SafeAreaView style={{ flex: 1 }}>
          <ScrollView
            style={styles.container}
            showsVerticalScrollIndicator={true}
          >
            <TouchableOpacity
              onPress={() => handleImagePick()}
              style={{
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "row",
              }}
            >
              <Image
                source={{
                  uri:
                    filepath != ""
                      ? filepath
                      : "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/avatar.png",
                }}
                style={{ borderRadius: 50, width: 83, height: 83 }}
              ></Image>
  
              <Image
                source={{
                  uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Group+26967.png",
                }}
                style={{
                  marginTop: 44,
                  marginLeft: -17,
                  color: COLORS.light_green,
                  height: 25,
                  width: 25,
                }}
              ></Image>
            </TouchableOpacity>
            <TextInput
              style={styles.input2}
              value={data.name}
              placeholder="Name"
              onChangeText={(text) => setData({ ...data, name: text })}
              placeholderTextColor="#FFFFFF"
            />
            <Text style={{ color: COLORS.light_yello, fontSize: 13 }}>
              As per Adhar / PAN
            </Text>
            <SelectDropdown
              data={relations}
              buttonStyle={styles.dropDownstyle}
              onSelect={(selectedItem, index) => {
                setData({ ...data, relationship: selectedItem });
                console.log(selectedItem, index);
              }}
              defaultValue={data.relationship}
              rowStyle={{ backgroundColor: "black" }}
              defaultButtonText="Select Relationship"
              dropdownIconPosition="left"
              rowTextStyle={{ color: "#FFFFFF" }}
              buttonTextStyle={styles.buttonTextStyle}
              buttonTextAfterSelection={(selectedItem, index) => {
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
                return item;
              }}
            />
  
            <TextInput
              style={styles.input}
              value={data.email}
              placeholder="Email"
              onChangeText={(text) => setData({ ...data, email: text })}
              placeholderTextColor="#FFFFFF"
              keyboardType="email-address"
            />
            <SelectDropdown
              data={StatesofIndia}
              buttonStyle={styles.dropDownstyle}
              onSelect={(selectedItem, index) => {
                setData({ ...data, state: selectedItem });
                console.log(selectedItem, index);
              }}
              defaultValue={data.state}
              rowStyle={{ backgroundColor: "black" }}
              defaultButtonText="Select State"
              dropdownIconPosition="left"
              rowTextStyle={{ color: "#FFFFFF" }}
              buttonTextStyle={styles.buttonTextStyle}
              buttonTextAfterSelection={(selectedItem, index) => {
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
                return item;
              }}
            />
            <TextInput
              style={styles.input}
              value={data.mobile_no}
              placeholder="Mobile No"
              onChangeText={(text) => setData({ ...data, mobile_no: text })}
              placeholderTextColor="#FFFFFF"
              keyboardType="phone-pad"
            />
            <TextInput
              style={styles.input}
              value={data.address}
              placeholder="Address"
              onChangeText={(text) => setData({ ...data, address: text })}
              placeholderTextColor="#FFFFFF"
            />
             <TextInput
              style={styles.input}
              value={data.city}
              placeholder="City"
              onChangeText={(text) => setData({ ...data, city:text })}
              placeholderTextColor="#FFFFFF"
            />
            
  
           
              
            <TouchableOpacity
              onPress={() => handleAddManager()}
              style={{
                width: 320,
                height: 45,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: COLORS.light_yello,
                borderRadius: 25,
                marginTop: 10,
              }}
            >
              <Text style={{ fontSize: 16, color: "black" }}>
                {(route.params)?"Update":"Add Manager"}
                <AntDesign
                  name="doubleright"
                  size={13}
                  marginLeft={3}
                  color="black"
                />
              </Text>
            </TouchableOpacity>
            
          </ScrollView>
  
         
        </SafeAreaView>
      </SafeAreaView>
      </KeyboardAvoidingView>
    );
  }
  const styles = StyleSheet.create({
    header: {
      height: 100,
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
    },
    input: {
      backgroundColor: "black",
      width: 320,
      height: 50,
      marginBottom: 10,
      marginTop: 10,
      borderRadius: 25,
      paddingLeft: 10,
      fontSize: 16,
      color: "white",
    },
    input3: {
      backgroundColor: "black",
      width: 240,
      height: 50,
      marginBottom: 10,
      marginTop: 10,
      borderRadius: 25,
      paddingLeft: 10,
      fontSize: 16,
      color: "white",
    },
    input2: {
      backgroundColor: "black",
      width: 320,
      height: 50,
      marginBottom: 5,
      marginTop: 10,
      borderRadius: 25,
      paddingLeft: 10,
      fontSize: 16,
      color: "white",
    },
    buttonTextStyle: {
      color: "#FFFFFF",
      marginLeft: 0,
      fontSize: 16,
      textAlign: "left",
    },
    dropDownstyle: {
      backgroundColor: "black",
      width: 320,
      height: 50,
      marginBottom: 10,
      marginTop: 10,
      borderRadius: 25,
      paddingLeft: 10,
      fontSize: 16,
      color: "white",
      textAlign: "left",
    },
  });
  