import {
  StyleSheet,
  ScrollView,
  Text,
  View,
  Button,
  Image,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import Header from "./Header";
import { SafeAreaView } from "react-native-safe-area-context";
import { useState, useRef, useEffect, useContext } from "react";
import { simpleGetCallWithErrorResponse } from "../../api/ApiServices";
import ApiConfig from "../../api/ApiConfig";
import { AppContext } from "../../user/AppContext";
import LinearGradient from "react-native-linear-gradient";
import FontAwesome from "react-native-vector-icons/FontAwesome";
import { COLORS } from "./colors";
import Spinner from "react-native-loading-spinner-overlay/lib";
import AntDesign from "react-native-vector-icons/AntDesign";

export default function Linked({ color, text, path, navigation, route }) {
  const [active, setActive] = useState("shared_by_me");
  const [nominees, setNominees] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sharedbymenominees, setSharedbymeNominees] = useState([]);
  const [sharedwithme, setSharedwithmeNominees] = useState([]);
  const { token } = useContext(AppContext);

  const getAllSharedByMeNominees = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_SHAREDBYME_NOMINEES, {
      token: token,
    })
      .then((data) => {
        if (data) {
          console.log(data);
          setSharedbymeNominees(data.json.data);
        }
        setLoading(false);
      })
      .catch((error) => {
        console.log("api response", error);
      });
    simpleGetCallWithErrorResponse(ApiConfig.GET_SHARED_WITH_ME, {
      token: token,
    })
      .then((data) => {
        if (data) {
          console.log(data);
          setSharedwithmeNominees(data.json.data);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };
  const getAllNominees = () => {
    simpleGetCallWithErrorResponse(ApiConfig.GET_ALL_NOMINEES, { token: token })
      .then((data) => {
        if (data) {
          console.log(data);
          setNominees(data.json.data);
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log("api response", error);
      });
  };

  useEffect(() => {
    getAllNominees();
    getAllSharedByMeNominees();
  }, [active, navigation.isFocused()]);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: "#252836" }}>
      <LinearGradient
        colors={["#2D3845", "#05A081", "#2D3845"]}
        style={{ flex: 1 }}
      >
        <View style={{ flex: sharedbymenominees?.length == 0 ? 0.8 : 0.3 }}>
          <View
            style={{
              backgroundColor: "#252836",
              height: 50,
              alignItems: "center",
              justifyContent: "space-between",
              flexDirection: "row",
            }}
          >
            <TouchableOpacity onPress={() => navigation.navigate("Dashboard")}>
              <AntDesign
                name="left"
                size={30}
                color="#FFFFFF"
                style={{ marginRight: 2 }}
              ></AntDesign>
            </TouchableOpacity>
            <Text style={{ fontSize: 22, color: "#FFFFFF" }}>
              Linked Accounts
            </Text>
            <View></View>
          </View>
          <View style={styles.toggleParent}>
            <TouchableOpacity
              onPress={() => setActive("shared_with_me")}
              style={{
                // width:108,
                height: 35,
                paddingLeft: 8,
                paddingRight: 8,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor:
                  active == "shared_with_me" ? "#0CFEBC" : "black",
                borderRadius: 25,
              }}
            >
              <Text
                style={{
                  fontSize: 13,
                  color: active == "shared_with_me" ? "black" : "#FFFFFF",
                }}
              >
                Shared With me
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setActive("shared_by_me")}
              style={{
                height: 35,
                paddingLeft: 8,
                paddingRight: 8,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: active == "shared_by_me" ? "#0CFEBC" : "black",
                borderRadius: 25,
              }}
            >
              <Text
                style={{
                  fontSize: 13,
                  color: active == "shared_by_me" ? "black" : "#FFFFFF",
                }}
              >
                Shared By me
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        {active == "shared_by_me" ? (
          <>
            <ScrollView style={{ flex: 0.2 }}>
              {sharedbymenominees && sharedbymenominees.length != 0 ? (
                sharedbymenominees.map((single) => {
                  return (
                    <TouchableOpacity
                      onPress={() =>
                        navigation.navigate("LinkedAssets", {
                          nominee_id: single.id,
                          name: single.shared_to.name,
                        })
                      }
                      style={{
                        width: Dimensions.get("screen").width - 32,
                        backgroundColor: "#1F1D2B",
                        height: 70,
                        marginLeft: 16,
                        marginRight: 16,
                        marginTop: 10,
                        borderRadius: 10,
                        alignItems: "center",

                        flex: 1,
                        flexDirection: "row",
                      }}
                    >
                      <View
                        style={{
                          width: 40,
                          height: 40,
                          borderColor: COLORS.light_green,
                          borderWidth: 1,
                          borderRadius: 50,
                          alignItems: "center",
                          marginLeft: 10,
                        }}
                      >
                        <Text
                          style={{
                            marginTop: 5,
                            fontSize: 22,
                            color: "#FFFFFF",
                          }}
                        >
                          {single.shared_to.name[0]}
                        </Text>
                      </View>
                      <Text
                        style={{
                          fontSize: 17,
                          color: "#FFFFFF",
                          marginLeft: 20,
                        }}
                      >
                        {single.shared_to.name}
                      </Text>
                      <View></View>
                    </TouchableOpacity>
                  );
                })
              ) : (
                <Spinner color={COLORS.light_green} visible={loading}></Spinner>
              )}
              {sharedbymenominees && sharedbymenominees.length == 0 ? (
                <View
                  style={{ alignItems: "center", justifyContent: "center" }}
                >
                  <TouchableOpacity
                    onPress={() => navigation.navigate("SharedByMe")}
                    style={{
                      width: 91,
                      height: 91,
                      borderRadius: 50,
                      color: "#FFFFFF",
                      marginRight: 21,
                      alignItems: "center",
                      justifyContent: "center",
                      marginTop: 10,
                      backgroundColor: "#252836",
                    }}
                  >
                    <Image
                      style={styles.rndImage}
                      source={require("../../assets/sharenow.png")}
                    />
                  </TouchableOpacity>
                  <Text
                    style={{
                      fontSize: 21,
                      color: "#FFFFFF",
                      marginTop: 5,
                      paddingBottom: 10,
                    }}
                  >
                    Start Sharing Now!
                  </Text>
                </View>
              ) : (
                ""
              )}
            </ScrollView>

            <TouchableOpacity
              onPress={() => navigation.navigate("SharedByMe")}
              style={{
                alignItems: "center",
                width: 60,
                position: "absolute",
                bottom: 30,
                right: 20,
                height: 60,
                color: "#FFFFFF",
                borderRadius: 50,
                justifyContent: "center",
                backgroundColor: "#FFBF35",
              }}
            >
              <FontAwesome name="plus" size={24} color="black" />
            </TouchableOpacity>
          </>
        ) : (
          
            <ScrollView style={{ flex: 0.2 }}>
              {sharedwithme.length != 0 ? (
                sharedwithme.map((single) => {
                  return (
                    <TouchableOpacity
                      style={{
                        width: Dimensions.get("screen").width - 32,
                        backgroundColor: "#1F1D2B",
                        height: 70,
                        marginLeft: 16,
                        marginRight: 16,

                        borderRadius: 10,
                        alignItems: "center",

                        flex: 1,
                        flexDirection: "row",
                      }}
                      onPress={()=>navigation.navigate("SharedWithMe",{nominee_id:single.id,name:single.user.legal_name})}
                    >
                      <View
                        style={{
                          width: 40,
                          height: 40,
                          borderColor: COLORS.light_green,
                          borderWidth: 1,
                          borderRadius: 50,
                          alignItems: "center",
                          marginLeft: 5,
                          marginRight: 15,
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 22,
                            color: "#FFFFFF",
                            marginTop: 5,
                          }}
                        >
                          {single.user.legal_name[0]}
                        </Text>
                      </View>
                      <Text
                        style={{
                          fontSize: 17,
                          color: "#FFFFFF",
                        }}
                      >
                        {single.user.legal_name}
                      </Text>
                      <View></View>
                    </TouchableOpacity>
                  );
                })
              ) : (
                <View
                  style={{ alignItems: "center", justifyContent: "center" }}
                >
                  <Text
                    style={{
                      fontSize: 21,
                      color: "#FFFFFF",
                      marginTop: 5,
                      paddingTop: 100,
                    }}
                  >
                    No Shared Asset Records Found
                  </Text>
                </View>
              )}
            </ScrollView>
          
        )}
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  toggleParent: {
    flexDirection: "row",
    backgroundColor: "black",
    justifyContent: "center",
    alignSelf: "center",
    borderRadius: 25,
    marginTop: 10,
    height: 37,
    borderColor: "#0CFEBC",
    borderWidth: 1,
  },
  header: {
    flex: 1,
  },
  rndImage: {
    width: 50.75,
    height: 50.75,
  },
});
