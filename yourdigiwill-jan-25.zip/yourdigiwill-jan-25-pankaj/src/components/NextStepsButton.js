import React from 'react'
import { View, Text, Image, TouchableOpacity, KeyboardAvoidingView } from 'react-native'
import LinearGradient from 'react-native-linear-gradient'
import arrow_forward from './../../assets/arrow_forward.png'
import { showMessage } from 'react-native-flash-message'


const NextStepsButton = (props) => {
  return (
    <KeyboardAvoidingView  style={{
      position: 'absolute',
      zIndex: 1,
      bottom: 40,
      right: 30,
      opacity: props.active ? 1 : 0.5,
    }}>
    <TouchableOpacity 
        disabled={!props.active}
        onPress={props.handleButtonPress}
      >
        <LinearGradient start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={['#0CFEBC', '#05A081']} style={{
          padding: 10,
          borderColor: '#0CFEBC',
          borderWidth: 1,
          borderRadius: 50,
        }}>
          <View style={{
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'center',
            alignItems: 'center',
          }}
          >
            <Text style={{
              color:"#fff",
              fontSize: 20,
              fontWeight: 'bold',
            }}>{ (props.text)? props.text:"Next Steps"}</Text>
            <Image source={arrow_forward} style={{
              width: 30,
              height: 30,
              marginLeft: 10,
              marginTop: 5,
            }} />
          </View>
        </LinearGradient>
      </TouchableOpacity>
      </KeyboardAvoidingView>
  )
}

export default NextStepsButton