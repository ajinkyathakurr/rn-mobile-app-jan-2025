import {
  View,
  ScrollView,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
} from "react-native";
import AntDesign from "react-native-vector-icons/AntDesign";
import DatePicker from "react-native-date-picker";
import Modal from "react-native-modal";
import Feather from "react-native-vector-icons/Feather";
import SelectDropdown from "react-native-select-dropdown";
import { showMessage } from "react-native-flash-message";
import { COLORS } from "../colors";
const frequencies = ["once", "monthly", "quarterly", "halfyearly", "yearly"];
export default function ReminderScreen({
  Visible,
  seTvisible,
  data,
  open,
  setOpen,
  setData,
  setisOn
}) {
  const showModal = () => {
    seTvisible(false);
    setisOn(true);
    showMessage({
      message: "Reminder set successfully",
      type: "success",
    });
  };
  const hideModal = () => {
    seTvisible(false);
    setisOn(false);
    showMessage({
      message: "Reminder Canceled successfully",
      type: "success",
    });
  };
  return (
    <Modal
      onRequestClose={() => {
        seTvisible(false);
      }}
      transparent={true}
      isVisible={Visible}
      style={{ justifyContent: "center" }}
      deviceHeight={500}
    >
      <ScrollView
        style={{
          flex: 1,
          backgroundColor: COLORS.light_grey,
          borderRadius: 10,
          marginTop: 100,
          marginBottom: 150,
        }}
      >
        <View
          style={{
            alignItems: "center",
            flex: 1,

            justifyContent: "space-between",
          }}
        >
          <View style={{ alignItems: "center" }}>
            <Text
              style={{
                color: COLORS.light_green,
                marginTop: 20,
                fontSize: 20,
              }}
            >
              When to Remind?
            </Text>
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: "black",
              paddingLeft: 15,
              borderRadius: 35,
              height: 50,
              width: 250,
              marginTop: 20,
            }}
          >
            <AntDesign name="calendar" size={30} color={COLORS.light_green} />
            <SelectDropdown
              data={frequencies}
              buttonStyle={styles.frequencyDownstyle}
              onSelect={(selectedItem, index) => {
                setData({ ...data, reminder_type: selectedItem });
              }}
              rowStyle={{ backgroundColor: "#FFFFFF" }}
              defaultButtonText="Select Frequency"
              dropdownIconPosition="left"
              rowTextStyle={{ color: "black" }}
              buttonTextStyle={styles.frequencybuttonTextStyle}
              buttonTextAfterSelection={(selectedItem, index) => {
                return selectedItem;
              }}
              rowTextForSelection={(item, index) => {
                return item;
              }}
            />
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: "black",
              paddingLeft: 15,
              borderRadius: 35,
              height: 50,
              width: 200,
              marginTop: 20,
              marginLeft: -50,
            }}
          >
            <Feather name="watch" size={30} color={COLORS.light_green} />
            <DatePicker
              modal
              mode="date"
              open={open}
              date={data.date}
              onConfirm={(date) => {
                setOpen(false);
                setData({ ...data, date: date });
              }}
              onCancel={() => {
                setOpen(false);
              }}
            />

            <TouchableOpacity
              style={styles.frequencyinput}
              onPress={() => setOpen(true)}
            >
              <Text
                style={{
                  fontSize: 16,
                  color: COLORS.light_green,
                  marginTop: 10,
                  paddingBottom: 10,
                }}
              >
                {(data.date)?(data.date.getFullYear() +
                  "-" +
                  (data.date.getMonth() + 1) +
                  "-" +
                  data.date.getDate()):""}
              </Text>
            </TouchableOpacity>
          </View>
          <TextInput
            style={{
              backgroundColor: "black",
              width: 295,
              height: 100,
              marginBottom: 10,
              marginTop: 10,
              borderRadius: 10,
              paddingLeft: 10,
              fontSize: 16,
              marginLeft: 10,
              color: COLORS.light_green,
            }}
            value={data.reminder_message}
            placeholder="Note here (if any)"
            keyboardType="text"
            onChangeText={(text) =>
              setData({ ...data, reminder_message: text })
            }
            placeholderTextColor={COLORS.light_green}
          />

          <View style={{ flexDirection: "row" }}>
            <TouchableOpacity
              onPress={() => hideModal()}
              style={{
                width: 100,
                height: 40,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: COLORS.light_yello,
                borderRadius: 25,
                bottom: 0,
                marginLeft: 32,
                marginRight: 32,
                marginTop: 40,
              }}
            >
              <Text style={{ fontSize: 18, color: "black" }}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => showModal()}
              style={{
                width: 100,
                height: 40,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: "#0CFEBC",
                borderRadius: 25,
                bottom: 0,
                marginLeft: 16,
                marginRight: 16,
                marginTop: 40,
              }}
            >
              <Text style={{ fontSize: 18, color: "black" }}>Save</Text>
            </TouchableOpacity>
          </View>

          {/* <Button title="Hide modal" onPress={toggleModal} /> */}
        </View>
      </ScrollView>
    </Modal>
  );
}
const styles = StyleSheet.create({
  buttonTextStyle: {
    color: "#FFF",

    textAlign: "left",
    marginLeft: 0,
    fontSize: 16,
  },
  sectionstyles: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 20,
    marginLeft: 15,
    marginRight: 15,
  },
  imageStyle: {
    padding: 7,
    margin: 7,
    height: 25,
    width: 25,
    marginTop: 10,
    marginRight: 10,
    flexDirection: "row",
  },

  dropDownstyle: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },

  container: {
    flex: 1,
    backgroundColor: "black",
  },
  header: {
    backgroundColor: "#252836",
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    marginLeft: 10,
    marginRight: 5,
  },
  body: {
    flex: 0.4,
    backgroundColor: "#252836",
    marginTop: 20,
    borderRadius: 10,
    marginRight: 10,
    marginLeft: 10,
    alignItems: "center",
  },
  input: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  frequencyinput: {
    backgroundColor: "black",
    width: 200,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 0,
    fontSize: 16,
    color: "white",
    marginLeft: 10,
  },

  frequencyDownstyle: {
    backgroundColor: "black",
    width: 200,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    marginLeft: 10,
  },
  frequencybuttonTextStyle: {
    color: COLORS.light_green,

    textAlign: "left",
    marginLeft: 0,
    fontSize: 16,
  },
});
