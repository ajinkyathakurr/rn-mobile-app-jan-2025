import {
  View,
  ScrollView,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
} from "react-native";
import AntDesign from "react-native-vector-icons/AntDesign";
import DatePicker from "react-native-date-picker";
import Modal from "react-native-modal";
import Feather from "react-native-vector-icons/Feather";
import SelectDropdown from "react-native-select-dropdown";
import { COLORS } from "../colors";
import { PermissionsIOS } from 'react-native';
import ImagePicker from "react-native-image-crop-picker";
import DocumentPicker from 'react-native-document-picker';
export default function UploadDoc({
 
 docs,
 setDocs,
}) {

  const requestDocumentPermission = async () => {
    try {
      const granted = await PermissionsIOS.requestMultiple([
        PermissionsIOS.PERMISSIONS.PHOTO_LIBRARY,
       
        PermissionsIOS.PERMISSIONS.DOCUMENTS,
      ]);
      // Check if permissions are granted
      if (
        granted[PermissionsIOS.PERMISSIONS.PHOTO_LIBRARY] === 'authorized' &&
      
        granted[PermissionsIOS.PERMISSIONS.DOCUMENTS] === 'authorized'
      ) {
        return 1;
      } else {
        return 0;//console.log('Permissions not granted');
      }
    } catch (error) {
      
      return -1;
    }
  };

  const pickDocument = async () => {
    const permission=await requestDocumentPermission()
    if(permission)
    {
      try {
        const res = await DocumentPicker.pick({
          type: [DocumentPicker.types.allFiles],
        });
        // Handle the selected document
        console.log('Document picked:', );
        setDocs(res)
        
      } catch (err) {
        if (DocumentPicker.isCancel(err)) {
          // User cancelled the picker
          alert("Upload Cancelled")
        } else {
          // Error occurred
          console.log(err)
          alert('Error picking document');
        }
      }
    }
    else{
      alert("Please provide permission to access documents");
    }
    
  };

  
  return (
    <View style={{ flex: 0.5, marginTop: 40 }}>
      <TouchableOpacity
        onPress={() => pickDocument()}
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          marginLeft: 10,
          marginRight: 10,
        }}
      >
        <Text style={{ color: COLORS.light_green, fontSize: 18 }}>
          Upload Document
        </Text>

        <AntDesign
          name="addfile"
          size={25}
          color={COLORS.light_green}
        ></AntDesign>
      </TouchableOpacity>
      {(docs)
        ? docs.map((single) => {
            return (
              <View
               key={single.name}
                style={{
                  marginLeft: 11,
                  marginRight: 10,
                  marginTop: 15,
                  flexDirection:"row",
                  width:"94%",
                  justifyContent:"space-between",
                  alignItems:"center"
                  
                }}
              >
                <Text style={{width:300, color: "white" }}>{single.name}</Text>
                <TouchableOpacity onPress={()=>setDocs([])}>
                <AntDesign
          name="delete"
          size={25}
          color={COLORS.light_green}
        ></AntDesign></TouchableOpacity>
              </View>
            );
          })
        : ""}
    </View>
  );
}
const styles = StyleSheet.create({});
