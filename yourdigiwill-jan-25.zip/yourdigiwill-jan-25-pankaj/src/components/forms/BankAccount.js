import { StyleSheet, Text, View ,Button,Image,ActivityIndicator,KeyboardAvoidingView,Platform,ScrollView, TextInput, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState,useContext } from 'react';
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import { showMessage, hideMessage } from "react-native-flash-message";
import { postWithAuthCallWithErrorResponse } from '../../../api/ApiServices';
import ApiConfig from '../../../api/ApiConfig';
import DigiSafe from './DigiSafe';
import SelectDropdown from 'react-native-select-dropdown'
import { COLORS } from '../colors';
import Entypo  from 'react-native-vector-icons/Entypo';
import ImagePicker from 'react-native-image-crop-picker';
import Modal from "react-native-modal";
import DatePicker from 'react-native-date-picker'
import ToggleSwitch from 'toggle-switch-react-native'
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { AppContext } from '../../../user/AppContext';
import Spinner from 'react-native-loading-spinner-overlay/lib';
// import DocumentPicker
//  from 'react-native-document-picker'
const countries = ["Equity mutual funds", "Dividend Yield Mutual Fund", "ELSS Funds", "overseas fund","LIquid Funds","Overnight Funds","Dynamic Bond Fund","Corporate Bond Fund","Banking & PSU Debt Fund","Gilt Fund","Floating Rate Funds","Hybrid Mutual Funds","Gold Mutual Funds"]
const frequencies=['once','monthly','quarterly','halfyearly','yearly']
const investment_type=['FD','RD','Saving Deposit','Current Deposit','Bank Scheme']
const account_type=['Saving','Current']
const bank_name=[
    'Au Small Finance Bank Limited',
	'Arunachal Pradesh Rural Bank',
	'Andhra Pradesh Grameena Vikas Bank',
	'Andhra Pragathi Grameena Bank',
	'IDBI Bank Ltd',
	'YES Bank Ltd.',
	'Tamilnad Mercantile Bank Ltd',
	'South Indian Bank Ltd',
	'RBL Bank Ltd',
	'Nainital Bank Ltd',
	'Kotak Mahindra Bank Ltd',
	'Karur Vysya Bank Ltd',
	'Karnataka Bank Ltd',
	'Jammu & Kashmir Bank Ltd',
	'Union Bank of India',
	'IDFC First Bank Ltd',
	'UCO Bank',
	'State Bank of India',
	'Induslnd Bank Ltd',
	'Punjab National Bank',
	'ICICI Bank Ltd.',
	'Punjab & Sind Bank',
	'HDFC Bank Ltd',
	'Indian Overseas Bank',
	'Indian Bank',
	'Federal Bank Ltd',
	'Central Bank of India',
	'Dhanlaxmi Bank Ltd',
	'Canara Bank',
	'DCB Bank Ltd',
	'Bank of Maharashtra',
	'City Union Bank Ltd',
	'Bandhan Bank Ltd',
	'Bank of India',
	'Bandhan Bank Ltd',
	'Bank of Baroda',
	'Axis Bank Ltd',
   'Woori Bank',
	'United Overseas Bank Ltd',
	'Sumitomo Mitsui Banking Corporation',
	'Standard Chartered Bank',
	'Sonali Bank Ltd',
	'Societe Generale',
	'Shinhan Bank',
	'SBM Bank (India) Limited',
	'Sberbank',
	'Qatar National Bank (Q.P.S.C.)',
	'PT Bank Maybank Indonesia TBK',
	'NatWest Markets Plc',
	'MUFG Bank, Ltd',
	'Mizuho Bank Ltd.',
	'Mashreq Bank PSC',
	'Krung Thai Bank Public Co. Ltd.',
	'Kookmin Bank',
	'KEB Hana Bank',
	'JSC VTB Bank',
	'J.P. Morgan Chase Bank N.A.',
	'Industrial Bank of Korea',
	'Industrial & Commercial Bank of China Ltd',
	'HSBC Ltd',
	'FirstRand Bank Ltd',
	'First Abu Dhabi Bank PJSC',
	'Emirates Bank NBD',
	'Doha Bank Q.P.S.C',
	'Deutsche Bank',
	'DBS Bank India Limited',
	'CTBC Bank Co., Ltd.',
	'Credit Suisse A.G',
	'Credit Agricole Corporate & Investment Bank',
	'Cooperatieve Rabobank U.A.',
	'Citibank N.A.',
	'BNP Paribas',
	'Bank of Nova Scotia',
	'Bank of China',
	'Bank of Ceylon',
	'Bank of Bahrain & Kuwait BSC',
	'Bank of America',
	'Barclays Bank Plc',
	'Australia and New Zealand Banking Group Ltd',
	'American Express Banking Corporation',
	'Abu Dhabi Commercial Bank Ltd',
	'AB Bank Ltd.',
	'Vidharbha Konkan Gramin Bank',
	'Uttarbanga Kshetriya Gramin Bank',
	'Uttarakhand Gramin Bank',
	'Uttar Bihar Gramin Bank',
	'Utkal Grameen bank',
	'Airtel Payments Bank Limited',
	'Tripura Gramin Bank',
	'Telangana Grameena Bank',
	'Paytm Payments Bank Limited',
	'Tamil Nadu Grama Bank',
	'Saurashtra Gramin Bank',
	'Fino Payments Bank Limited',
	'Sarva Haryana Gramin Bank',
	'Saptagiri Grameena Bank',
	'India Post Payments Bank Limited',
	'Rajasthan Marudhara Gramin Bank',
	'Punjab Gramin Bank',
	'Unity Small Finance Bank Limited',
	'Puduvai Bharathiar Grama Bank',
	'Prathama UP Gramin Bank',
	'Shivalik Small Finance Bank Limited',
	'Paschim Banga Gramin Bank',
	'Odisha Gramya Bank',
	'North East Small Finance Bank Limited',
	'Nagaland Rural Bank',
	'Mizoram Rural Bank',
	'Meghalaya Rural Bank',
	'Jana Small Finance Bank Limited',
	'Manipur Rural Bank',
	'Maharashtra Gramin Bank',
	'Fincare Small Finance Bank Limited',
	'Madhyanchal Gramin Bank',
	'Madhya Pradesh Gramin Bank',
	'Kerala Gramin Bank',
	'Karnataka Vikas Grameena Bank',
	'Karnataka Gramin Bank',
	'ESAF Small Finance Bank Limited',
	'Jharkhand Rajya Gramin Bank',
	'J&K Grameen Bank',
	'Utkarsh Small Finance Bank Limited',
	'Himachal Pradesh Gramin Bank',
	'Ellaquai Dehati Bank',
	'Ujjivan Small Finance Bank Limited',
	'Dakshin Bihar Gramin Bank',
	'Chhattisgarh Rajya Gramin Bank',
	'Suryoday Small Finance Bank Limited',
	'Chaitanya Godavari Grameena Bank',
	'Baroda UP Bank',
	'Equitas Small Finance Bank Limited',
	'Baroda Rajasthan Kshetriya Gramin Bank',
	'Baroda Gujarat Gramin Bank',
	'Bangiya Gramin Vikas Bank',
	'Assam Gramin Vikash Bank',
	'Capital Small Finance Bank Limited',
	'Aryavart Bank'
]
export default function BankAccount({navigation,route}) {
const {category_id,metadata}=route.params;
  const [date, setDate] = useState(new Date())
  const [open, setOpen] = useState(false)
  const [additional,setadditional]=useState(false)
  const {token}=useContext(AppContext)
    const [loading,setLoading]=useState(false)
    const [data,setData]=useState({origin:metadata ? metadata.origin:"",id:metadata ? metadata.id:"",message:metadata ? metadata.message:"",category_id:metadata ? metadata.category_id:"",bank_name:metadata ? metadata.bank_name:"",account_type:metadata ? metadata.account_type:"",account_no:metadata ? metadata.account_no:"",bank_branch:metadata ? metadata.bank_branch:"",reminder_type:"",reminder_message:"",date:new Date()})
    const [docs,setDocs]=useState([])
    const [historydate,setHistorydate]=useState(new Date())
    const [isModalVisible, setModalVisible] = useState(false);
    const [isOn,setisOn]=useState(false)
  
    if (data.origin){
      button_text="Update"
      back_navigate="MyAssetsAndLiablity"
     }
     else{
      button_text="Save"
      back_navigate="Home"
     }
    const hideModal = ()=>{
setModalVisible(false)
setisOn(false)
showMessage({
  message: "Reminder Canceled successfully",
  type: "success",
});

    }

    const showModal = ()=>{
      setModalVisible(false)
      setisOn(true)
      showMessage({
        message: "Reminder set successfully",
        type: "success",
      });
      
          }
    useEffect(()=>{

setTimeout(() => {
    setLoading(false)
}, 2000);

    },[])

const setReminder = (isOn)=>{
  console.log("hii")
 setModalVisible(true)
//setisOn(true)
}

    const handleImagePick=()=>{
      ImagePicker.openPicker({
        width: 300,
        height: 400,
        compressImageQuality:0.5,
        multiple:true,
  
        cropping: true
      }).then(image => {
        setDocs(image)
        console.log(image);
      });
  
    }

    const handleSubmit = ()=>{
      if(data.bank_name==""){
       
          showMessage({
            message: "Please Enter Bank Name",
            type: "danger",
          });
          return
        }
        
      setLoading(true)
      const formbody=new FormData()
      if (docs) {
        for (var i = 0; i < docs.length; i++) {
          formbody.append("doc_file", {
            uri: docs[i].uri,
            name: docs[i].name,
            filename:docs[i].name ,
            type: docs[i].type,
          });
        }
      }

      formbody.append('bank_name',data.bank_name);
      formbody.append('bank_branch',data.bank_branch)
     formbody.append('account_type',data.account_type);
    formbody.append('account_no' , data.account_no);
      formbody.append('message',data.message);
    formbody.append('category_id',category_id)
    if(isOn){
      formbody.append('reminder_type',data.reminder_type);
      formbody.append('reminder_message',data.reminder_message);
     formbody.append('date',data.date.getFullYear()+ "-"+(data.date.getMonth()+1)+"-"+data.date.getDate())
    }
    if (data.origin=="edit"){
      formbody.append('category_id',data.category_id);
    formbody.append('will_id',data.id);
      method='put'
    }
    else{
      method='post'
    }
      console.log(formbody)
      fetch(ApiConfig.DIGIWILL_ADD_ASSET,{ method:method,
      headers:{  
    
        Authorization: `Token ${token}`
    
        } , body :formbody})
      .then(function(response){
    
        return response.json();
      })
      .then(function(json){
    console.log(json)
    setLoading(false)
    showMessage({
      message: json.message,
      type: "success",
    });
    setTimeout(() => {
      navigation.navigate("Home");

    }, 100);    
      })
      .catch(function(error) {
        setTimeout(() => {
          setLoading(false)
          showMessage({
            message: "Asset Added successfully",
            type: "success",
          });
          navigation.navigate('Home')
        }, 1000);
        
      
      console.log('There has been a problem with your fetch operation: ' + error.message);

    
        throw error;
      });




       
      }





  return (
  
  
  <KeyboardAvoidingView style={{flex:1}} behavior='height'>

          
          <SafeAreaView style={styles.container}>
          <ScrollView style={{flex:1}}>
    
          
           <View style={styles.header}>
           <TouchableOpacity onPress={() => navigation.navigate(back_navigate)}>
<AntDesign name='left' size={30} color='#FFFFFF' style={{marginRight:2}}></AntDesign>
</TouchableOpacity>
    
           <Text  style={{fontSize:22,color:'#FFFFFF',marginTop:10,paddingBottom:10}}>Bank Account</Text>
            <View></View>
           </View>
           {
loading ? 
<Spinner visible={loading}/>

      

         :<>
          <View style={styles.body}>
            <DigiSafe/>
            <SelectDropdown
	data={bank_name}
  buttonStyle={styles.dropDownstyle}
	onSelect={(selectedItem, index) => {
		console.log(selectedItem, index)
    setData({...data,bank_name:selectedItem})
	}}
  rowStyle={{backgroundColor:'black'}}
  defaultButtonText="Bank Name"
  dropdownIconPosition="left"
  rowTextStyle={{color:'#FFFFFF'}}
  defaultValue={data.bank_name}
  buttonTextStyle={styles.buttonTextStyle}
	buttonTextAfterSelection={(selectedItem, index) => {
		// text represented after item is selected
		// if data array is an array of objects then return selectedItem.property to render after item is selected
		return selectedItem
	}}
	rowTextForSelection={(item, index) => {
		// text represented for each item in dropdown
		// if data array is an array of objects then return item.property to represent item in dropdown
		return item
	}}
/>
           <TextInput
            style={styles.input}
            placeholder="Account Number"
            value={data.account_no}
            keyboardType="numeric"
            onChangeText = {(text)=>setData({...data,account_no:text})}
            placeholderTextColor="#8A8D9F" 
          />

         
         


    
    
           </View>
           <View style={{flex:0.5,marginTop:40}}>
<TouchableOpacity 
onPress={()=>handleImagePick()}
style={{flexDirection:'row',justifyContent:'space-between',marginLeft:10,marginRight:10}}>
<Text style={{color:COLORS.light_green,fontSize:18}} >Upload Document</Text>

<Entypo name='upload' size={18} color={COLORS.light_green}></Entypo>


</TouchableOpacity>
{
  docs.length != 0 ? 
  docs.map((single)=>{
return (
<View style={{marginLeft:10,marginRight:10,marginTop:5}}>
  <Text style={{color:'white'}}>{single.path}</Text>
 
  </View>

)


  }):""
}


           </View>

<View>
    <TouchableOpacity 
    onPress={()=>setadditional(!additional)}
    style={{flexDirection:'row',justifyContent:'space-between',marginLeft:10,marginRight:10,marginTop:20}}>
    <Text style={{color:COLORS.light_green,fontSize:18}}>Additional Info</Text>
{
    additional ? 
<AntDesign name='caretdown' color={"#FFFFFF"}></AntDesign>
:<AntDesign name='caretup' color={"#FFFFFF"}></AntDesign>

}
    </TouchableOpacity>
{
    additional ? 
    <View>
    <View style={styles.body}>
          
    <TextInput
            style={styles.input}
            value={data.bank_branch}
            placeholder="Branch Name"
            onChangeText = {(text)=>setData({...data,bank_branch:text})}
    
            placeholderTextColor="#8A8D9F" 
          />  
       
       <SelectDropdown
	data={account_type}
  buttonStyle={styles.dropDownstyle}
	onSelect={(selectedItem, index) => {
		console.log(selectedItem, index)
    setData({...data,account_type:selectedItem})
	}}
  rowStyle={{backgroundColor:'black'}}
  defaultButtonText="Account Type"
  dropdownIconPosition="left"
  rowTextStyle={{color:'#FFFFFF'}}
  defaultValue={data.account_type}
  buttonTextStyle={styles.buttonTextStyle}
	buttonTextAfterSelection={(selectedItem, index) => {
		// text represented after item is selected
		// if data array is an array of objects then return selectedItem.property to render after item is selected
		return selectedItem
	}}
	rowTextForSelection={(item, index) => {
		// text represented for each item in dropdown
		// if data array is an array of objects then return item.property to represent item in dropdown
		return item
	}}
/>


 <TextInput
            style={styles.input}
            value={data.message}
            placeholder="Message"
           
            keyboardType="text"
            onChangeText = {(text)=>setData({...data,message:text})}
    
            placeholderTextColor="#8A8D9F" 
          />

    
    
           </View>
    </View>:""
}
    

</View>


<View style={{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginRight:15,marginLeft:15,marginTop:20,marginBottom:70}}>
  <Text style={{color:'white',fontSize:20}} >Set Reminder?</Text>
<>
<Modal 
  onRequestClose={() => {setModalVisible(false)}}

transparent={true}  isVisible={isModalVisible} style={{justifyContent:'center'}} deviceHeight={500} >
        <ScrollView style={{ flex: 1 ,backgroundColor:COLORS.light_grey,borderRadius:10,marginTop:100,marginBottom:50}} >
          <View style={{alignItems:'center'}}>
          <Text style={{color:COLORS.light_green,marginTop:20,fontSize:18}}>When to Remind?</Text>
          </View>

          <SelectDropdown
	data={frequencies}
  buttonStyle={styles.frequencyDownstyle}
	onSelect={(selectedItem, index) => {
		setData({...data,reminder_type:selectedItem})
	}}
  rowStyle={{backgroundColor:'black'}}
  defaultButtonText="Select Frequency"
  dropdownIconPosition="left"
  rowTextStyle={{color:'#FFFFFF'}}
  buttonTextStyle={styles.frequencybuttonTextStyle}
	buttonTextAfterSelection={(selectedItem, index) => {
		// text represented after item is selected
		// if data array is an array of objects then return selectedItem.property to render after item is selected
		return selectedItem
	}}
	rowTextForSelection={(item, index) => {
		// text represented for each item in dropdown
		// if data array is an array of objects then return item.property to represent item in dropdown
		return item
	}}
/>
<DatePicker
        modal
        mode='date'
        open={open} 
        date={data.date}
        onConfirm={(date) => {
          setOpen(false)
setData({...data,date:date})}}
        onCancel={() => {
          setOpen(false)
        }}
      />
      <TouchableOpacity  style={styles.frequencyinput} onPress={() => setOpen(true)} >

<Text style={{fontSize:16,color:COLORS.light_green,marginTop:10,paddingBottom:10}}>{data.date.getFullYear() + "-" + (data.date.getMonth()+1) +"-"+data.date.getDate()}</Text>
  </TouchableOpacity>
      <TextInput
          style={{backgroundColor:'black',
          width:295,
          height:100,
          marginBottom:10,
          marginTop:10,
          borderRadius:10,
          paddingLeft:10,
          fontSize:16,
          marginLeft:10,
          color:COLORS.light_green,}}
            value={data.reminder_message}
            placeholder="Note here (if any)"
           
            keyboardType="text"
            onChangeText = {(text)=>setData({...data,reminder_message:text})}
    
            placeholderTextColor={COLORS.light_green}
          />

<View style={{flexDirection:'row'}}>
<TouchableOpacity
               onPress={()=>hideModal()}
            style={{width:100,
              height:40,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:COLORS.light_yello,
            borderRadius:25,
            bottom:0,
            marginLeft:16,
            marginRight:16,
            marginTop:40
          
          
         }}
            
          >
            <Text  style={{fontSize:16,color:'black' }}>Cancel

            </Text>
          </TouchableOpacity>
          <TouchableOpacity
        onPress={()=>showModal()}
            style={{width:100,
              height:40,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#0CFEBC',
            borderRadius:25,
            bottom:0,
            marginLeft:16,
            marginRight:16,
            marginTop:40
          
          
         }}
            
          >
            <Text  style={{fontSize:16,color:'black' }}>Save

            </Text>
          </TouchableOpacity>
</View>
          

          {/* <Button title="Hide modal" onPress={toggleModal} /> */}
        </ScrollView>
      </Modal>
</>
  <ToggleSwitch
  isOn={isOn}
  onColor="green"
  offColor="red"
  label="Example label"
  labelStyle={{ color: "black", fontWeight: "700" }}
  size={'small'}
  onToggle={(isOn)=> setReminder(isOn)}
/>

</View>


         </>
           }
          
           </ScrollView>

           <View style={{width:Dimensions.get('screen').height-32}}>
           <TouchableOpacity
        onPress={()=>handleSubmit()}
            style={{width:Dimensions.get('screen').width-32,
              height:50,
            alignItems:'center',
            justifyContent:'center',
            backgroundColor:'#0CFEBC',
            borderRadius:25,
            bottom:0,
            marginLeft:16,
            marginRight:16,
            marginTop:40,
            position:'absolute',
            bottom:0,
            left:0
         }}
            
          >
            <Text  style={{fontSize:20,color:'black' }}>{button_text}

            <AntDesign name="doubleright" size={20} marginLeft={3} color="black" />
            </Text>
          </TouchableOpacity>

           </View>
    
       </SafeAreaView>

     


  
    
  </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  buttonTextStyle:{
    color:'#FFF',

    textAlign:'left',
    marginLeft:0,
    fontSize:16,


  },
dropDownstyle:{
  backgroundColor:'black',
  width:295,
  height:50,
  marginBottom:10,
  marginTop:10,
  borderRadius:25,
  paddingLeft:10,
  fontSize:16,
  color:'#FFF'
},

    container: {
     flex:1,
     backgroundColor:'black',
  
   
    },
    header:{
        flex:0.07,
        backgroundColor:'#252836',
      alignItems:'center',
      justifyContent:'space-between',
      flexDirection:'row',
      marginLeft:10,
      marginRight:5

    },
    body:{
        flex:0.4,
        backgroundColor:"#252836",
        marginTop:20,
        borderRadius:10,
       marginRight:10,
       marginLeft:10,
       alignItems:'center',
    },
    input:{
        backgroundColor:'black',
        width:295,
        height:50,
        marginBottom:10,
        marginTop:10,
        borderRadius:25,
        paddingLeft:10,
        fontSize:16,
        color:'white',
      
       



    },
    frequencyinput:{
      backgroundColor:'black',
      width:295,
      height:50,
      marginBottom:10,
      marginTop:10,
      borderRadius:25,
      paddingLeft:10,
      fontSize:16,
      color:'white',
      marginLeft:10
    
     



  }

    ,
    frequencyDownstyle:{
      backgroundColor:'black',
      width:295,
      height:50,
      marginBottom:10,
      marginTop:10,
      borderRadius:25,
      paddingLeft:10,
      fontSize:16,
      color:'white',
      marginLeft:10
    },
    frequencybuttonTextStyle:{
      color:COLORS.light_green,
  
      textAlign:'left',
      marginLeft:0,
      fontSize:16,
  
  
    }
})