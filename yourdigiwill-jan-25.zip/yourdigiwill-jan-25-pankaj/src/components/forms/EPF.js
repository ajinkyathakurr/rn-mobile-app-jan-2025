import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useEffect, useState, useContext } from "react";
import AntDesign from "react-native-vector-icons/AntDesign";
import { showMessage, hideMessage } from "react-native-flash-message";
import { postWithAuthCallWithErrorResponse } from "../../../api/ApiServices";
import ApiConfig from "../../../api/ApiConfig";
import DigiSafe from "./DigiSafe";
import SelectDropdown from "react-native-select-dropdown";
import { COLORS } from "../colors";
import Entypo from "react-native-vector-icons/Entypo";
import ImagePicker from "react-native-image-crop-picker";
import Modal from "react-native-modal";
import DatePicker from "react-native-date-picker";
import ToggleSwitch from "toggle-switch-react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import { AppContext } from "../../../user/AppContext";
import Spinner from "react-native-loading-spinner-overlay/lib";
import ReminderScreen from "./ReminderScreen";
import UploadDoc from "./UploadDoc";
// import DocumentPicker
//  from 'react-native-document-picker'

export default function EPF({ navigation, route }) {
  const { category_id, metadata } = route.params;
  const [date, setDate] = useState(new Date());
  const [open, setOpen] = useState(false);
  const [additional, setadditional] = useState(false);
  const { token } = useContext(AppContext);
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
    origin: metadata ? metadata.origin : "",
    id: metadata ? metadata.id : "",
    category_id: metadata ? metadata.category_id : "",
    uan_no: metadata ? metadata.uan_no : "",
    message: metadata ? metadata.message : "",
    amount: metadata ? metadata.amount : "",
    reminder_type: "",
    reminder_message: "",
    date: new Date(),
  });
  const [docs, setDocs] = useState([]);
  const [historydate, setHistorydate] = useState(new Date());
  const [isModalVisible, setModalVisible] = useState(false);
  const [isOn, setisOn] = useState(false);
  if (data.origin){
    button_text="Update"
    back_navigate="MyAssetsAndLiablity"
   }
   else{
    button_text="Save"
    back_navigate="Home"
   }
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  }, []);

  const setReminder = (isOn) => {
    console.log("hii");
    setModalVisible(true);
    //setisOn(true)
  };

 

  const handleSubmit = () => {
    if (data.uan_no == "") {
      showMessage({
        message: "Please Enter UAN",
        type: "danger",
      });
      return;
    }
    setLoading(true);
    const formbody = new FormData();
    if (docs) {
      for (var i = 0; i < docs.length; i++) {
        formbody.append("doc_file", {
          uri: docs[i].uri,
          name: docs[i].name,
          filename:docs[i].name ,
          type: docs[i].type,
        });
      }
    }

    formbody.append("uan_no", data.uan_no);
    formbody.append("message", data.message);

    formbody.append("amount", data.amount);
    formbody.append("category_id", category_id);
    if (isOn) {
      formbody.append("reminder_type", data.reminder_type);
      formbody.append("reminder_message", data.reminder_message);
      formbody.append(
        "date",
        data.date.getFullYear() +
          "-" +
          (data.date.getMonth() + 1) +
          "-" +
          data.date.getDate()
      );
    }
    if (data.origin == "edit") {
      formbody.append("category_id", data.category_id);
      formbody.append("will_id", data.id);
      method = "put";
    } else {
      method = "post";
    }
    console.log(formbody);
    fetch(ApiConfig.DIGIWILL_ADD_ASSET, {
      method: method,
      headers: {
        Authorization: `Token ${token}`,
      },
      body: formbody,
    })
      .then(function (response) {
        return response.json();
      })
      .then(function (json) {
        console.log(json);
        setLoading(false);
        showMessage({
          message: json.message,
          type: "success",
        });
        setTimeout(() => {
          navigation.navigate("Home");

        }, 100);      })
      .catch(function (error) {
        setTimeout(() => {
          setLoading(false);
          showMessage({
            message: "Asset Added successfully",
            type: "success",
          });
          navigation.navigate("Home");
        }, 1000);

        console.log(
          "There has been a problem with your fetch operation: " + error.message
        );

        throw error;
      });
  };

  return (
    <KeyboardAvoidingView behavior="height" style={{ flex: 1 }}>
      <SafeAreaView style={styles.container}>
        <ScrollView style={{ flex: 1 }}>
          <View style={styles.header}>
            <TouchableOpacity
              onPress={() => navigation.navigate(back_navigate)}
            >
              <AntDesign
                name="left"
                size={30}
                color="#FFFFFF"
                style={{ marginRight: 2 }}
              ></AntDesign>
            </TouchableOpacity>

            <Text
              style={{
                fontSize: 22,
                color: "#FFFFFF",
                marginTop: 10,
                paddingBottom: 10,
              }}
            >
              EPF{" "}
            </Text>
            <View></View>
          </View>
          {loading ? (
            <Spinner visible={loading} />
          ) : (
            <>
              <View style={styles.body}>
                <DigiSafe />
                <TextInput
                  style={styles.input}
                  placeholder="UAN Number"
                  value={data.uan_no}
                  onChangeText={(text) => setData({ ...data, uan_no: text })}
                  placeholderTextColor="#8A8D9F"
                />
              </View>
              <UploadDoc setDocs={setDocs} docs={docs} />
              <View>
                <TouchableOpacity
                  onPress={() => setadditional(!additional)}
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    marginLeft: 10,
                    marginRight: 10,
                    marginTop: 20,
                  }}
                >
                  <Text style={{ color: COLORS.light_green, fontSize: 18 }}>
                    Additional Info
                  </Text>
                  {!additional ? (
                    <AntDesign name="caretdown" color={"#FFFFFF"}></AntDesign>
                  ) : (
                    <AntDesign name="caretup" color={"#FFFFFF"}></AntDesign>
                  )}
                </TouchableOpacity>
                {additional ? (
                  <View>
                    <View style={styles.body}>
                      <TextInput
                        style={styles.input}
                        value={data.amount}
                        placeholder="Amount"
                        keyboardType="numeric"
                        onChangeText={(text) =>
                          setData({ ...data, amount: text })
                        }
                        placeholderTextColor="#8A8D9F"
                      />

                      <TextInput
                        style={styles.input}
                        value={data.message}
                        placeholder="Message"
                        keyboardType="default"
                        onChangeText={(text) =>
                          setData({ ...data, message: text })
                        }
                        placeholderTextColor="#8A8D9F"
                      />
                    </View>
                  </View>
                ) : (
                  ""
                )}
              </View>
{/* 
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                  marginRight: 15,
                  marginLeft: 15,
                  marginTop: 20,
                  marginBottom: 70,
                }}
              >
                <Text style={{ color: "white", fontSize: 20 }}>
                  Set Reminder?
                </Text>
                <>
                <ReminderScreen
                    Visible={isModalVisible}
                   
                    setOpen={setOpen}
                    data={data}
                    open={open}
                    setData={setData}
                   setisOn={setisOn}
                   seTvisible={setModalVisible}
                  />
                </>
                <ToggleSwitch
                  isOn={isOn}
                  onColor="green"
                  offColor="red"
                  label="Example label"
                  labelStyle={{ color: "black", fontWeight: "700" }}
                  size={"small"}
                  onToggle={(isOn) => setReminder(isOn)}
                />
              </View> */}
            </>
          )}
        </ScrollView>
        <View style={{ width: Dimensions.get("screen").height - 32 }}>
          <TouchableOpacity
            onPress={() => handleSubmit()}
            style={{
              width: Dimensions.get("screen").width - 32,
              height: 50,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "#0CFEBC",
              borderRadius: 25,
              bottom: 0,
              marginLeft: 16,
              marginRight: 16,
              marginTop: 40,
              position: "absolute",
              bottom: 0,
              left: 0,
            }}
          >
            <Text style={{ fontSize: 20, color: "black" }}>
              {button_text}

              <AntDesign
                name="doubleright"
                size={20}
                marginLeft={3}
                color="black"
              />
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  buttonTextStyle: {
    color: "#8A8D9F",

    textAlign: "left",
    marginLeft: 0,
    fontSize: 16,
  },
  dropDownstyle: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },

  container: {
    flex: 1,
    backgroundColor: "black",
  },
  header: {
    flex: 0.07,
    backgroundColor: "#252836",
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: "row",
    marginLeft: 10,
    marginRight: 5,
  },
  body: {
    flex: 0.4,
    backgroundColor: "#252836",
    marginTop: 20,
    borderRadius: 10,
    marginRight: 10,
    marginLeft: 10,
    alignItems: "center",
  },
  input: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
  },
  frequencyinput: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    marginLeft: 10,
  },

  frequencyDownstyle: {
    backgroundColor: "black",
    width: 295,
    height: 50,
    marginBottom: 10,
    marginTop: 10,
    borderRadius: 25,
    paddingLeft: 10,
    fontSize: 16,
    color: "white",
    marginLeft: 10,
  },
  frequencybuttonTextStyle: {
    color: COLORS.light_green,

    textAlign: "left",
    marginLeft: 0,
    fontSize: 16,
  },
});
