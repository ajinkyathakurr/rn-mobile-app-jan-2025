import {
  StyleSheet,
  Text,
  View,
  Button,
  Image,
  ActivityIndicator,
  KeyboardAvoidingView,
  Alert,
  BackHandler,
  Platform,
  Dimensions,
  TouchableOpacity,
} from "react-native";
import { COLORS } from "../colors";
import RBSheet from "react-native-raw-bottom-sheet";
import { useRef } from "react";
import FontAwsome from "react-native-vector-icons/FontAwesome";
import MaterialIcons from "react-native-vector-icons/MaterialIcons";
import image from "../../../assets/dwicon.png"
export default function DigiSafe({ navigation }) {
  const RBref = useRef(null);
  return (
    <View>
      <RBSheet
        ref={RBref}
        closeOnDragDown={false}
        closeOnPressMask={true}
        closeOnPressBack={true}
        height={650}
        customStyles={{
          draggableIcon: {
            backgroundColor: "#ffe",
          },
          container: {
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
            backgroundColor: "rgba(52, 52, 52, 0.1)",
            display: "flex",
            flexDirection: "column",
            overflow: "visible",
          },
        }}
      >
        <View
          style={{
            width: 100,
            height: 100,
            backgroundColor: COLORS.light_grey,
            borderRadius: 150,
            marginTop: -10,
            marginLeft: "37%",
            zIndex: 1,
            flex:1,
            justifyContent:"center",
            alignItems:"center"
          }}
        >
            <Image resizeMethod="cover" width={50} height={50} source={image}/>
        </View>
        <View
          style={{
            alignItems: "center",
            backgroundColor: COLORS.light_green,
            
            marginTop: -40,
            borderTopEndRadius: 20,
            borderTopLeftRadius: 20,
            paddingTop: 60,
            height:620,
            paddingBottom:50
          }}
        >
          <Text
            style={{
              fontSize: 25,
              fontWeight: "bold",
              borderBottomWidth: 2,
              borderBottomColor: COLORS.grey,
            }}
          >
            DigiWill is safe and secure
          </Text>
          <View
            style={{
              borderWidth: 0.25,
              borderColor: COLORS.light_grey,
              width: 300,
              marginTop: 5,
            }}
          ></View>
          <View>
            <View
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                width: "80%",
              }}
            >
              <View
                style={{
                  marginRight: 10,
                  backgroundColor: "#FFFFFF",
                  width: 50,
                  height: 50,
                  borderRadius: 50,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FontAwsome name="group" size={30} />
              </View>

              <Text style={{ fontSize: 15 }}>
               Life status tracker AI ensuring your financial records & 
               wills reaches your loved one's after you
              </Text>
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                width: "80%",
              }}
            >
              <View
                style={{
                  marginRight: 10,
                  backgroundColor: "#FFFFFF",
                  width: 50,
                  height: 50,
                  borderRadius: 50,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <MaterialIcons name="security" size={30} />
              </View>

              <Text style={{ fontSize: 15 }}>
               DigiWill never discloses your data to third parties
              </Text>
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                width: "80%",
              }}
            >
              <View
                style={{
                  marginRight: 10,
                  backgroundColor: "#FFFFFF",
                  width: 50,
                  height: 50,
                  borderRadius: 50,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FontAwsome name="lock" size={30} />
              </View>

              <Text style={{ fontSize: 15 }}>
                DigiWill uses 256 Bit AES Encryption + Tokenization
              </Text>
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                width: "80%",
              }}
            >
              <View
                style={{
                  marginRight: 10,
                  backgroundColor: "#FFFFFF",
                  width: 50,
                  height: 50,
                  borderRadius: 50,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FontAwsome name="cloud" size={30} />
              </View>

              <Text style={{ fontSize: 15 }}>
               We are hosted on AWS Private Server
              </Text>
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                width: "80%",
              }}
            >
              <View
                style={{
                  marginRight: 10,
                  backgroundColor: "#FFFFFF",
                  width: 50,
                  height: 50,
                  borderRadius: 50,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <MaterialIcons name="verified-user" size={30} />
              </View>

              <Text style={{ fontSize: 15 }}>
                Biometric Authentication , Mpin, Videos are stored 
                for any unAuthorized account detection.
              </Text>
            </View>
            

              
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: "row",
                alignItems: "center",
                width: "80%",
              }}
            >
              
          </View>
          
        </View>
      </RBSheet>
      <TouchableOpacity
        onPress={() => {
          RBref.current.open();
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Text
            style={{
              color: COLORS.light_green,
              fontSize: 18,
              marginTop: 10,
              marginBottom: 10,
            }}
          >
            DigiSafe
          </Text>
          <Image
            source={{ uri: "https://digiwillbackenddata.s3.us-west-2.amazonaws.com/Vector+(13).png" }}
            style={{ height: 14, width: 11 }}
          />
        </View>
      </TouchableOpacity>
    </View>
  );
}
