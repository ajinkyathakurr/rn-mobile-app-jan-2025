// BackgroundSlider.js
import React, { useRef, useState,useContext,useEffect } from 'react';
import { View, ImageBackground, Text,Dimensions, StyleSheet, SafeAreaView, TouchableOpacity } from 'react-native';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import screen1 from "../../assets/screen1.png"
import screen2 from "../../assets/screen2.png"
import screen3 from "../../assets/screen3.png"
import { COLORS } from './colors';
import { AppContext } from '../../user/AppContext';
const { width: screenWidth } = Dimensions.get('window');

const OnboardingScreen = ({navigation}) => {
  const [activeSlide, setActiveSlide] = useState(0);
  const carouselRef = useRef(null);
  // const { pin, setPin, loading,setisLoading } = useContext(AppContext)
  const data = [
    { image: screen1,},
    { image: screen2,},
    { image: screen3,},
  ];
  // useEffect(() => {
  //   if (!loading && pin) {
  //     navigation.navigate('Pinverify', { nominee: "signup", id: "" })

  //   }

  // }, [loading])

  const renderItem = ({ item }) => (
    <ImageBackground source={item.image} style={styles.imageBackground}>
      
    </ImageBackground>
  );

  return (
    <SafeAreaView style={styles.container}>
      <Carousel
        ref={carouselRef}
        data={data}
        renderItem={renderItem}
        sliderWidth={screenWidth}
        itemWidth={screenWidth}
        onSnapToItem={(index) => setActiveSlide(index)}
        autoplay={true}
        loop={true}
      />
      <Pagination
        dotsLength={data.length}
        activeDotIndex={activeSlide}
        containerStyle={styles.paginationContainer}
        dotStyle={styles.paginationDot}
        inactiveDotStyle={styles.inactiveDot}
        inactiveDotOpacity={0.6}
        inactiveDotScale={0.6}
      />
      <TouchableOpacity
      onPress={()=>{
        navigation.navigate("LoginSignup")
      }} style={{
        width:150,
        height:50,
        backgroundColor:COLORS.light_green,
        justifyContent:"center",
        alignItems:"center",
        borderRadius:50
      }}>
        <Text style={{fontWeight:"bold"}}>Get Started</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:"black",
    alignItems:"center",

  },
  imageBackground: {
    width: screenWidth,
    height:"110%",
    
    justifyContent: 'center',
    alignItems: 'center',
  },
  paginationContainer: {
    position: 'absolute',
    bottom: 80,
    left: 0,
    right: 0,
  },
  paginationDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    marginHorizontal: 8,
    backgroundColor: COLORS.light_green,
    
  },
  inactiveDot: {
    backgroundColor: 'gray',
  },
});

export default OnboardingScreen;
