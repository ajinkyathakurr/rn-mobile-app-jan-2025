import {
  StyleSheet,
  Text,
  View,
  Share,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from "react-native";
import Spinner from "react-native-loading-spinner-overlay";
import { getWithAuthCall, postWithAuthCall } from "../../api/ApiServices";
import Clipboard from "@react-native-clipboard/clipboard";
import { SafeAreaView } from "react-native-safe-area-context";
import { showMessage } from "react-native-flash-message";
import AntDesign from "react-native-vector-icons/AntDesign";
import Feather from "react-native-vector-icons/Feather";
import { COLORS } from "./colors";
import ApiConfig from "../../api/ApiConfig";
import { useEffect } from "react";
import { useState } from "react";
import { useRef } from "react";

export default function Reffral({ navigation }) {
  const [code, setCode] = useState(null);
  const ReferralIpRef = useRef(null);
  const [codeApplied, setCodeApplied] = useState(null);
  const [withdrawAmount, setWithdrawAmount] = useState(0);
  const [Visible,SetVisible]=useState(false)
  const [BankDetails, setBankDetails] = useState({
    amount: 0,
    account_no: null,
    ifsc_code: null,
    mode: "BANK",
  });
  const [CodeUsers,SetCodeUsers]=useState([])
  const applyCode = () => {
    if (codeApplied)
      postWithAuthCall(ApiConfig.DIGIWILL_REFEREL_VERIFICATION, {
        referral_code: codeApplied,
      }).then((res) => {
        if (res.status) {
          showMessage({ message: "Code Applied", type: "success" });
          ReferralIpRef.current.setNativeProps({
            style: { display: "none" },
          });
        } else showMessage({ message: res.message, type: "danger" });
      });
  };
  const onShare = async () => {
    try {
      const result = await Share.share({
        message: `Hi, I just secured my family's future with DigiWill. I strongly recommend you to secure your family using Digiwill, India's only Digital Virasat App. Use my code ${code} to secure you loved ones in just 3 clicks and get 5% extra discount on any purchase`,
      });
    } catch (error) {
      Alert.alert(error.message);
    }
  };

  const copyToClipboard = () => {
    Clipboard.setString(code);
    showMessage({
      message: "Referral code copied to clipboard",
      type: "success",
    });
  };

  const getReward = () => {
    getWithAuthCall(ApiConfig.GET_WITHDRAW_REWARD).then((res) => {
      setWithdrawAmount(res.data.balance);
      setCode(res.data.code);
      setBankDetails({
        account_no: res.data.account_no,
        amount: res.data.balance,
        ifsc_code: res.data.ifsc_code,
      });
    });
  };
  const withdrawReward = () => {
    if (
      !BankDetails.account_no ||
      !BankDetails.ifsc_code ||
      !BankDetails.mode
    ) {
      showMessage({
        message: "Please give all the Bank details",
        type: "info",
      });
    }
    else if(withdrawAmount<500){
      showMessage({
        message: "Minimum Rs. 500 balance is required",
        type: "info",
      });
    }
    postWithAuthCall(ApiConfig.WITHDRAW_REWARD, BankDetails).then((res) => {
      console.log(res);
    });
  };
  const checkRefEligibility = () => {
    getWithAuthCall(ApiConfig.CHECK_REFERRAL_ELIGIBILITY).then((res) => {
      if (res.status)
        if (res.refer_code_applied)
          ReferralIpRef.current.setNativeProps({
            style: { display: "none" },
          });
        else
          showMessage({
            message: "You are not eligible for referral",
            type: "danger",
          });
    });
  };

  const getSharedAndPurchased=()=>{
    getWithAuthCall(ApiConfig.SHARED_PURCHASED).then((res)=>{
      if(res.status)
      SetCodeUsers(res.Data);
    })
  }
  useEffect(() => {
    checkRefEligibility();
    getReward();
    getSharedAndPurchased();
  }, []);

  // shared and purchased functionality remaining
  // Withdraw backend bug
  // Withdraw functionality Remaining
  return (
    <SafeAreaView style={{ backgroundColor: "black", height: "100%" }}>
      <View
        style={{
          backgroundColor: "#252836",
          height: 50,
          alignItems: "center",
          justifyContent: "space-between",
          flexDirection: "row",
          marginLeft: 10,
          marginRight: 5,
        }}
      >
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <AntDesign
            name="left"
            size={30}
            color="#FFFFFF"
            style={{ marginRight: 2 }}
          ></AntDesign>
        </TouchableOpacity>
        <Text style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" }}>
          Refer and Earn
        </Text>
        <View></View>
      </View>
      <View style={{ flex: 1, alignItems: "center", padding: 10 }}>
        <View
          ref={ReferralIpRef}
          style={{
            backgroundColor: COLORS.grey,
            borderRadius: 10,
            height: 100,
            width: 350,
            alignItems: "center",
            justifyContent: "space-evenly",
          }}
        >
          <Text style={{ color: COLORS.light_green, fontWeight: "bold" }}>
            Have Reffral Code ?
          </Text>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              borderWidth: 2,
              borderColor: COLORS.light_green,
              borderRadius: 50,
              paddingRight: 15,
            }}
          >
            <TextInput
              placeholderTextColor={COLORS.light_green}
              placeholder="Enter Referral Code"
              style={{
                padding: 10,
                borderRadius: 30,
                color: COLORS.light_green,
                width: 250,
                height: 50,
              }}
              onChangeText={(text) => setCodeApplied(text)}
            />
            <TouchableOpacity onPress={applyCode}>
              <Text style={{ color: COLORS.light_yello }}>Apply</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={{ flex: 1, marginTop: 20, alignItems: "center" }}>
          <Text style={{ color: COLORS.light_green, fontSize: 20 }}>
            Reffer and Earn Rewards
          </Text>
          {/* Share icon here */}
          <Text
            style={{
              marginTop: 10,
              color: COLORS.white,
              fontSize: 15,
              textAlign: "center",
            }}
          >
            Share Referral code with your friends, Get Rewards when they Create
            / Purchase on Digiwill
          </Text>
          <View
            style={{
              borderColor: COLORS.light_green,
              borderWidth: 2,
              backgroundColor: COLORS.white,
              alignItems: "center",
              padding: 10,
              borderRadius: 20,
              marginTop: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                margin: 5,
                width: 300,
                justifyContent: "center",
              }}
            >
              {code ? (
                <Text
                  style={{
                    color: COLORS.black,
                    fontSize: 15,
                    fontWeight: "bold",
                    marginRight: 10,
                  }}
                >
                  {code}
                </Text>
              ) : (
                <Spinner color={COLORS.light_green} visible={!code} />
              )}

              <TouchableOpacity onPress={copyToClipboard}>
                <Feather name="copy" size={20} color={COLORS.black} />
              </TouchableOpacity>
            </View>
            <TouchableOpacity onPress={onShare}>
              <Text style={{ color: COLORS.light_green_new, fontSize: 15 }}>
                Tap to Share
              </Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate("Terms");
            }}
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              backgroundColor: COLORS.light_grey_body,
              height: 50,
              width: 340,
              marginTop: 20,
              borderRadius: 10,
            }}
          >
            <Text style={{ color: COLORS.light_green, marginLeft: 10 }}>
              Terms & Conditions
            </Text>
            <AntDesign
              name="right"
              style={{ marginRight: 15 }}
              size={20}
              color={COLORS.light_green}
            />
          </TouchableOpacity>
          <View
            style={{
              borderColor: COLORS.white,
              borderWidth: 0.5,
              width: 350,
              marginTop: 20,
            }}
          />
          <View style={{ alignItems: "center" }}>
            <Text style={{ color: COLORS.light_green }}>My Reward</Text>
            <Text style={{ color: COLORS.white }}>
              Your rewards can be redeem in your account below.
            </Text>
            <View
              style={{
                width: 320,
                marginTop: 20,
                alignItems: "center",
                justifyContent: "space-between",
                flexDirection: "row",
              }}
            >
              <Text style={{ color: COLORS.light_green, fontSize: 25 }}>
                ₹ {withdrawAmount}
              </Text>
              <TouchableOpacity
                onPress={withdrawReward}
                style={{
                  width: 150,
                  padding: 10,
                  borderRadius: 50,
                  alignItems: "center",
                  justifyContent: "space-between",
                  backgroundColor: COLORS.light_yello,
                  flexDirection: "row",
                }}
              >
                <Feather
                  color={COLORS.black}
                  size={30}
                  name="arrow-down-circle"
                />
                <Text style={{ fontSize: 20, fontWeight: "bold" }}>
                  Withdraw
                </Text>
              </TouchableOpacity>
            </View>
            <View
              style={{
                paddingLeft: 10,
                paddingRight: 10,
                paddingBottom: 20,
                marginTop: 20,
                backgroundColor: COLORS.light_grey_body,
                width: 340,
                maxHeight:220,
                borderRadius: 10,
              }}
            >
              <TouchableOpacity
                style={{
                  marginTop: 15,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
                onPress={() => {SetVisible(!Visible)}}
              >
                <Text style={{ color: COLORS.light_green, marginLeft: 10 }}>
                  Shared & Purchased
                </Text>
                <AntDesign
                  name={!Visible?"downcircle":"upcircle"}
                  style={{ marginRight: 15 }}
                  size={20}
                  color={COLORS.light_green}
                />
              </TouchableOpacity>
              {(Visible)?
              <ScrollView style={{ flexDirection: "column", marginTop: 20 }}>
                  {
                  (CodeUsers)?CodeUsers.map((user)=>{
                    return (<View
                    style={{
                      padding: 5,
                      borderWidth: 2,
                      borderColor: COLORS.light_green,
                      borderRadius: 10,
                      marginBottom:10
                    }}
                    id={user.id}
                  >
                  
                    <Text style={{ color: COLORS.white, fontSize: 20 }}>
                      {user.user_reward_by_whom}
                    </Text>
                    <Text style={{ color: COLORS.light_yello, marginTop: 10 }}>
                    {user.status}
                    </Text>
                  </View>)
                  }):<></>
                }
              
              
             
              
            </ScrollView>:<></>
            }
              
            </View>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({});
