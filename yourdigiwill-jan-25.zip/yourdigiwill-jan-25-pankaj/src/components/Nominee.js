import { StyleSheet, Text, View, TouchableOpacity, Button, Image, ActivityIndicator, KeyboardAvoidingView, Platform, SafeAreaView } from 'react-native';
import Header from './Header';
import { COLORS } from './colors';

export default function Nominee({ navigation }) {
  return   <Header  text='Nominees' navigation={navigation}/>
}