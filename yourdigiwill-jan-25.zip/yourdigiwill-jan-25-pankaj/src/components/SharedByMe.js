import { StyleSheet, Text, View ,Button,Image,TouchableOpacity,Dimensions,ScrollView} from 'react-native';
import Header from './Header';
import { SafeAreaView } from 'react-native-safe-area-context';
import {useState,useRef,useEffect,useContext} from 'react'
import { PostCallWithErrorResponse, simpleGetCallWithErrorResponse } from '../../api/ApiServices';
import ApiConfig from '../../api/ApiConfig';
import { AppContext } from '../../user/AppContext';
import Spinner from 'react-native-loading-spinner-overlay';
import  FontAwesome  from 'react-native-vector-icons/FontAwesome'; 
import  AntDesign  from 'react-native-vector-icons/AntDesign'; 
import CheckBox from 'react-native-check-box';
import LinearGradient from 'react-native-linear-gradient';
import { COLORS } from './colors';

export default function SharedByMe({navigation}) {

    const [sharedbymenominees,setSharedbymeNominees]=useState([])
    const [loading,setLoading]=useState(true)
    const [selectednominees,setselectedsetNominees]=useState([])
    const {token}=useContext(AppContext)



    const handleSubmit = ()=>{
        console.log(selectednominees)
        PostCallWithErrorResponse(ApiConfig.ADD_SHARED_BY_ME , 
            {nominee_array:selectednominees,token:token}
               )
             .then((result) => {
               console.log(result)
               if (result.json.status) {
                //  setData({name:"",relationship:"",age:"",email:"",phone:"",address:"",gender:""})
                //  getAllAssets()
                //  bottomsheet.current.close()
                navigation.navigate('Linked',{isadded:true})
               }
             })
             .catch((error) => {
               console.log("api response", error);
           
             });

    }


    const getAllSharedByMeNominees = ()=>{

        simpleGetCallWithErrorResponse(ApiConfig.LINKED_NOMINEES,{token:token})
          .then((data) => {
              
            if (data) {
                console.log(data)
                setSharedbymeNominees(data.json.data)
              setLoading(false)
            }
          })
          .catch((error) => {
            console.log("api response", error);
      
          });
      
      }



useEffect(()=>{

 
    getAllSharedByMeNominees()
    
    },[])
    

  return (
    <SafeAreaView
    style={{backgroundColor:'black',flex:1}}

  >
<View style={{ backgroundColor: "#252836",height:50,alignItems:'center',justifyContent:'space-between',flexDirection:'row',marginBottom:10}}>
<TouchableOpacity onPress={() => navigation.navigate("Home")}>
<AntDesign name='left' size={30} color='#FFFFFF' style={{marginRight:2}}></AntDesign>
</TouchableOpacity>
        <Text
          style={{ fontFamily: "System", fontSize: 22, color: "#FFFFFF" ,}}
        >
  Select Nominees
        </Text>
 <View></View>
        </View>

        <ScrollView style={{flex:0.2}}>
        {
          sharedbymenominees.length !=0 ? 
   sharedbymenominees.map((single)=>{
return (
  <View
  style={{
    width: Dimensions.get("screen").width - 32,
    backgroundColor: "#1F1D2B",
    height: 70,
    marginLeft: 16,
    marginRight: 16,
    marginTop: 10,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "space-between",
    flex: 1,
    flexDirection: "row",
  }}
>
  <View style={{ 
        width:40,
        height:40,
        borderRadius:40,
        borderWidth:2,
        borderColor:COLORS.light_green,
        marginLeft:10
        }}>
    <Text
      style={{
        fontFamily: "System",
        fontSize: 22,
        color: "#FFFFFF",
        marginLeft: 10,
        marginTop:5
       
      }}
    >
      {single.name[0]}
    </Text>
  </View>
  <Text
    style={{
      fontFamily: "Roboto-Regular",
      fontSize: 17,
      color: "#FFFFFF",
    }}
  >
    {single.name}
  </Text>
  <View>
  <CheckBox
          style={styles.checkbox}
          isChecked={selectednominees.indexOf(single.id) > -1 ? true : false}
          onClick={()=> { selectednominees.indexOf(single.id) > -1? setselectedsetNominees(selectednominees.filter((value)=>value!=single.id)): setselectedsetNominees(  [...selectednominees,single.id]) ;console.log(selectednominees)  }}
          // color={true ? '#0CFEBC' : undefined}
          checkBoxColor="#0CFEBC"
        />

  </View>

</View>
)


          })
          :
          
          <Spinner visible={loading}/>
        }
      

      </ScrollView>


      <LinearGradient
       colors={['#FFBF35','#FFA900']}
       style={{width:65,borderRadius:50,flex:0.1,left:'80%',bottom:'1%'}}
      
       >
       <TouchableOpacity
                onPress={() => handleSubmit()}
                style={{
                 width:65,
                    height:65,
                    borderRadius:50,
                    color:'#FFFFFF',
                alignItems:'center',
                 justifyContent:'center', 
             
                  
               }}
                >
                  
                  <AntDesign name="arrowright" size={24} color="black" />               
              </TouchableOpacity>
       </LinearGradient>


</SafeAreaView>
  )
}

const styles = StyleSheet.create({
    checkbox:{

        marginRight:5,
        color:'#0CFEBC',
        borderColor:'#0CFEBC'
    }


})