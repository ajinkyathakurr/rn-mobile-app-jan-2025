--
-- PostgreSQL database dump
--

-- Dumped from database version 12.11 (Ubuntu 12.11-0ubuntu0.20.04.1)
-- Dumped by pg_dump version 12.11 (Ubuntu 12.11-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: get_in_touch; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.get_in_touch (
    id integer NOT NULL,
    name character varying(100),
    email character varying(100),
    message text,
    user_id integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.get_in_touch OWNER TO newuser;

--
-- Name: get_in_touch_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.get_in_touch_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.get_in_touch_id_seq OWNER TO newuser;

--
-- Name: get_in_touch_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.get_in_touch_id_seq OWNED BY public.get_in_touch.id;


--
-- Name: group_channel_members; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_channel_members (
    member_id integer NOT NULL,
    member_user_id integer,
    member_group_id integer,
    member_created_at timestamp without time zone,
    member_status character varying DEFAULT 'active'::character varying,
    member_channel_id integer
);


ALTER TABLE public.group_channel_members OWNER TO newuser;

--
-- Name: TABLE group_channel_members; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON TABLE public.group_channel_members IS 'only for Private channels';


--
-- Name: group_channel_members_member_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_channel_members_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_channel_members_member_id_seq OWNER TO newuser;

--
-- Name: group_channel_members_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_channel_members_member_id_seq OWNED BY public.group_channel_members.member_id;


--
-- Name: group_channels; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_channels (
    channel_id integer NOT NULL,
    channel_name character varying(500),
    channel_description text,
    channel_group_id integer,
    channel_status character varying DEFAULT 'active'::character varying,
    channel_owner integer,
    channel_created_at timestamp without time zone,
    channel_updated_at timestamp without time zone,
    channel_type character varying DEFAULT 'standard'::character varying
);


ALTER TABLE public.group_channels OWNER TO newuser;

--
-- Name: TABLE group_channels; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON TABLE public.group_channels IS 'sub groups';


--
-- Name: COLUMN group_channels.channel_type; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON COLUMN public.group_channels.channel_type IS 'standard/private';


--
-- Name: group_channels_channel_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_channels_channel_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_channels_channel_id_seq OWNER TO newuser;

--
-- Name: group_channels_channel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_channels_channel_id_seq OWNED BY public.group_channels.channel_id;


--
-- Name: group_chat; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_chat (
    group_chat_id integer NOT NULL,
    group_chat_room character varying(100),
    group_chat_created_at timestamp with time zone,
    group_chat_status character varying DEFAULT 'active'::character varying,
    group_chat_channel_id integer,
    group_chat_group_id integer,
    group_chat_last_updated timestamp with time zone
);


ALTER TABLE public.group_chat OWNER TO newuser;

--
-- Name: TABLE group_chat; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON TABLE public.group_chat IS 'group channel chats';


--
-- Name: group_chat_conversation; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_chat_conversation (
    conversation_id integer NOT NULL,
    conversation_from integer,
    conversation_message text,
    conversation_datetime timestamp with time zone,
    conversation_status character varying DEFAULT 'active'::character varying,
    conversation_group_chat_id integer,
    conversation_type character varying(50)
);


ALTER TABLE public.group_chat_conversation OWNER TO newuser;

--
-- Name: COLUMN group_chat_conversation.conversation_type; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON COLUMN public.group_chat_conversation.conversation_type IS 'message/poll';


--
-- Name: group_chat_conversation_conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_chat_conversation_conversation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_chat_conversation_conversation_id_seq OWNER TO newuser;

--
-- Name: group_chat_conversation_conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_chat_conversation_conversation_id_seq OWNED BY public.group_chat_conversation.conversation_id;


--
-- Name: group_chat_files; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_chat_files (
    file_id integer NOT NULL,
    file_path character varying(500),
    file_real_name character(300),
    file_created_at timestamp with time zone,
    file_chat_id integer,
    file_status character varying DEFAULT 'active'::character varying,
    file_conversation_id integer,
    file_type character varying(50)
);


ALTER TABLE public.group_chat_files OWNER TO newuser;

--
-- Name: group_chat_files_file_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_chat_files_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_chat_files_file_id_seq OWNER TO newuser;

--
-- Name: group_chat_files_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_chat_files_file_id_seq OWNED BY public.group_chat_files.file_id;


--
-- Name: group_chat_group_chat_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_chat_group_chat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_chat_group_chat_id_seq OWNER TO newuser;

--
-- Name: group_chat_group_chat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_chat_group_chat_id_seq OWNED BY public.group_chat.group_chat_id;


--
-- Name: group_chat_notification; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_chat_notification (
    chat_notification_id integer NOT NULL,
    chat_notification_chat_id integer,
    chat_notification_from_id integer,
    chat_notification_to_id integer,
    chat_notification_date timestamp without time zone,
    chat_notification_status character varying DEFAULT 'unread'::character varying,
    chat_notification_conversation_id integer
);


ALTER TABLE public.group_chat_notification OWNER TO newuser;

--
-- Name: group_chat_notification_chat_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_chat_notification_chat_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_chat_notification_chat_notification_id_seq OWNER TO newuser;

--
-- Name: group_chat_notification_chat_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_chat_notification_chat_notification_id_seq OWNED BY public.group_chat_notification.chat_notification_id;


--
-- Name: group_hide; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_hide (
    id integer NOT NULL,
    group_id integer,
    user_id integer,
    created_at timestamp without time zone
);


ALTER TABLE public.group_hide OWNER TO newuser;

--
-- Name: TABLE group_hide; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON TABLE public.group_hide IS 'hidden groups for each users';


--
-- Name: group_hide_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_hide_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_hide_id_seq OWNER TO newuser;

--
-- Name: group_hide_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_hide_id_seq OWNED BY public.group_hide.id;


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_members (
    member_id integer NOT NULL,
    member_user_id integer,
    member_group_id integer,
    member_created_at timestamp without time zone,
    member_status character varying(20) DEFAULT 'active'::character varying,
    member_role character varying DEFAULT 'member'::character varying
);


ALTER TABLE public.group_members OWNER TO newuser;

--
-- Name: group_members_member_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_members_member_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_members_member_id_seq OWNER TO newuser;

--
-- Name: group_members_member_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_members_member_id_seq OWNED BY public.group_members.member_id;


--
-- Name: group_poll_options; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_poll_options (
    option_id integer NOT NULL,
    option_poll_id integer,
    option_value text,
    option_status character varying(50) DEFAULT 'active'::character varying,
    option_created_at timestamp without time zone,
    option_updated_at timestamp without time zone
);


ALTER TABLE public.group_poll_options OWNER TO newuser;

--
-- Name: group_poll_options_option_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_poll_options_option_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_poll_options_option_id_seq OWNER TO newuser;

--
-- Name: group_poll_options_option_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_poll_options_option_id_seq OWNED BY public.group_poll_options.option_id;


--
-- Name: group_poll_vote; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_poll_vote (
    vote_id integer NOT NULL,
    vote_poll_id integer,
    vote_poll_option integer,
    vote_user_id integer,
    vote_created_at timestamp without time zone,
    vote_updated_at timestamp without time zone
);


ALTER TABLE public.group_poll_vote OWNER TO newuser;

--
-- Name: group_poll_vote_vote_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_poll_vote_vote_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_poll_vote_vote_id_seq OWNER TO newuser;

--
-- Name: group_poll_vote_vote_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_poll_vote_vote_id_seq OWNED BY public.group_poll_vote.vote_id;


--
-- Name: group_polls; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.group_polls (
    poll_id integer NOT NULL,
    poll_question text,
    poll_created_user integer,
    poll_status character varying,
    poll_created_at timestamp without time zone,
    poll_updated_at timestamp without time zone,
    poll_conversation_id integer
);


ALTER TABLE public.group_polls OWNER TO newuser;

--
-- Name: group_polls_poll_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.group_polls_poll_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.group_polls_poll_id_seq OWNER TO newuser;

--
-- Name: group_polls_poll_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.group_polls_poll_id_seq OWNED BY public.group_polls.poll_id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.groups (
    group_id integer NOT NULL,
    group_name character varying(500),
    group_description text,
    group_image character varying(100),
    group_status character varying DEFAULT 'active'::character varying,
    group_created_at timestamp without time zone,
    group_updated_at timestamp without time zone,
    group_owner integer
);


ALTER TABLE public.groups OWNER TO newuser;

--
-- Name: groups_group_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.groups_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.groups_group_id_seq OWNER TO newuser;

--
-- Name: groups_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.groups_group_id_seq OWNED BY public.groups.group_id;


--
-- Name: pages; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.pages (
    page_id integer NOT NULL,
    page_title character varying(500),
    page_content text,
    page_updated_at timestamp without time zone,
    page_created_at timestamp without time zone,
    page_name character varying(50),
    page_status character varying(50) DEFAULT 'active'::character varying
);


ALTER TABLE public.pages OWNER TO newuser;

--
-- Name: TABLE pages; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON TABLE public.pages IS 'Static pages';


--
-- Name: pages_page_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.pages_page_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pages_page_id_seq OWNER TO newuser;

--
-- Name: pages_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.pages_page_id_seq OWNED BY public.pages.page_id;


--
-- Name: private_chat; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.private_chat (
    private_chat_id integer NOT NULL,
    private_chat_from integer,
    private_chat_to integer,
    private_chat_room character varying(100),
    private_chat_created_at timestamp without time zone,
    private_chat_status character varying(50) DEFAULT 'active'::character varying,
    private_chat_from_status character varying(50) DEFAULT 'active'::character varying,
    private_chat_to_status character varying(50) DEFAULT 'active'::character varying,
    private_chat_last_updated timestamp without time zone
);


ALTER TABLE public.private_chat OWNER TO newuser;

--
-- Name: TABLE private_chat; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON TABLE public.private_chat IS 'one to one chat';


--
-- Name: private_chat_conversation; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.private_chat_conversation (
    conversation_id integer NOT NULL,
    conversation_from integer,
    conversation_message text,
    conversation_datetime timestamp without time zone,
    conversation_status character varying(50) DEFAULT 'active'::character varying,
    conversation_read_status character varying(50) DEFAULT 'unread'::character varying,
    conversation_to integer,
    conversation_chat_id integer
);


ALTER TABLE public.private_chat_conversation OWNER TO newuser;

--
-- Name: private_chat_conversation_conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.private_chat_conversation_conversation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.private_chat_conversation_conversation_id_seq OWNER TO newuser;

--
-- Name: private_chat_conversation_conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.private_chat_conversation_conversation_id_seq OWNED BY public.private_chat_conversation.conversation_id;


--
-- Name: private_chat_files; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.private_chat_files (
    file_id integer NOT NULL,
    file_path character varying(500),
    file_real_name character varying(500),
    file_created_at timestamp without time zone,
    file_chat_id integer,
    file_status character varying(50) DEFAULT 'active'::character varying,
    file_conversation_id integer,
    file_type character varying(100)
);


ALTER TABLE public.private_chat_files OWNER TO newuser;

--
-- Name: private_chat_files_file_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.private_chat_files_file_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.private_chat_files_file_id_seq OWNER TO newuser;

--
-- Name: private_chat_files_file_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.private_chat_files_file_id_seq OWNED BY public.private_chat_files.file_id;


--
-- Name: private_chat_notification; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.private_chat_notification (
    chat_notification_id integer NOT NULL,
    chat_notification_chat_id integer,
    chat_notification_from_id integer,
    chat_notification_to_id integer,
    chat_notification_date timestamp without time zone,
    chat_notification_status character varying(50) DEFAULT 'unread'::character varying,
    chat_notification_conversation_id integer
);


ALTER TABLE public.private_chat_notification OWNER TO newuser;

--
-- Name: private_chat_notification_chat_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.private_chat_notification_chat_notification_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.private_chat_notification_chat_notification_id_seq OWNER TO newuser;

--
-- Name: private_chat_notification_chat_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.private_chat_notification_chat_notification_id_seq OWNED BY public.private_chat_notification.chat_notification_id;


--
-- Name: private_chat_pin; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.private_chat_pin (
    pin_id integer NOT NULL,
    pin_chat_id integer,
    pin_user_id integer,
    pin_created_at timestamp without time zone
);


ALTER TABLE public.private_chat_pin OWNER TO newuser;

--
-- Name: private_chat_pin_pin_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.private_chat_pin_pin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.private_chat_pin_pin_id_seq OWNER TO newuser;

--
-- Name: private_chat_pin_pin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.private_chat_pin_pin_id_seq OWNED BY public.private_chat_pin.pin_id;


--
-- Name: private_chat_private_chat_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.private_chat_private_chat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.private_chat_private_chat_id_seq OWNER TO newuser;

--
-- Name: private_chat_private_chat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.private_chat_private_chat_id_seq OWNED BY public.private_chat.private_chat_id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.settings (
    settings_id integer NOT NULL,
    settings_user_id integer,
    settings_theme character varying DEFAULT 'light'::character varying,
    settings_enable_calls boolean DEFAULT true,
    settings_play_call_sound boolean DEFAULT true,
    settings_enable_notification boolean DEFAULT true,
    settings_notification_calls boolean DEFAULT true,
    settings_updated_at timestamp without time zone,
    settings_microphone boolean DEFAULT true,
    settings_zoom_level character varying(20) DEFAULT 100,
    settings_spell_check boolean DEFAULT false,
    settings_play_notification_sound boolean DEFAULT true
);


ALTER TABLE public.settings OWNER TO newuser;

--
-- Name: COLUMN settings.settings_theme; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON COLUMN public.settings.settings_theme IS 'light/dark';


--
-- Name: COLUMN settings.settings_zoom_level; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON COLUMN public.settings.settings_zoom_level IS 'in %';


--
-- Name: settings_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.settings_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_settings_id_seq OWNER TO newuser;

--
-- Name: settings_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.settings_settings_id_seq OWNED BY public.settings.settings_id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public."user" (
    user_id integer NOT NULL,
    user_name character varying(200),
    user_email_id character varying(100),
    user_phone character varying(50),
    user_educational_institute character varying(300),
    user_password character varying(100),
    user_status character varying DEFAULT 'inactive'::character varying,
    user_dob date,
    user_nationality character varying(100),
    user_address text,
    user_created_at timestamp without time zone,
    user_updated_at timestamp without time zone,
    user_profile_image character varying(300),
    user_token character varying(300),
    user_login_status character varying(30) DEFAULT 'online'::character varying,
    user_gender character varying(30),
    user_designation character varying(300),
    user_department character varying(300),
    user_shift character varying(30)
);


ALTER TABLE public."user" OWNER TO newuser;

--
-- Name: user_login_log; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.user_login_log (
    login_log_id integer NOT NULL,
    login_log_user_id integer,
    login_log_mode character varying(50),
    login_log_imei_ip character varying,
    login_log_datetime timestamp without time zone,
    login_log_status character varying DEFAULT 'online'::character varying
);


ALTER TABLE public.user_login_log OWNER TO newuser;

--
-- Name: TABLE user_login_log; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON TABLE public.user_login_log IS 'User Login Log';


--
-- Name: COLUMN user_login_log.login_log_mode; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON COLUMN public.user_login_log.login_log_mode IS 'web/app';


--
-- Name: user_login_log_login_log_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.user_login_log_login_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_login_log_login_log_id_seq OWNER TO newuser;

--
-- Name: user_login_log_login_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.user_login_log_login_log_id_seq OWNED BY public.user_login_log.login_log_id;


--
-- Name: user_otp; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.user_otp (
    otp_id integer NOT NULL,
    otp_user_id integer,
    otp_type character varying(50),
    otp_code character varying(100),
    otp_status character varying DEFAULT 'not verified'::character varying,
    otp_created_at timestamp without time zone
);


ALTER TABLE public.user_otp OWNER TO newuser;

--
-- Name: COLUMN user_otp.otp_type; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON COLUMN public.user_otp.otp_type IS 'email/sms';


--
-- Name: COLUMN user_otp.otp_status; Type: COMMENT; Schema: public; Owner: newuser
--

COMMENT ON COLUMN public.user_otp.otp_status IS 'not verified/ verified';


--
-- Name: user_otp_otp_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.user_otp_otp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_otp_otp_id_seq OWNER TO newuser;

--
-- Name: user_otp_otp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.user_otp_otp_id_seq OWNED BY public.user_otp.otp_id;


--
-- Name: user_token; Type: TABLE; Schema: public; Owner: newuser
--

CREATE TABLE public.user_token (
    token_id integer NOT NULL,
    token_user_id integer,
    token_code character varying(300),
    token_status character varying(50) DEFAULT 'not verified'::character varying,
    token_created_at timestamp without time zone,
    token_updated_at timestamp without time zone
);


ALTER TABLE public.user_token OWNER TO newuser;

--
-- Name: user_token_token_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.user_token_token_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_token_token_id_seq OWNER TO newuser;

--
-- Name: user_token_token_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.user_token_token_id_seq OWNED BY public.user_token.token_id;


--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: newuser
--

CREATE SEQUENCE public.user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_user_id_seq OWNER TO newuser;

--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: newuser
--

ALTER SEQUENCE public.user_user_id_seq OWNED BY public."user".user_id;


--
-- Name: get_in_touch id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.get_in_touch ALTER COLUMN id SET DEFAULT nextval('public.get_in_touch_id_seq'::regclass);


--
-- Name: group_channel_members member_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channel_members ALTER COLUMN member_id SET DEFAULT nextval('public.group_channel_members_member_id_seq'::regclass);


--
-- Name: group_channels channel_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channels ALTER COLUMN channel_id SET DEFAULT nextval('public.group_channels_channel_id_seq'::regclass);


--
-- Name: group_chat group_chat_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat ALTER COLUMN group_chat_id SET DEFAULT nextval('public.group_chat_group_chat_id_seq'::regclass);


--
-- Name: group_chat_conversation conversation_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_conversation ALTER COLUMN conversation_id SET DEFAULT nextval('public.group_chat_conversation_conversation_id_seq'::regclass);


--
-- Name: group_chat_files file_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_files ALTER COLUMN file_id SET DEFAULT nextval('public.group_chat_files_file_id_seq'::regclass);


--
-- Name: group_chat_notification chat_notification_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_notification ALTER COLUMN chat_notification_id SET DEFAULT nextval('public.group_chat_notification_chat_notification_id_seq'::regclass);


--
-- Name: group_hide id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_hide ALTER COLUMN id SET DEFAULT nextval('public.group_hide_id_seq'::regclass);


--
-- Name: group_members member_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_members ALTER COLUMN member_id SET DEFAULT nextval('public.group_members_member_id_seq'::regclass);


--
-- Name: group_poll_options option_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_options ALTER COLUMN option_id SET DEFAULT nextval('public.group_poll_options_option_id_seq'::regclass);


--
-- Name: group_poll_vote vote_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_vote ALTER COLUMN vote_id SET DEFAULT nextval('public.group_poll_vote_vote_id_seq'::regclass);


--
-- Name: group_polls poll_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_polls ALTER COLUMN poll_id SET DEFAULT nextval('public.group_polls_poll_id_seq'::regclass);


--
-- Name: groups group_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.groups ALTER COLUMN group_id SET DEFAULT nextval('public.groups_group_id_seq'::regclass);


--
-- Name: pages page_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.pages ALTER COLUMN page_id SET DEFAULT nextval('public.pages_page_id_seq'::regclass);


--
-- Name: private_chat private_chat_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat ALTER COLUMN private_chat_id SET DEFAULT nextval('public.private_chat_private_chat_id_seq'::regclass);


--
-- Name: private_chat_conversation conversation_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_conversation ALTER COLUMN conversation_id SET DEFAULT nextval('public.private_chat_conversation_conversation_id_seq'::regclass);


--
-- Name: private_chat_files file_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_files ALTER COLUMN file_id SET DEFAULT nextval('public.private_chat_files_file_id_seq'::regclass);


--
-- Name: private_chat_notification chat_notification_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_notification ALTER COLUMN chat_notification_id SET DEFAULT nextval('public.private_chat_notification_chat_notification_id_seq'::regclass);


--
-- Name: private_chat_pin pin_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_pin ALTER COLUMN pin_id SET DEFAULT nextval('public.private_chat_pin_pin_id_seq'::regclass);


--
-- Name: settings settings_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.settings ALTER COLUMN settings_id SET DEFAULT nextval('public.settings_settings_id_seq'::regclass);


--
-- Name: user user_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public."user" ALTER COLUMN user_id SET DEFAULT nextval('public.user_user_id_seq'::regclass);


--
-- Name: user_login_log login_log_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.user_login_log ALTER COLUMN login_log_id SET DEFAULT nextval('public.user_login_log_login_log_id_seq'::regclass);


--
-- Name: user_otp otp_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.user_otp ALTER COLUMN otp_id SET DEFAULT nextval('public.user_otp_otp_id_seq'::regclass);


--
-- Name: user_token token_id; Type: DEFAULT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.user_token ALTER COLUMN token_id SET DEFAULT nextval('public.user_token_token_id_seq'::regclass);


--
-- Name: get_in_touch get_in_touch_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.get_in_touch
    ADD CONSTRAINT get_in_touch_pkey PRIMARY KEY (id);


--
-- Name: group_channel_members group_channel_members_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channel_members
    ADD CONSTRAINT group_channel_members_pkey PRIMARY KEY (member_id);


--
-- Name: group_channels group_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channels
    ADD CONSTRAINT group_channels_pkey PRIMARY KEY (channel_id);


--
-- Name: group_chat_conversation group_chat_conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_conversation
    ADD CONSTRAINT group_chat_conversation_pkey PRIMARY KEY (conversation_id);


--
-- Name: group_chat_files group_chat_files_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_files
    ADD CONSTRAINT group_chat_files_pkey PRIMARY KEY (file_id);


--
-- Name: group_chat_notification group_chat_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_notification
    ADD CONSTRAINT group_chat_notification_pkey PRIMARY KEY (chat_notification_id);


--
-- Name: group_chat group_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat
    ADD CONSTRAINT group_chat_pkey PRIMARY KEY (group_chat_id);


--
-- Name: group_hide group_hide_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_hide
    ADD CONSTRAINT group_hide_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (member_id);


--
-- Name: group_poll_options group_poll_options_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_options
    ADD CONSTRAINT group_poll_options_pkey PRIMARY KEY (option_id);


--
-- Name: group_poll_vote group_poll_vote_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_vote
    ADD CONSTRAINT group_poll_vote_pkey PRIMARY KEY (vote_id);


--
-- Name: group_polls group_polls_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_polls
    ADD CONSTRAINT group_polls_pkey PRIMARY KEY (poll_id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (group_id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (page_id);


--
-- Name: private_chat_conversation private_chat_conversation_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_conversation
    ADD CONSTRAINT private_chat_conversation_pkey PRIMARY KEY (conversation_id);


--
-- Name: private_chat_files private_chat_files_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_files
    ADD CONSTRAINT private_chat_files_pkey PRIMARY KEY (file_id);


--
-- Name: private_chat_notification private_chat_notification_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_notification
    ADD CONSTRAINT private_chat_notification_pkey PRIMARY KEY (chat_notification_id);


--
-- Name: private_chat_pin private_chat_pin_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_pin
    ADD CONSTRAINT private_chat_pin_pkey PRIMARY KEY (pin_id);


--
-- Name: private_chat private_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat
    ADD CONSTRAINT private_chat_pkey PRIMARY KEY (private_chat_id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (settings_id);


--
-- Name: user_login_log user_login_log_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.user_login_log
    ADD CONSTRAINT user_login_log_pkey PRIMARY KEY (login_log_id);


--
-- Name: user_otp user_otp_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.user_otp
    ADD CONSTRAINT user_otp_pkey PRIMARY KEY (otp_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: user_token user_token_pkey; Type: CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.user_token
    ADD CONSTRAINT user_token_pkey PRIMARY KEY (token_id);


--
-- Name: group_channel_members group_channel_members_member_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channel_members
    ADD CONSTRAINT group_channel_members_member_channel_id_fkey FOREIGN KEY (member_channel_id) REFERENCES public.group_channels(channel_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_channel_members group_channel_members_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channel_members
    ADD CONSTRAINT group_channel_members_member_group_id_fkey FOREIGN KEY (member_group_id) REFERENCES public.groups(group_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_channel_members group_channel_members_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channel_members
    ADD CONSTRAINT group_channel_members_member_user_id_fkey FOREIGN KEY (member_user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_channels group_channels_channel_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_channels
    ADD CONSTRAINT group_channels_channel_group_id_fkey FOREIGN KEY (channel_group_id) REFERENCES public.groups(group_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat_conversation group_chat_conversation_conversation_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_conversation
    ADD CONSTRAINT group_chat_conversation_conversation_from_fkey FOREIGN KEY (conversation_from) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat_conversation group_chat_conversation_conversation_group_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_conversation
    ADD CONSTRAINT group_chat_conversation_conversation_group_chat_id_fkey FOREIGN KEY (conversation_group_chat_id) REFERENCES public.group_chat(group_chat_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat_files group_chat_files_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_files
    ADD CONSTRAINT group_chat_files_file_chat_id_fkey FOREIGN KEY (file_chat_id) REFERENCES public.group_chat(group_chat_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat_files group_chat_files_file_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_files
    ADD CONSTRAINT group_chat_files_file_conversation_id_fkey FOREIGN KEY (file_conversation_id) REFERENCES public.group_chat_conversation(conversation_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat group_chat_group_chat_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat
    ADD CONSTRAINT group_chat_group_chat_channel_id_fkey FOREIGN KEY (group_chat_channel_id) REFERENCES public.group_channels(channel_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat group_chat_group_chat_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat
    ADD CONSTRAINT group_chat_group_chat_group_id_fkey FOREIGN KEY (group_chat_group_id) REFERENCES public.groups(group_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat_notification group_chat_notification_chat_notification_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_notification
    ADD CONSTRAINT group_chat_notification_chat_notification_chat_id_fkey FOREIGN KEY (chat_notification_chat_id) REFERENCES public.group_chat(group_chat_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_chat_notification group_chat_notification_chat_notification_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_chat_notification
    ADD CONSTRAINT group_chat_notification_chat_notification_conversation_id_fkey FOREIGN KEY (chat_notification_conversation_id) REFERENCES public.group_chat_conversation(conversation_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_hide group_hide_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_hide
    ADD CONSTRAINT group_hide_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(group_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_hide group_hide_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_hide
    ADD CONSTRAINT group_hide_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_members group_members_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_member_group_id_fkey FOREIGN KEY (member_group_id) REFERENCES public.groups(group_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_members group_members_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_member_user_id_fkey FOREIGN KEY (member_user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_poll_options group_poll_options_option_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_options
    ADD CONSTRAINT group_poll_options_option_poll_id_fkey FOREIGN KEY (option_poll_id) REFERENCES public.group_polls(poll_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_poll_vote group_poll_vote_vote_poll_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_vote
    ADD CONSTRAINT group_poll_vote_vote_poll_id_fkey FOREIGN KEY (vote_poll_id) REFERENCES public.group_polls(poll_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_poll_vote group_poll_vote_vote_poll_option_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_vote
    ADD CONSTRAINT group_poll_vote_vote_poll_option_fkey FOREIGN KEY (vote_poll_option) REFERENCES public.group_poll_options(option_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_poll_vote group_poll_vote_vote_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_poll_vote
    ADD CONSTRAINT group_poll_vote_vote_user_id_fkey FOREIGN KEY (vote_user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_polls group_polls_poll_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_polls
    ADD CONSTRAINT group_polls_poll_conversation_id_fkey FOREIGN KEY (poll_conversation_id) REFERENCES public.group_chat_conversation(conversation_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_polls group_polls_poll_created_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.group_polls
    ADD CONSTRAINT group_polls_poll_created_user_fkey FOREIGN KEY (poll_created_user) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_conversation private_chat_conversation_conversation_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_conversation
    ADD CONSTRAINT private_chat_conversation_conversation_chat_id_fkey FOREIGN KEY (conversation_chat_id) REFERENCES public.private_chat(private_chat_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_conversation private_chat_conversation_conversation_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_conversation
    ADD CONSTRAINT private_chat_conversation_conversation_from_fkey FOREIGN KEY (conversation_from) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_conversation private_chat_conversation_conversation_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_conversation
    ADD CONSTRAINT private_chat_conversation_conversation_to_fkey FOREIGN KEY (conversation_to) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_files private_chat_files_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_files
    ADD CONSTRAINT private_chat_files_file_chat_id_fkey FOREIGN KEY (file_chat_id) REFERENCES public.private_chat(private_chat_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_files private_chat_files_file_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_files
    ADD CONSTRAINT private_chat_files_file_conversation_id_fkey FOREIGN KEY (file_conversation_id) REFERENCES public.private_chat_conversation(conversation_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_notification private_chat_notification_chat_notification_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_notification
    ADD CONSTRAINT private_chat_notification_chat_notification_chat_id_fkey FOREIGN KEY (chat_notification_chat_id) REFERENCES public.private_chat(private_chat_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_notification private_chat_notification_chat_notification_conversation_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_notification
    ADD CONSTRAINT private_chat_notification_chat_notification_conversation_i_fkey FOREIGN KEY (chat_notification_conversation_id) REFERENCES public.private_chat_conversation(conversation_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_pin private_chat_pin_pin_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_pin
    ADD CONSTRAINT private_chat_pin_pin_chat_id_fkey FOREIGN KEY (pin_chat_id) REFERENCES public.private_chat(private_chat_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat_pin private_chat_pin_pin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat_pin
    ADD CONSTRAINT private_chat_pin_pin_user_id_fkey FOREIGN KEY (pin_user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat private_chat_private_chat_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat
    ADD CONSTRAINT private_chat_private_chat_from_fkey FOREIGN KEY (private_chat_from) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: private_chat private_chat_private_chat_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.private_chat
    ADD CONSTRAINT private_chat_private_chat_to_fkey FOREIGN KEY (private_chat_to) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings settings_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_settings_user_id_fkey FOREIGN KEY (settings_user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_otp user_otp_otp_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: newuser
--

ALTER TABLE ONLY public.user_otp
    ADD CONSTRAINT user_otp_otp_user_id_fkey FOREIGN KEY (otp_user_id) REFERENCES public."user"(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

