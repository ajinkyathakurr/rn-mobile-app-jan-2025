export
    const BASE_URL = "https://prod.yourdigiwill.com/api/";

const ApiConfig = {
// Login AND SIGNUP Related APIS
    GET_MPIN_STATUS:BASE_URL+"get_mpin_status",

    GET_ALL_ASSETS_LOGO: BASE_URL + "dashboard_sub_menu",
    DIGIWILL_GENERATE_OTP:BASE_URL +"generate_otp",
    DIGIWILL_VERIFY_OTP:BASE_URL + "verify_otp",
    GET_ALL_NOMINEES:BASE_URL + "add_nominee",
    DIGIWILL_ADD_NOMINEE:BASE_URL + "add_nominee",
    GET_ALL_SHAREDBYME_NOMINEES:BASE_URL+"get_shared_by_me",
    LINKED_NOMINEES:BASE_URL+"linked_nominees",
    ADD_SHARED_BY_ME:BASE_URL +"get_shared_by_me",
    GET_ALL_NOTIFICATIONS:BASE_URL + "inapp-notifications",
    GET_ALL_PLANS:BASE_URL+"plan",
    DIGIWILL_START_PAYMENT:BASE_URL+"pay",
    DIGIWILL_VERIFY_PAYMENT:BASE_URL+"success",
    SET_PIN:BASE_URL+"set_pin",
    CHANGE_PIN:BASE_URL+"change_mpin",
    GET_ALL_SUBSCRIPTION:BASE_URL+"get_subscriptions",
    CHECK_ALREADY_SUBSCRIBED:BASE_URL+"check_already_subscribed",
    GET_SHARED_ASSETS_AND_LIABLITY:BASE_URL+"check_assets",
    GET_ALL_ASSETS:BASE_URL+'get_all_assets',
    GET_ALL_REMINDERS:BASE_URL+ 'get_all_reminders_ios',
    Update_ALL_REMINDERS:BASE_URL+ 'get_all_reminders',
    SHARE_ASSET:BASE_URL+"share_assets",
    GET_SHARED_WITH_ME:BASE_URL+"get_shared_with_me",
    GET_SHARABLE_ASSETS:BASE_URL + "share_assets",
    GET_DISTRIBUTION:BASE_URL+"add_distribution_ios",
    GET_DISTRIBUTION_NOMINEE:BASE_URL+"get_nominees_for_distribution",
    ADD_DISTRIBUTION:BASE_URL+"add_distribution_ios",
    GENERATE_AADHAR_OTP:BASE_URL+"generate_aadhar_otp",
    GET_SUBSCRIPTION_DETAIL:BASE_URL+"get_subscription_detail",
    DIGIWILL_REMOVE_NOMINEE_FROM_ENSURANCE:BASE_URL+"remove_nominee_ensurance",
    SUBMIT_AADHAR_OTP:BASE_URL+"submit_aadhar_otp",
    VERIFY_PAN:BASE_URL+"verify_pan",
    DIGIWILL_ADD_ASSET:BASE_URL+"get_all_assets",
    DIGIWILL_USER_REGISTRATION:BASE_URL+"user_registration",
    DIGIWILL_REFEREL_VERIFICATION:BASE_URL+"verify_referral_code",

   GET_PROFILE:BASE_URL +"profile",
   SEND_EMAIL:BASE_URL + "dashboard_mail_verification",

   //communication
   GET_NOMINEE_COMMUNICATION:BASE_URL+"nominee_data_for_communication",
   AFTERLIFE_GENERATE_ORDER:BASE_URL+"afterlife",
   COMMUNICATION_VERIFICATION:BASE_URL+"afterlife_pay",
   AFTERYOU_PLAN_CHECK:BASE_URL+"check_active_communication",
   UNLINK_NOMINEE:BASE_URL+"get_shared_by_me",
   ADD_NOMINEE_AFTERYOU:BASE_URL+"add_nominee_afteryou",
   ADD_NOMINEE_FREQUENCY:BASE_URL+"add_frequency",


   //Expresswill
   CREATE_EXPRESSWILL:BASE_URL+"create_expresswill",
   GET_EXPRESSWILL:BASE_URL+"get_express_Will",
   DRAFT_DISTRIBUTION:BASE_URL+"draft_distribution",
   GET_EXPRESSWILL:BASE_URL+"get_express_Will",
   EXPRESS_WILL_PDF:BASE_URL+"express_will_pdf",
   GET_EXPRESS_WILL:BASE_URL+"get_express_Will",
   CHECK_EXPRESSWILL_ELIGIBILITY:BASE_URL+"check-expresswill-eligibility",
   ADD_WITNESS_DRAFT:BASE_URL+"add-witness_draft",
   ADD_SPEECH_DRAFT:BASE_URL+"expresswill_speech_draft",
   ADD_WITNESS:BASE_URL+"add-witness",
   ADD_SPEECH:BASE_URL+"expresswill_speech",
   ADD_DRAFT_EXECUTOR:BASE_URL+"add_executor_draft",
   ADD_EXECUTOR:BASE_URL+"add_executor",
   START_PAYMENT : BASE_URL+"express_will_payment",
   PAYMENT_SUCCESS_EXPRESSWILL:BASE_URL+"express_will_sucesspayment",
  
   //Succession Manager
   ADD_MANAGER:BASE_URL+"add_succession_manager",
   GET_MANAGERS:BASE_URL+"add_succession_manager",
   //E-sign
   INIT_ESIGN:BASE_URL+"initialize_esign",
   E_SIGN_STATUS:BASE_URL+'esign_status',

   //Subscription
   GET_ALL_PLANS:BASE_URL+"plan",
   ENSURANCE_PAY:BASE_URL+"pay",
   GET_SUBSCRIPTION_DETAIL:BASE_URL + "get_subscription_detail",
   ADD_NOMINEE_SUBSCRIPTION:BASE_URL+'add_nominee_ensurance',
   GET_NOMINEE_SUBSCRIPTION:BASE_URL+'get_nominee_ensurance',
   DOWNLOAD_INVOICE:BASE_URL+'get_subscriptions',
   // Asset/Liability update and delete
   DELETE_ASSET:BASE_URL+"fego_get_data",
   //    DELETE USER ACCOUNt 
   DELETE_USER_ACCOUNT:BASE_URL+'delete_account',

  // Referrals
   GET_REFFERAL_CODE:BASE_URL+"get_referral_code",
   GET_WITHDRAW_REWARD:BASE_URL+"withdraw_reward",
   WITHDRAW_REWARD:BASE_URL+"withdraw_reward",
   CHECK_REFERRAL_ELIGIBILITY:BASE_URL+"check_referral_eligibility",
   SHARED_PURCHASED:BASE_URL+"shared_and_purchsaed_by_referralcode"
}
export default ApiConfig;