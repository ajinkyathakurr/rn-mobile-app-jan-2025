import { StyleSheet, Text, View, Button, Image, ActivityIndicator, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useEffect, useState } from 'react';
import { ScrollView, TextInput, TouchableOpacity } from 'react-native-gesture-handler';
// import { AntDesign } from '@expo/vector-icons'; 
import Icon from 'react-native-vector-icons/AntDesign';

import AsyncStorage from '@react-native-async-storage/async-storage';

import { OtpInput } from "react-native-otp-entry";
import { showMessage, hideMessage } from "react-native-flash-message";
import ApiConfig from './api/ApiConfig';
import { PostCallWithErrorResponse } from './api/ApiServices';
import { COLORS } from './src/components/colors';

async function setToken(value) {
  await AsyncStorage.setItem('token', value);
}
async function setPin(value) {
  await AsyncStorage.setItem('pin', value);
}
export default function Pincode({ route, navigation }) {
  console.log(route)
  const { token, email } = route.params;
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState({ otp: "" })

  const handleSubmit = async () => {
    if (data.otp == "" || data.otp.length != 4) {
      if (data.otp == "") {
        showMessage({
          message: "Please enter the valid otp",
          type: "danger",
        });
      }
      if (data.otp.length != 4) {
        showMessage({
          message: "Please enter atleast 4 digit otp",
          type: "danger",
        });
      }

      return
    }
    console.log("otp", data.otp)
    PostCallWithErrorResponse(ApiConfig.SET_PIN,
      {
        pin: data.otp,
        token: token,
      }
    )
      .then((data1) => {
        console.log(data1.json)
        if (data1.json.result) {

          showMessage({
            message: "pin set successfully",
            type: "success",
          });

          setPin(data.otp)


          navigation.navigate('ProfileDetails', { token: token, email: email })
        }


      }
      )
      .catch((error) => {
        console.log("api response", error);

      });
  }
  return (


    <KeyboardAvoidingView style={{ flex: 1 }}>
      {
        loading ?
          <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
            <ActivityIndicator size="small" color="#0000ff" />

          </View>

          :
          <SafeAreaView style={styles.container}>
            <ScrollView style={{ flex: 1 }}>


              <View style={styles.header}>

                <Text style={{ fontSize: 24, color: '#FFFFFF', marginTop: 10, paddingBottom: 10, fontWeight: 'bold' }}>
                  Setup MPIN
                </Text>

              </View>
              <View style={styles.body}>
                <Text style={{ fontSize: 26, color: '#0CFEBC', marginTop: 30, fontWeight: 'bold' }}>
                  Set MPin Code
                </Text>
                <Text style={{ fontSize: 16, color: COLORS.light_green_new, marginTop: 30, textAlign: 'center' }}>
                  To setup your PIN code, Enter 4 digit code then confirm it below
                </Text>
                <View style={styles.input}>


              <OtpInput
                  numberOfDigits={4}
                  onTextChange={(text) => setData({ ...data, otp: text })}
                  // code={this.state.code} //You can supply this prop or not. The component will be used as a controlled / uncontrolled component respectively.
                  // onCodeChanged = {code => { this.setState({code})}}

                  // codeInputHighlightStyle={{borderBottomColor:'#0CFEBC',}}    autoFocusOnLoad
                  keyboardAppearance	='dark'
                  onFilled={(text) => setData({ ...data, otp: text })}
                  theme={
                    {
                      pinCodeTextStyle:{color:"#0CFEBC"},
                      containerStyle:{width: '80%', height: 100,marginTop:10},
                      pinCodeContainerStyle: {borderRadius:15,backgroundColor:'black',borderColor:'black',color:'#0CFEBC',width:55,height:60,fontSize:20},
                      filledPinCodeContainerStyle: {borderBottomColor:'#0CFEBC',}
                    }
                  }
              />

                </View>

                {/* <TextInput
            style={styles.input}
            value={data.phone}
            placeholder="Otp"
            keyboardType="numeric"
            onChangeText = {(text)=>setData({...data,phone:text})}
    
            placeholderTextColor="#8A8D9F" 
          />

     */}

                <TouchableOpacity
                  onPress={() => handleSubmit()}
                  style={{
                    width: 295,
                    height: 50,
                    alignItems: 'center',
                    justifyContent: 'center',
                    backgroundColor: '#0CFEBC',
                    borderRadius: 25,
                    marginTop: 10,
                    marginBottom: 30,
                    flexDirection: 'row'
                  }}

                >
                  <Text style={{ fontSize: 20, color: '#FFFFFF' }}>Confirm


                  </Text>
                  <Icon name="doubleright" size={20} marginLeft={10} color="#FFFFFF" />
                </TouchableOpacity>
              </View>

            </ScrollView>

          </SafeAreaView>

      }




    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'black',


  },
  header: {
    flex: 0.07,
    backgroundColor: '#252836',
    alignItems: 'center'

  },
  body: {
    flex: 0.4,
    backgroundColor: "#252836",
    marginTop: 20,
    borderRadius: 10,
    marginRight: 10,
    marginLeft: 10,
    alignItems: 'center'
  },
  input: {
    flex: 1,
    flexDirection: 'row'




  }

})